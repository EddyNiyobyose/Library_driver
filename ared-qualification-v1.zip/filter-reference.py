# Test fixture extracted from source; runtime uses deployed source instead.
_VISIBLE_COUNT_ANALYTICS_TYPE = 'visible_count'
_VISIBLE_COUNT_SEMANTICS = 'visible person detections in current processed frame, not unique people, not entries, not occupancy'
_PERSON_BOX_RATIO_FRAME_WIDTH = 640.0
_PERSON_BOX_RATIO_FRAME_HEIGHT = 640.0

def _numeric_confidence(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    confidence = float(value)
    if not math.isfinite(confidence):
        return None
    return confidence

def _numeric_finite_box_coordinate(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    coordinate = float(value)
    if not math.isfinite(coordinate):
        return None
    return coordinate

def _person_box_geometry(detection: dict, frame_width=640, frame_height=640) -> dict[str, float] | None:
    box = detection.get('box')
    if not isinstance(box, (list, tuple)) or len(box) < 4:
        return None
    coordinates = [_numeric_finite_box_coordinate(value) for value in box[:4]]
    if any((value is None for value in coordinates)):
        return None
    raw_x1, raw_y1, raw_x2, raw_y2 = coordinates
    raw_x1 *= 640 / frame_width
    raw_x2 *= 640 / frame_width
    raw_y1 *= 640 / frame_height
    raw_y2 *= 640 / frame_height
    left = min(raw_x1, raw_x2)
    top = min(raw_y1, raw_y2)
    right = max(raw_x1, raw_x2)
    bottom = max(raw_y1, raw_y2)
    width = right - left
    height = bottom - top
    if height <= 0 or width <= 0:
        return None
    area = width * height
    aspect_ratio = width / height
    if not all((math.isfinite(value) for value in (width, height, area, aspect_ratio))):
        return None
    clamped_left = min(max(left, 0.0), _PERSON_BOX_RATIO_FRAME_WIDTH)
    clamped_top = min(max(top, 0.0), _PERSON_BOX_RATIO_FRAME_HEIGHT)
    clamped_right = min(max(right, 0.0), _PERSON_BOX_RATIO_FRAME_WIDTH)
    clamped_bottom = min(max(bottom, 0.0), _PERSON_BOX_RATIO_FRAME_HEIGHT)
    clamped_width = max(0.0, clamped_right - clamped_left)
    clamped_height = max(0.0, clamped_bottom - clamped_top)
    frame_area = _PERSON_BOX_RATIO_FRAME_WIDTH * _PERSON_BOX_RATIO_FRAME_HEIGHT
    return {'left': left, 'top': top, 'right': right, 'bottom': bottom, 'width': width, 'height': height, 'area': area, 'aspect_ratio': aspect_ratio, 'area_ratio': clamped_width * clamped_height / frame_area, 'width_ratio': clamped_width / _PERSON_BOX_RATIO_FRAME_WIDTH, 'height_ratio': clamped_height / _PERSON_BOX_RATIO_FRAME_HEIGHT, 'clamped_left': clamped_left, 'clamped_top': clamped_top, 'clamped_right': clamped_right, 'clamped_bottom': clamped_bottom}

def _is_near_boundary_box(geometry: dict[str, float], margin_pixels: int, *, horizontal_only: bool=False) -> bool:
    margin = max(0, int(margin_pixels))
    touches_left = geometry['clamped_left'] <= margin
    touches_right = geometry['clamped_right'] >= _PERSON_BOX_RATIO_FRAME_WIDTH - margin
    if horizontal_only:
        return touches_left or touches_right
    touches_top = geometry['clamped_top'] <= margin
    touches_bottom = geometry['clamped_bottom'] >= _PERSON_BOX_RATIO_FRAME_HEIGHT - margin
    return touches_left or touches_right or touches_top or touches_bottom

def _is_suspicious_boundary_person_box(confidence: float, geometry: dict[str, float]) -> tuple[bool, bool]:
    if settings.CAMERA_ANALYTICS_PERSON_FILTER_PROFILE in ('candidate_relaxed', 'model'):
        return (False, False)
    max_confidence = float(settings.CAMERA_ANALYTICS_PERSON_FULL_FRAME_MAX_CONFIDENCE)
    if confidence >= max_confidence:
        return (False, False)
    edge_margin = int(settings.CAMERA_ANALYTICS_PERSON_EDGE_MARGIN_PIXELS)
    near_boundary = _is_near_boundary_box(geometry, edge_margin)
    near_side_boundary = _is_near_boundary_box(geometry, edge_margin, horizontal_only=True)
    is_full_frame = geometry['area_ratio'] >= float(settings.CAMERA_ANALYTICS_PERSON_MAX_BOX_AREA_RATIO) and near_boundary
    is_large_boundary = geometry['area_ratio'] >= float(settings.CAMERA_ANALYTICS_PERSON_LARGE_BOUNDARY_MIN_AREA_RATIO) and near_boundary
    is_tall_edge = geometry['height_ratio'] >= float(settings.CAMERA_ANALYTICS_PERSON_EDGE_BOX_MIN_HEIGHT_RATIO) and geometry['width_ratio'] <= float(settings.CAMERA_ANALYTICS_PERSON_EDGE_BOX_MAX_WIDTH_RATIO) and near_side_boundary
    return (is_full_frame, bool(is_full_frame or is_large_boundary or is_tall_edge))

def normalize_person_detections(detections: list[dict], frame_width=640, frame_height=640) -> dict:
    """Filter worker detections to backend person analytics semantics.

    Person analytics intentionally count visible class-0 detections in the
    current processed frame only when the worker supplied a numeric confidence
    at or above the backend minimum. Malformed detections are ignored so a bad
    worker payload cannot inflate counts or crash the poller.
    """
    if any((not isinstance(v, (int, float)) or isinstance(v, bool) or (not math.isfinite(v)) or (v <= 0) for v in (frame_width, frame_height))):
        raise ValueError('invalid source frame dimensions')
    min_confidence = float(settings.CAMERA_ANALYTICS_PERSON_MIN_CONFIDENCE)
    profile = settings.CAMERA_ANALYTICS_PERSON_FILTER_PROFILE
    if profile not in ('legacy', 'candidate_relaxed', 'model'):
        raise ValueError('unknown person filter profile')
    min_box_width = 0 if profile == 'candidate_relaxed' else int(settings.CAMERA_ANALYTICS_PERSON_MIN_BOX_WIDTH)
    min_box_height = int(settings.CAMERA_ANALYTICS_PERSON_MIN_BOX_HEIGHT)
    min_box_area = int(settings.CAMERA_ANALYTICS_PERSON_MIN_BOX_AREA)
    min_aspect_ratio = float(settings.CAMERA_ANALYTICS_PERSON_MIN_ASPECT_RATIO)
    max_aspect_ratio = float(settings.CAMERA_ANALYTICS_PERSON_MAX_ASPECT_RATIO)
    if profile == 'model':
        min_box_width = min_box_height = min_box_area = 1
    filtered: list[dict] = []
    dropped_low_confidence_count = 0
    dropped_malformed_box_count = 0
    dropped_tiny_box_count = 0
    dropped_aspect_ratio_count = 0
    dropped_boundary_box_count = 0
    dropped_full_frame_box_count = 0
    for detection in detections:
        if not isinstance(detection, dict):
            continue
        try:
            detection_class = int(detection.get('class'))
        except (TypeError, ValueError):
            continue
        if detection_class != 0:
            continue
        confidence = _numeric_confidence(detection.get('confidence'))
        if confidence is None:
            continue
        if confidence < min_confidence:
            dropped_low_confidence_count += 1
            continue
        box_geometry = _person_box_geometry(detection, frame_width, frame_height)
        if box_geometry is None:
            dropped_malformed_box_count += 1
            continue
        if profile == 'model' and (box_geometry['width_ratio'] <= 0 or box_geometry['height_ratio'] <= 0):
            dropped_malformed_box_count += 1
            continue
        width = box_geometry['width']
        height = box_geometry['height']
        area = box_geometry['area']
        aspect_ratio = box_geometry['aspect_ratio']
        if profile != 'model' and (aspect_ratio < min_aspect_ratio or aspect_ratio > max_aspect_ratio):
            dropped_aspect_ratio_count += 1
            continue
        if width < min_box_width or height < min_box_height or area < min_box_area:
            dropped_tiny_box_count += 1
            continue
        is_full_frame, is_boundary = _is_suspicious_boundary_person_box(confidence, box_geometry)
        if is_boundary:
            dropped_boundary_box_count += 1
            if is_full_frame:
                dropped_full_frame_box_count += 1
            continue
        filtered.append(detection)
    return {'filtered_detections': filtered, 'raw_detection_count': len(detections), 'filtered_person_count': len(filtered), 'dropped_low_confidence_count': dropped_low_confidence_count, 'dropped_malformed_box_count': dropped_malformed_box_count, 'dropped_tiny_box_count': dropped_tiny_box_count, 'dropped_aspect_ratio_count': dropped_aspect_ratio_count, 'dropped_boundary_box_count': dropped_boundary_box_count, 'dropped_full_frame_box_count': dropped_full_frame_box_count, 'min_confidence_used': min_confidence, 'filter_profile': profile, 'min_box_width_used': min_box_width, 'min_box_height_used': min_box_height, 'min_box_area_used': min_box_area, 'min_aspect_ratio_used': None if profile == 'model' else min_aspect_ratio, 'max_aspect_ratio_used': None if profile == 'model' else max_aspect_ratio, 'max_box_area_ratio_used': float(settings.CAMERA_ANALYTICS_PERSON_MAX_BOX_AREA_RATIO), 'full_frame_max_confidence_used': float(settings.CAMERA_ANALYTICS_PERSON_FULL_FRAME_MAX_CONFIDENCE), 'edge_margin_pixels_used': int(settings.CAMERA_ANALYTICS_PERSON_EDGE_MARGIN_PIXELS), 'edge_box_min_height_ratio_used': float(settings.CAMERA_ANALYTICS_PERSON_EDGE_BOX_MIN_HEIGHT_RATIO), 'edge_box_max_width_ratio_used': float(settings.CAMERA_ANALYTICS_PERSON_EDGE_BOX_MAX_WIDTH_RATIO), 'large_boundary_min_area_ratio_used': float(settings.CAMERA_ANALYTICS_PERSON_LARGE_BOUNDARY_MIN_AREA_RATIO), 'analytics_type': _VISIBLE_COUNT_ANALYTICS_TYPE, 'semantics': _VISIBLE_COUNT_SEMANTICS}
