"""Isolated deployed-code regression checks; all external I/O mocked/blocked."""
import asyncio
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import tempfile
import time
from unittest.mock import AsyncMock, patch


def main():
    from app import ai_detection_client as ai, database, local_security as security, socketio_server, zone_snapshots
    results = []
    async def checks(folder):
        with ExitStack() as stack:
            # Separate Python process, temporary SQLite, no actual notifications/network.
            stack.enter_context(patch('socket.socket.connect', side_effect=RuntimeError('Network forbidden in isolated regression')))
            stack.enter_context(patch('socket.socket.connect_ex', side_effect=RuntimeError('Network forbidden in isolated regression')))
            stack.enter_context(patch.object(security, 'database_path', return_value=folder/'security.db'))
            stack.enter_context(patch.object(ai.analytics_store, 'insert_sample', new=AsyncMock()))
            stack.enter_context(patch.object(ai, 'save_doc', new=AsyncMock()))
            stack.enter_context(patch.object(database, 'get_doc', new=AsyncMock(return_value=None)))
            stack.enter_context(patch.object(ai.settings, 'CAMERA_ANALYTICS_WRITE_RAW_TO_COUCHDB', False))
            notices = stack.enter_context(patch.object(socketio_server.sio, 'emit', new=AsyncMock()))
            published = stack.enter_context(patch.object(socketio_server, 'emit_person_count_update', new=AsyncMock()))
            entered, release = asyncio.Event(), asyncio.Event()
            async def blocked_capture(event):
                entered.set()
                await release.wait()
                return '/security/events/'+event['id']+'/snapshot'
            stack.enter_context(patch.object(zone_snapshots, 'capture', new=blocked_capture))
            rule = security.SecurityRule(enabled=True)
            ai.reset_person_count_stabilization_state()
            security._record('qualification', 'Qualification', rule, [], 'outside', {}, 1)
            try:
                start = time.perf_counter()
                args = ('qualification','Qualification','qualification',[{'class':0,'confidence':.9,'box':[50,20,150,400]}],'2026-10-23T12:00:00Z',True)
                await asyncio.wait_for(ai._handle_person(*args, observation_id='inside',security_rule=rule.model_dump()),5)
                await asyncio.wait_for(entered.wait(),5)
                if published.await_count != 1 or published.call_args.args[0]['person_count'] != 1 or notices.await_count != 1:
                    raise AssertionError('Count/event did not publish while snapshot was blocked')
                results.append({'check':'count_and_initial_event_not_blocked_by_snapshot','status':'PASS','elapsed_ms':(time.perf_counter()-start)*1000})
                await asyncio.wait_for(ai._handle_person(*args, observation_id='inside',security_rule=rule.model_dump()),5)
                if published.await_count != 1:
                    raise AssertionError('Repeated observation published a duplicate count')
                results.append({'check':'duplicate_observation_suppressed','status':'PASS'})
                release.set()
                await security.stop_snapshot_tasks()
                events=await security.recent_events()
                if notices.await_count != 2 or len(events)!=1 or events[0]['evidence_status']!='snapshot_available':
                    raise AssertionError('Completed snapshot update missing')
                results.append({'check':'snapshot_completion_updates_existing_event','status':'PASS'})
            finally:
                release.set()
                await security.stop_snapshot_tasks()
                ai.reset_person_count_stabilization_state()
            hold=asyncio.Event()
            async def failed_capture(event):
                await hold.wait()
                raise OSError('intentional snapshot failure')
            stack.enter_context(patch.object(zone_snapshots,'capture',new=failed_capture))
            try:
                for i in range(security._MAX_SNAPSHOT_TASKS+2):
                    camera='bounded-'+str(i)
                    security._record(camera,camera,rule,[],'outside',{},1)
                    await security.observe(camera,camera,rule.model_dump(),[{'box':[50,20,150,400]}],'inside')
                if len(security._snapshot_tasks)!=security._MAX_SNAPSHOT_TASKS:
                    raise AssertionError('Snapshot concurrency bound not respected')
                hold.set()
                await security.stop_snapshot_tasks()
                await asyncio.sleep(0)
                events=[e for e in await security.recent_events() if e['camera_id'].startswith('bounded-')]
                if len(events)!=security._MAX_SNAPSHOT_TASKS+2 or any(e['evidence_status']!='missing' for e in events):
                    raise AssertionError('Failed snapshots lost events or falsely marked evidence available')
                results.append({'check':'bounded_snapshot_work_and_failure_retains_events','status':'PASS'})
            finally:
                hold.set()
                await security.stop_snapshot_tasks()
    error=None
    with tempfile.TemporaryDirectory(prefix='ared-isolated-code-check-') as directory:
        try:
            asyncio.run(checks(Path(directory)))
        except Exception as exc:
            error=type(exc).__name__+': '+str(exc)
    modules=[ai,security,zone_snapshots]
    print('ARED_RELIABILITY_RESULT:'+json.dumps({'status':'FAIL' if error else 'PASS','checks':results,'error':error,'source_sha256':{m.__name__:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for m in modules},'scope':'Isolated deployed Python logic; network mocked, temporary database. Not browser or camera acceptance.'}))


if __name__=='__main__': main()
