#!/usr/bin/env python3
"""Read-only model qualification. Never installs a model or changes deployments."""
import argparse
import ast
import base64
import collections
import hashlib
import io
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import types
import zipfile

ROOT = Path(__file__).resolve().parent
MODEL_SHA = '87aebc2dbdc1cb7cd63e27108f1b1dcc025ec146d4c184bbb3f3e98b9aafd797'
CANDIDATE_SHA = '9c5d27db61abae7acdf7e3520e85c5ef52d0a0b672c8f52faed50b3db49e543b'
INPUT_SHA = '2a66da5285954dba214dfb52d8c05528f7d1e9ea174bf74606610287648cd423'
CAMERA = 'ad146364-2126-4434-84bc-5dd76446727b'
K = '/usr/local/sbin/ared-kubectl'
MARKER = 'ARED_QUALIFICATION_RESULT:'
REMOTE = '/tmp/ared-qualification-v1'
ARTWORK = '6ea73cd35be1e4ce.jpg'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('w') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)
    descriptor = os.open(str(path.parent), os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def load(path):
    return json.loads(Path(path).read_text())


def require(ok, message):
    if not ok:
        raise ValueError(message)


def overlap(a, b):
    inter = max(0, min(a[2], b[2])-max(a[0], b[0])) * max(0, min(a[3], b[3])-max(a[1], b[1]))
    union = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - inter
    return inter/union if union > 0 else 0


def match(gt, detections):
    remaining = set(range(len(gt)))
    matched = set()
    for index in sorted(range(len(detections)), key=lambda i: (-detections[i][4], i)):
        value, gi = max(((overlap(gt[g], detections[index]), g) for g in sorted(remaining)), default=(0, -1))
        if value >= .5:
            matched.add(gi)
            remaining.remove(gi)
    return matched


def size(box):
    area = (box[2]-box[0])*(box[3]-box[1])
    return 'small' if area < 1024 else 'medium' if area < 9216 else 'large'


def metrics(items, predictions, corrected=True, filter_fn=None):
    total = dict(images=0, gt=0, tp=0, fp=0, fn=0, count_absolute_error=0)
    groups = {s: dict(found=0, total=0) for s in ('small', 'medium', 'large', 'edge_proxy')}
    per_image = {}
    for item in items:
        if not item['primary_scoring']:
            continue
        name = item['name']
        gt = [] if corrected and name == ARTWORK else item['reviewed_gt']
        det = predictions[name]['detections']
        if filter_fn:
            det = filter_fn(det)
        matched = match(gt, det)
        tp, fp, fn = len(matched), len(det)-len(matched), len(gt)-len(matched)
        for key, val in dict(images=1, gt=len(gt), tp=tp, fp=fp, fn=fn, count_absolute_error=abs(len(det)-len(gt))).items():
            total[key] += val
        per_image[name] = dict(tp=tp, fp=fp, fn=fn)
        for i, box in enumerate(gt):
            selected = [size(box)]
            if min(box[:2]) <= 1 or max(box[2:]) >= 639:
                selected.append('edge_proxy')
            for group in selected:
                groups[group]['total'] += 1
                groups[group]['found'] += int(i in matched)
    total['precision'] = total['tp']/(total['tp']+total['fp']) if total['tp']+total['fp'] else None
    total['recall'] = total['tp']/total['gt'] if total['gt'] else None
    total['count_mae'] = total['count_absolute_error']/total['images'] if total['images'] else None
    for group in groups.values():
        group['recall'] = group['found']/group['total'] if group['total'] else None
    return dict(overall=total, groups=groups, per_image=per_image)


def stat(values):
    return dict(samples=len(values), median=statistics.median(values), p95=sorted(values)[math.ceil(.95*len(values))-1], maximum=max(values)) if values else dict(samples=0)


def filter_from_source(source, settings):
    """Execute only the actual deployed pure filter functions, not app startup."""
    names = {'_numeric_confidence', '_numeric_finite_box_coordinate', '_person_box_geometry', '_is_near_boundary_box', '_is_suspicious_boundary_person_box', 'normalize_person_detections'}
    tree = ast.parse(source)
    functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
    require({n.name for n in functions} == names, 'Deployed filter structure changed; cannot assume semantics')
    require(all(not f.decorator_list for f in functions), 'Unexpected filter decorators')
    constants = {'_PERSON_BOX_RATIO_FRAME_WIDTH', '_PERSON_BOX_RATIO_FRAME_HEIGHT', '_VISIBLE_COUNT_ANALYTICS_TYPE', '_VISIBLE_COUNT_SEMANTICS'}
    namespace = {'math': math, 'settings': types.SimpleNamespace(**settings)}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in constants:
                    namespace[target.id] = ast.literal_eval(node.value)
    require(constants <= namespace.keys(), 'Missing filter constants')
    exec(compile(ast.Module(body=functions, type_ignores=[]), 'deployed-filter', 'exec'), namespace)
    def apply(detections):
        rows = [{'box': d[:4], 'confidence': d[4], 'class': int(d[5])} for d in detections]
        result = namespace['normalize_person_detections'](rows, 640, 640)
        return [d['box']+[d['confidence'], d['class']] for d in result['filtered_detections']]
    return apply


def verify_baseline(baseline):
    require(baseline['identity']['model_sha256']['rknn'] == MODEL_SHA, 'Wrong baseline model')
    items = baseline['items']
    require(len(items) == 1000 and len({i['name'] for i in items}) == 1000, 'Incomplete baseline image index')
    for backend in ('rknn', 'onnx'):
        rows = baseline['predictions'][backend]
        require(len(rows) == 1000 and {r['image'] for r in rows} == {i['name'] for i in items}, 'Incomplete baseline predictions')
        for row in rows:
            require(row['confidence'] == .25 and row['nms_iou'] == .45, 'Baseline threshold mismatch')
            validate_detections(row['detections'])
    for item in items:
        require(Path(item['name']).name == item['name'], 'Invalid image name')
        require(len(item['reviewed_gt']) == item['reviewed_box_count'], 'Label count mismatch')
        for box in item['reviewed_gt']:
            require(len(box) == 4 and all(math.isfinite(x) for x in box) and box[2] > box[0] and box[3] > box[1], 'Invalid label coordinates')


def validate_detections(rows):
    for row in rows:
        require(len(row) == 6 and all(isinstance(x, (int, float)) and math.isfinite(x) for x in row), 'Malformed detection')
        require(row[5] == 0 and 0 <= row[4] <= 1 and row[2] > row[0] and row[3] > row[1], 'Invalid detection')


def save_checkpoint(path, identity, rows):
    save(path, dict(identity=identity, rows=rows, rows_sha256=digest(json.dumps(rows,sort_keys=True,allow_nan=False).encode())))


def read_checkpoint(path, identity, items, model):
    value=load(path)
    require(value['identity']==identity, 'Checkpoint identity mismatch')
    rows=value['rows']
    require(value['rows_sha256']==digest(json.dumps(rows,sort_keys=True,allow_nan=False).encode()), 'Checkpoint content hash mismatch')
    require(len(rows)==len(items) and [r['image'] for r in rows]==[i['name'] for i in items], 'Incomplete checkpoint')
    for row,item in zip(rows,items):
        require(row['model']==model and row['image_sha256']==item['image_sha256'], 'Checkpoint image/model mismatch')
        validate_detections(row['detections'])
        require(all(isinstance(row[k],(int,float)) and math.isfinite(row[k]) and row[k]>=0 for k in ('wall_ms','cpu_ms')), 'Invalid checkpoint timing')
        require(len(row['best_raw_score_at_iou_0_5'])==len(item['reviewed_gt']), 'Missing raw score evidence')
    return rows


def command(args, timeout=60, data=None):
    result = subprocess.run(args, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    if result.stderr:
        print(result.stderr.decode(errors='replace')[-4000:], file=sys.stderr, flush=True)
    require(result.returncode == 0, 'Command failed: ' + ' '.join(args[:8]) + '; ' + result.stdout.decode(errors='replace')[-2000:])
    return result.stdout


def get(kind, name=None):
    return json.loads(command([K, '--request-timeout=30s', '-n', 'camera-solution', 'get', kind] + ([name] if name else []) + ['-o', 'json']))


def pod_for(deployment):
    dep = get('deployment', deployment)
    replicas = get('replicasets')['items']
    owners = {r['metadata']['uid'] for r in replicas if any(o.get('uid') == dep['metadata']['uid'] and o.get('controller') for o in r['metadata'].get('ownerReferences', []))}
    pods = [p for p in get('pods')['items'] if not p['metadata'].get('deletionTimestamp') and any(o.get('uid') in owners and o.get('controller') for o in p['metadata'].get('ownerReferences', [])) and any(c.get('type') == 'Ready' and c.get('status') == 'True' for c in p['status'].get('conditions', []))]
    require(len(pods) == 1, 'Expected exactly one ready pod owned by ' + deployment)
    return pods[0]


def container_identity(pod, container):
    rows = [c for c in pod['status']['containerStatuses'] if c['name'] == container]
    require(len(rows) == 1 and rows[0].get('ready') and 'running' in rows[0].get('state', {}), 'Container is not ready')
    c = rows[0]
    return dict(pod_uid=pod['metadata']['uid'], container_id=c['containerID'], image_id=c['imageID'], restarts=c['restartCount'])


def remote(pod, container, code, data=None, timeout=60):
    return command([K, '-n', 'camera-solution', 'exec', '-i', pod, '-c', container, '--', 'env', 'OMP_NUM_THREADS=1', 'OPENBLAS_NUM_THREADS=1', 'RKNN_LOG_LEVEL=0', 'python3', '-c', code], timeout, data)


def probe(pod):
    code = '''import json,hashlib,urllib.request
from pathlib import Path
r=json.load(urllib.request.urlopen("http://127.0.0.1:8000/readyz",timeout=10))
paths=["ModelLoader.py","nms.py","preprocessing.py","rknn_weights/base_model_batch1.rknn"]
v={"ready":r,"hashes":{p:hashlib.sha256((Path("/app")/p).read_bytes()).hexdigest() for p in paths},"resources":{p:Path(p).read_text() for p in ["/sys/fs/cgroup/memory.current","/sys/fs/cgroup/memory.max","/sys/fs/cgroup/memory.events","/sys/fs/cgroup/cpu.stat","/proc/loadavg"] if Path(p).is_file()}}
print(json.dumps(v))'''
    value = json.loads(remote(pod, 'edgevision-ai-toolkit2', code))
    model = value['ready']['model']
    require(value['ready']['status'] == 'ready' and model['backend'] == 'RKNN' and not model['cpu_fallback'] and model['npu_policy_satisfied'], 'AI runtime is not ready with RKNN')
    require(value['hashes']['rknn_weights/base_model_batch1.rknn'] == MODEL_SHA, 'Installed model changed')
    resources = value['resources']
    limit = resources.get('/sys/fs/cgroup/memory.max', 'max').strip()
    if limit != 'max':
        require(int(resources['/sys/fs/cgroup/memory.current']) < .75*int(limit), 'Container memory already above 75%; postpone diagnostic')
    return value


def worker(request):
    """Executed in the AI container; no production writes, one model at a time."""
    import gc
    import resource
    import numpy as np
    import cv2
    sys.path.insert(0, '/app')
    from ModelLoader import RKNNModel
    from nms import non_max_suppression
    model_path = '/app/rknn_weights/base_model_batch1.rknn' if request['model'] == 'baseline' else REMOTE + '/candidate.rknn'
    require(file_sha(model_path) == (MODEL_SHA if request['model'] == 'baseline' else CANDIDATE_SHA), 'Wrong runtime model bytes')
    cv2.setNumThreads(1)
    model = RKNNModel(model_path, nc=1)
    require(model.target == 'rk3568', 'This candidate is only qualified for RK3568')
    try:
        for index, item in enumerate(request['images']):
            encoded = base64.b64decode(item['bytes'], validate=True)
            require(digest(encoded) == item['image_sha256'], 'Image transport hash mismatch')
            frame = cv2.imdecode(np.frombuffer(encoded, np.uint8), cv2.IMREAD_COLOR | cv2.IMREAD_IGNORE_ORIENTATION)
            require(frame is not None and list(frame.shape) == [item['original_height'], item['original_width'], 3], 'Image dimensions mismatch')
            if index == 0:
                for unused in range(3):
                    model.infer_raw(frame)
            start, cpu = time.perf_counter(), time.process_time()
            raw = model.infer_raw(frame)
            wall_ms, cpu_ms = (time.perf_counter()-start)*1000, (time.process_time()-cpu)*1000
            require(raw.shape == (1, 5, 8400) and np.isfinite(raw).all(), 'Unexpected raw output')
            require(raw[0,4].min() >= -1e-5 and raw[0,4].max() <= 1.00001, 'Invalid raw scores')
            det = np.asarray(non_max_suppression(raw.copy(), conf_thres=.25, iou_thres=.45, nc=1)[0]).tolist()
            validate_detections(det)
            best = []
            xywh = raw[0, :4].T
            boxes = np.concatenate((xywh[:, :2]-xywh[:, 2:]/2, xywh[:, :2]+xywh[:, 2:]/2), axis=1)
            areas = np.prod(np.maximum(0, boxes[:, 2:]-boxes[:, :2]), axis=1)
            for gt in item['reviewed_gt']:
                inter = np.prod(np.maximum(0, np.minimum(boxes[:, 2:], gt[2:])-np.maximum(boxes[:, :2], gt[:2])), axis=1)
                union = areas+(gt[2]-gt[0])*(gt[3]-gt[1])-inter
                ious = np.divide(inter, union, out=np.zeros_like(inter), where=union>0)
                scores = raw[0,4,ious>=.5]
                best.append(float(scores.max()) if scores.size else None)
            result = dict(image=item['name'], image_sha256=item['image_sha256'], model=request['model'], detections=det, wall_ms=wall_ms, cpu_ms=cpu_ms, adapter_timing=dict(model.last_timing), peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, best_raw_score_at_iou_0_5=best, raw_max_score=float(raw[0,4].max()))
            print(MARKER+json.dumps(result, allow_nan=False), flush=True)
            del frame, encoded, raw
    finally:
        del model
        gc.collect()


def batch(pod, items, archive, model, before):
    request = dict(model=model, images=[])
    for item in items:
        data = archive.read('images/'+item['name'])
        require(digest(data) == item['image_sha256'], 'Original image mismatch: '+item['name'])
        request['images'].append(dict(item, bytes=base64.b64encode(data).decode()))
    code = 'import runpy,json,sys; g=runpy.run_path("'+REMOTE+'/qualify.py",run_name="worker_module"); g["worker"](json.load(sys.stdin))'
    output = remote(pod, 'edgevision-ai-toolkit2', code, json.dumps(request).encode(), 240)
    rows = []
    for line in output.decode().splitlines():
        if line.startswith(MARKER):
            rows.append(json.loads(line[len(MARKER):]))
        elif line.strip():
            print(line, flush=True)
    after = container_identity(get('pod', pod), 'edgevision-ai-toolkit2')
    require(before == after, 'Container changed during batch; batch discarded, previous checkpoints retained')
    require(len(rows) == len(items) and [r['image'] for r in rows] == [i['name'] for i in items], 'Incomplete batch results')
    for item, row in zip(items, rows):
        require(row['image_sha256'] == item['image_sha256'] and row['model'] == model, 'Result identity mismatch')
        validate_detections(row['detections'])
    return rows


def report(baseline, out, candidate=None, backend=None, speed=None, live=None):
    items = baseline['items']
    old = {r['image']: r for r in baseline['predictions']['rknn']}
    base = metrics(items, old)
    result = dict(scope='Person-only diagnostic qualification, NOT production certification', baseline=base,
        model_comparison='Existing quantized RKNN versus FP16 graph-optimized RKNN; measured difference cannot isolate graph rewrite from precision change.',
        known_label_correction={'image': ARTWORK, 'change': '28 artwork boxes excluded from physical-person ground truth; originals unchanged'},
        definitions={'size': 'box area in 640x640 input: small<1024, medium<9216, large>=9216; NOT measured distance', 'edge_proxy': 'box within 1 pixel of frame edge; NOT certified partial/close', 'matching': 'score-ordered one-to-one IoU>=0.5; confidence .25, NMS IoU .45'},
        gaps=['Labels were screened at preview resolution; completeness is not certified.', 'Close distance and partial-body classes lack verified dedicated labels.', 'No animal, pose, theft or restaurant service-time validation in this Person dataset.', 'Isolated notification checks do not certify browser delivery. Live invalid-frame recovery and multi-camera load still require exercised cases; empty-camera captures cannot pass them.', 'No approved business accuracy or end-to-end latency targets; conservative regression gates are diagnostic only.', 'This is a reused development set, not an independent held-out acceptance test.'], gates={})
    result['baseline_original_labels_as_uploaded'] = metrics(items, old, corrected=False)['overall']
    if backend:
        fn = filter_from_source(backend['source'], backend['settings'])
        result['baseline_with_current_backend_filters'] = metrics(items, old, filter_fn=fn)
        result['backend_settings'] = backend['settings']
    if candidate:
        require(set(candidate) == set(old), 'Candidate incomplete; cannot score as a full run')
        new = metrics(items, candidate)
        result['candidate'] = new
        regressed = [n for n in base['per_image'] if new['per_image'][n]['fn'] > base['per_image'][n]['fn'] or new['per_image'][n]['fp'] > base['per_image'][n]['fp']]
        result['gates']['accuracy_no_per_image_regression'] = dict(status='PASS' if not regressed else 'FAIL', regressed_images=regressed)
        result['gates']['size_recall_no_regression'] = dict(status='PASS' if all(new['groups'][s]['found'] >= base['groups'][s]['found'] for s in base['groups']) else 'FAIL')
        if backend:
            result['candidate_with_current_backend_filters'] = metrics(items, candidate, filter_fn=fn)
        failures = []
        for item in items:
            if not item['primary_scoring']:
                continue
            gt = [] if item['name'] == ARTWORK else item['reviewed_gt']
            row = candidate[item['name']]
            found = match(gt, row['detections'])
            for i, box in enumerate(gt):
                if i not in found:
                    score = row['best_raw_score_at_iou_0_5'][i]
                    stage = 'no_aligned_raw_box' if score is None else 'score_below_or_equal_threshold' if score <= .25 else 'nms_or_one_to_one_matching'
                    failures.append(dict(image=item['name'], label_index=i, size=size(box), stage=stage, best_score=score))
        result['candidate_misses'] = failures
    else:
        result['gates']['accuracy_no_per_image_regression'] = dict(status='NOT_TESTED')
    if speed:
        result['speed_ms'] = {model: {key: stat([r[key] for r in speed if r['model'] == model]) for key in ('wall_ms', 'cpu_ms')} for model in ('baseline', 'candidate')}
        a, b = result['speed_ms']['baseline'], result['speed_ms']['candidate']
        ok = b['wall_ms']['median'] <= .9*a['wall_ms']['median'] and b['cpu_ms']['median'] <= .9*a['cpu_ms']['median'] and b['wall_ms']['p95'] <= a['wall_ms']['p95']
        result['gates']['speed_cpu_gain'] = dict(status='PASS' if ok else 'FAIL', criterion='>=10% lower wall and process-CPU medians, no p95 wall regression; same 50 images, alternating blocks, 3 warmups per model/block')
        result['speed_limitations'] = 'Shared production NPU/host; process CPU excludes driver/kernel work outside process. Block ordering reduces but cannot eliminate contention. Not total-system CPU proof.'
        disagreements = [r['image'] for r in speed if r['model']=='baseline' and r['detections'] != old[r['image']]['detections']]
        result['baseline_replay_exact_differences'] = disagreements
        result['gates']['historical_baseline_reproducible'] = dict(status='REVIEW' if disagreements else 'PASS', note='Any exact detection difference requires review before attributing accuracy changes solely to candidate.')
    else:
        result['gates']['speed_cpu_gain'] = dict(status='NOT_TESTED')
    if live:
        frames = live.get('summary', {}).get('frames', [])
        result['live'] = dict(captured_frames=len(frames), timings={field: stat([f['stage_timing'][field] for f in frames if isinstance(f.get('stage_timing',{}).get(field), (int,float))]) for field in ('pipeline_frame_extract_elapsed_ms','ai_backend_inference_elapsed_ms','worker_attempt_elapsed_ms')}, trace_matches=sum(bool(f.get('worker_observation_id')) and f.get('backend',{}).get('observation_id')==f.get('worker_observation_id') for f in frames), detection_counts=[f.get('ai_detection_count') for f in frames])
        result['gates']['live_trace'] = dict(status='PASS' if frames and result['live']['trace_matches']==len(frames) else 'INCOMPLETE', note='Trace continuity only; actual people counts need image ground truth.')
    if (out/'reliability.json').exists():
        result['isolated_backend_reliability'] = load(out/'reliability.json')
        result['gates']['isolated_backend_reliability'] = {'status': result['isolated_backend_reliability']['status']}
    else:
        result['gates']['isolated_backend_reliability'] = {'status':'NOT_TESTED'}
    result['deployment_decision'] = 'DO_NOT_AUTO_PROMOTE: review all measured gates and unresolved coverage; this script never installs candidate.'
    save(out/'report.json', result)
    lines = ['PERSON QUALIFICATION', 'Diagnostic results only; no model or production setting was changed.', '', 'Saved baseline: '+str(base['overall']), '', 'Gates:']
    lines += [name+': '+gate['status'] for name, gate in result['gates'].items()]
    lines += ['', 'Unresolved coverage:']+result['gaps']
    (out/'READ_ME.txt').write_text('\n'.join(lines)+'\n')
    return result


def run(args):
    import fcntl
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=True)
    with (out.parent/'.ared-qualification.lock').open('a') as global_lock, (out/'run.lock').open('a') as lock:
        fcntl.flock(global_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        _run(args, out)


def _run(args, out):
    package = load(ROOT/'package.json')
    for name, expected in package.items():
        require(Path(name).name == name and file_sha(ROOT/name) == expected, 'Kit file changed: '+name)
    baseline = load(ROOT/'baseline.json')
    verify_baseline(baseline)
    import shutil
    require(shutil.disk_usage(out).free > 512*1024*1024, 'Need at least 512 MiB host free space for reports')
    require(file_sha(args.input) == INPUT_SHA, 'Original dataset ZIP fingerprint mismatch')
    pod = pod_for('edgevision-ai-toolkit2')
    name = pod['metadata']['name']
    before = container_identity(pod, 'edgevision-ai-toolkit2')
    state = probe(name)
    backend_pod = pod_for('camera-backend')
    backend_name = backend_pod['metadata']['name']
    backend_container = 'backend'
    backend_identity = container_identity(backend_pod, backend_container)
    code = 'import json; from pathlib import Path; from app.config import settings; print(json.dumps({"source":Path("/app/app/ai_detection_client.py").read_text(),"settings":{n:getattr(settings,n) for n in type(settings).model_fields if n.startswith("CAMERA_ANALYTICS_PERSON_")}}))'
    # Resolve module filename from Python itself; do not guess image filesystem layout.
    code = code.replace('Path("/app/app/ai_detection_client.py")', '__import__("pathlib").Path(__import__("app.ai_detection_client",fromlist=["__file__"]).__file__)')
    backend = json.loads(remote(backend_name, backend_container, code))
    filter_from_source(backend['source'], backend['settings'])
    require(container_identity(get('pod', backend_name), backend_container) == backend_identity, 'Backend restarted during settings capture')
    identity = dict(package=package, input_sha256=INPUT_SHA, ai_image=before['image_id'], ai_hashes=state['hashes'], backend_image=backend_identity['image_id'], backend_source_sha=digest(backend['source'].encode()), backend_settings=backend['settings'])
    if (out/'identity.json').exists():
        require(load(out/'identity.json') == identity, 'Run identity changed; use a new --output folder')
    else:
        require(not any(p.name not in ('run.lock', 'run.log') for p in out.iterdir()), 'Output contains unrelated files')
        save(out/'identity.json', identity)
    save(out/'backend.json', backend)
    save(out/'runtime-before.json', dict(container=before, state=state))
    try:
        code = 'import sys; exec(compile(sys.stdin.read(), "isolated_reliability_check", "exec"), {"__name__":"__main__"})'
        response = remote(backend_name, backend_container, code, (ROOT/'reliability_worker.py').read_bytes(), 60)
        rows = [json.loads(line.split('ARED_RELIABILITY_RESULT:',1)[1]) for line in response.decode().splitlines() if line.startswith('ARED_RELIABILITY_RESULT:')]
        require(len(rows)==1 and rows[0]['status'] in ('PASS','FAIL'), 'No valid isolated reliability result')
        require(rows[0]['source_sha256']['app.ai_detection_client'] == identity['backend_source_sha'], 'Backend source changed during reliability checks')
        save(out/'reliability.json', rows[0])
    except Exception as exc:
        save(out/'reliability.json', dict(status='INCOMPLETE', error=str(exc)))
    report(baseline, out, backend=backend)
    payload = {n: base64.b64encode((ROOT/n).read_bytes()).decode() for n in ('qualify.py', 'candidate.rknn')}
    install = 'import sys,json,base64; from pathlib import Path; p=Path("'+REMOTE+'"); p.mkdir(exist_ok=True); d=json.load(sys.stdin); [(p/n).write_bytes(base64.b64decode(d[n],validate=True)) for n in ("qualify.py","candidate.rknn")]'
    remote(name, 'edgevision-ai-toolkit2', install, json.dumps(payload).encode())
    items = baseline['items']
    with zipfile.ZipFile(args.input) as archive:
        require(len(archive.namelist()) == len(set(archive.namelist())), 'Duplicate ZIP members')
        for item in items:
            require(digest(archive.read('images/'+item['name'])) == item['image_sha256'], 'Dataset image fingerprint mismatch')
        print('PASS: all 1000 original image fingerprints checked. Existing baseline reused.', flush=True)
        # 50 deterministic, distributed images: ensure each pixel-size group is represented.
        selected = []
        ordered = sorted(items, key=lambda i: i['image_sha256'])
        for group in ('small', 'medium', 'large'):
            selected += [i for i in ordered if i['primary_scoring'] and any(size(b)==group for b in i['reviewed_gt'])][:10]
        unique = {i['name']: i for i in selected}
        for item in ordered:
            if len(unique) == 50:
                break
            unique.setdefault(item['name'], item)
        speed_items = list(unique.values())
        speed_rows = []
        for block in range(5):
            group = speed_items[block*10:(block+1)*10]
            for model in (('baseline','candidate') if block%2==0 else ('candidate','baseline')):
                path = out/'speed'/f'{block}-{model}.json'
                if not path.exists():
                    require(container_identity(get('pod', name), 'edgevision-ai-toolkit2') == before, 'Container changed; resume with same command')
                    require(probe(name)['hashes'] == state['hashes'], 'Adapter/model changed during run')
                    rows = batch(name, group, archive, model, before)
                    save_checkpoint(path, identity, rows)
                speed_rows.extend(read_checkpoint(path, identity, group, model))
                print('SPEED BLOCK', block+1, model, 'saved', flush=True)
        for start in range(0, len(items), 20):
            group = items[start:start+20]
            path = out/'accuracy'/f'{start:04d}.json'
            if not path.exists():
                require(container_identity(get('pod', name), 'edgevision-ai-toolkit2') == before, 'Container changed; resume with same command')
                require(probe(name)['hashes'] == state['hashes'], 'Adapter/model changed during run')
                rows = batch(name, group, archive, 'candidate', before)
                save_checkpoint(path, identity, rows)
            read_checkpoint(path, identity, group, 'candidate')
            print('CANDIDATE ACCURACY', start+len(group), '/1000 saved permanently', flush=True)
    candidate = {r['image']:r for path in sorted((out/'accuracy').glob('*.json')) for r in load(path)['rows']}
    require(container_identity(get('pod', backend_name), backend_container) == backend_identity, 'Backend changed during run; retain measurements, review before final report')
    live = None
    capture_code = '''import json,sys,time,urllib.request
base="http://127.0.0.1:8090/diagnostics"
r=urllib.request.Request(base+"/cameras/'''+CAMERA+'''/collect",data=b"",method="POST")
s=json.load(urllib.request.urlopen(r,timeout=15)); url=base+"/collections/"+s["session_id"]
for attempt in range(45):
 s=json.load(urllib.request.urlopen(url,timeout=10))
 if s["state"]!="collecting": break
 time.sleep(2)
if s["state"]!="complete": raise RuntimeError("Collection incomplete: "+str(s))
sys.stdout.buffer.write(urllib.request.urlopen(url+"/bundle",timeout=60).read())'''
    try:
        content = remote(backend_name, backend_container, capture_code, timeout=180)
        with zipfile.ZipFile(io.BytesIO(content)) as z:
            require(z.testzip() is None, 'Live bundle CRC failed')
            live = json.loads(z.read('diagnostics.json'))
        (out/'camera-diagnostics.zip').write_bytes(content)
    except Exception as exc:
        save(out/'live-collection-error.json', dict(error=str(exc)))
        print('Live collection unavailable; accuracy/speed evidence retained.', flush=True)
    save(out/'runtime-after.json', dict(container=container_identity(get('pod',name),'edgevision-ai-toolkit2'), state=probe(name)))
    report(baseline, out, candidate, backend, speed_rows, live)
    archive_path = out/'qualification-results.zip'
    temporary = out/'qualification-results.zip.partial'
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as z:
        for path in sorted(out.rglob('*')):
            if path.is_file() and path.name not in ('run.lock','run.log','qualification-results.zip','qualification-results.zip.partial') and not path.name.endswith('.partial'):
                z.write(path, path.relative_to(out))
    temporary.replace(archive_path)
    print('COMPLETE. FILE TO SHARE:', archive_path, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['start', 'run', 'audit'])
    parser.add_argument('--input', default='/mnt/data/ai-evaluation/person-accuracy-input-v2.zip')
    parser.add_argument('--output', default='/mnt/data/ai-evaluation/qualification-v1')
    args = parser.parse_args()
    if args.mode == 'start':
        out = Path(args.output).resolve()
        out.mkdir(parents=True, exist_ok=True)
        with (out/'run.log').open('ab') as log:
            process = subprocess.Popen([sys.executable, '-u', str(Path(__file__).resolve()), 'run', '--input', str(Path(args.input).resolve()), '--output', str(out)], stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        print('SSH-independent PID:', process.pid)
        print('LOG:', out/'run.log')
        print('RESULT:', out/'qualification-results.zip')
    elif args.mode == 'audit':
        baseline = load(ROOT/'baseline.json')
        verify_baseline(baseline)
        out = Path(args.output)
        out.mkdir(parents=True, exist_ok=True)
        report(baseline, out)
        print('Baseline audit saved:', out/'report.json')
    else:
        try:
            run(args)
        except Exception as exc:
            print('STOP:', type(exc).__name__, str(exc), 'Completed host checkpoints retained. No production change made.', file=sys.stderr, flush=True)
            raise


if __name__ == '__main__':
    main()
