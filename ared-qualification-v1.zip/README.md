# Person-model qualification v1

Purpose: measure the existing Person model against the separate RK3568 CPU-optimization candidate, reuse the completed baseline, and expose remaining evidence gaps. This does not deploy, train, replace weights, lower thresholds, patch GitOps, or trigger CI.

## One run, four measured areas

1. **Accuracy:** candidate inference on the same 1,000 fingerprint-verified original images. Reuse the existing baseline outputs rather than rerun its entire dataset. Report primary 742-image precision, recall, count error, small/medium/large and frame-edge proxy recall, individual regressions, and raw-score/matching stages of misses. Report both the uploaded label baseline and the documented artwork correction. The 182 ambiguous and 76 unresolved fragment images are not silently promoted into certified primary ground truth.
2. **Backend filtering:** retrieve the actual deployed filter source and current settings. Execute its pure filtering functions against the exact saved model detections and candidate detections. Compare accuracy before and after filters without changing settings. This does not reproduce temporal stabilization from unrelated still images.
3. **Speed and process CPU:** run both RKNN files on the same 50 deterministically selected images, in alternating ten-image blocks, with three warmups for each model/block. One diagnostic model is loaded at a time. Report median and p95 wall time, process CPU and peak process memory. Existing live inference still shares the NPU: this is a same-session comparison, not an isolated hardware benchmark.
4. **Count/notification code and live timing:** execute four deployed backend logic checks in a separate process with a temporary SQLite database, mocked persistence/socket publication/capture, and blocked socket connections. Check count publication while snapshot work is blocked, duplicate suppression, completed-image update, and bounded failed-snapshot work. Then request the existing three-frame live diagnostic bundle and trace AI → worker → backend and extraction/inference times. Real notifications are not sent by the isolated checks.

## Installation and start

Copy `ared-qualification-v1.zip` to `/mnt/data/ai-evaluation/` on the box. Keep the already existing `/mnt/data/ai-evaluation/person-accuracy-input-v2.zip`; do not copy the pictures again.

Extract this kit into `/mnt/data/ai-evaluation/ared-qualification-v1` using the supplied checksum-verified command. Then:

```sh
python3 /mnt/data/ai-evaluation/ared-qualification-v1/qualify.py start
```

The supervisor continues after SSH disconnects. Completed batches are written and fsynced to host storage, not container `/tmp`. At most one unfinished batch needs repeating after interruption. The script does not automatically restart the application or chase deployments while measurements are in flight.

To resume after an interrupted test, run the same start command. It discovers the current ready pod through Deployment → ReplicaSet ownership and verifies the same code/model/settings identity. A changed release/settings intentionally requires a new `--output` directory. Only one qualification process can hold the host lock.

Check progress without starting another run:

```sh
tail -n 15 /mnt/data/ai-evaluation/qualification-v1/run.log
```


Share `/mnt/data/ai-evaluation/qualification-v1/qualification-results.zip` once the log says `COMPLETE`.

## Diagnostic gates, not promised business acceptance

- Accuracy: no increased false positives or misses on any primary image; no size-group recall regression. This deliberately strict gate surfaces tradeoffs instead of hiding them in an average.
- Speed: at least 10% lower median wall time and process CPU, with no p95 wall-time regression. This is an engineering screening threshold, not an agreed product requirement or statistical certainty.
- Reproducibility: any exact difference between current-model replay and the saved baseline is marked REVIEW. Adapter hashes are recorded, because the historical code and current code can differ.
- Missing data is NOT_TESTED or INCOMPLETE, never PASS. A full result file does not mean all gates passed.
- The final decision always remains DO_NOT_AUTO_PROMOTE. Review the results before selecting a candidate.

## Explicit limits

- Preview-reviewed annotations do not certify every tiny person or exact boundary. Small pixel area is not measured distance; touching the frame edge is not proof of close range or partial visibility. The script cannot invent those labels.
- This reused dataset is development evidence. It is no longer an independent held-out acceptance set for changes tuned on it.
- Candidate is FP16, current model is quantized. A comparison measures their combined deployment differences; it does not isolate precision effects from the attention-graph rewrite.
- Process CPU is not total board/driver CPU. No claim of moving every operation to the NPU is made.
- Live empty frames cannot prove person recall, recovery from corrupted decoder output, browser notification delivery, or multi-camera capacity. No person is artificially inserted into the live stream.
- Pose, animal classes, theft and restaurant timing are outside this single-class Person evaluation.
- Isolated regression tests exercise deployed Python logic, not the full network/browser path. They do not inject faults into the live application.
- No claim of 100% certainty or dramatic improvement is made before hardware results. The candidate has not been tested on this RK3568 by the author.

## Local validation included

16 script checks passed, including exact reproduction of the existing baseline, invalid/incomplete inputs, one-to-one matching, per-image regression detection, container-change rejection, worker result protocol, and a simulated interruption/resume of all 1,000 images with zero completed batches repeated.

Four isolated backend regression checks also passed against the locally available application source. The kit runs them again against the actual deployed backend and records source hashes. Source-reference tests do not claim a fresh GitHub review.

Run local script tests from the kit folder with Python 3 and NumPy available:

```sh
python3 -m unittest -v test_qualify
```

Offline baseline-only report (standard library; no NPU required):

```sh
python3 qualify.py audit --output ./baseline-audit
```

## Primary references consulted

Rockchip RKNN Toolkit2 (conversion, runtime and evaluation): https://github.com/airockchip/rknn-toolkit2
Rockchip layer accuracy analysis example: https://github.com/airockchip/rknn-toolkit2/blob/master/rknn-toolkit2/examples/functions/accuracy_analysis/test.py
ONNX Runtime thread management: https://onnxruntime.ai/docs/performance/tune-performance/threading.html

These describe evaluation/runtime mechanisms. They do not prove this candidate's hardware speed or accuracy.
