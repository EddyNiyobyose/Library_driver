import ast
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import qualify as q


class QualificationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = q.load(q.ROOT/'baseline.json')

    def test_baseline_reproduces_existing_report(self):
        q.verify_baseline(self.base)
        old = {r['image']:r for r in self.base['predictions']['rknn']}
        m = q.metrics(self.base['items'], old)
        self.assertEqual([m['overall'][k] for k in ('images','gt','tp','fp','fn')], [742,1768,982,403,786])
        self.assertEqual(m['groups']['small'], {'found':34,'total':326,'recall':34/326})
        original = q.metrics(self.base['items'], old, corrected=False)
        self.assertEqual(original['overall']['gt'], 1796)

    def test_duplicate_detections_are_false_positives(self):
        gt = [[10,10,50,100]]
        d = [[10,10,50,100,.9,0],[10,10,50,100,.8,0]]
        self.assertEqual(q.match(gt,d), {0})

    def test_matching_is_score_ordered_not_input_order(self):
        gt = [[0,0,10,10],[5,0,15,10]]
        self.assertEqual(q.match(gt, [[0,0,15,10,.8,0],[0,0,10,10,.9,0]]), {0,1})

    def test_incomplete_baseline_rejected(self):
        b = copy.deepcopy(self.base)
        b['predictions']['rknn'].pop()
        with self.assertRaises(ValueError): q.verify_baseline(b)

    def test_bad_values_rejected(self):
        for d in ([[0,0,10,10,float('nan'),0]], [[0,0,10,10,.9,1]], [[10,0,0,10,.9,0]]):
            with self.assertRaises(ValueError): q.validate_detections(d)

    def test_missing_evidence_is_not_pass(self):
        with tempfile.TemporaryDirectory() as d:
            r = q.report(self.base, Path(d))
            self.assertEqual(r['gates']['accuracy_no_per_image_regression']['status'],'NOT_TESTED')
            self.assertTrue(r['deployment_decision'].startswith('DO_NOT_AUTO_PROMOTE'))

    def test_incomplete_candidate_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError): q.report(self.base, Path(d), {'bad':{}})

    def test_identical_candidate_passes_accuracy_but_not_untested_speed(self):
        old = {r['image']:dict(r, best_raw_score_at_iou_0_5=r['best_raw_score_at_iou_0.5']) for r in self.base['predictions']['rknn']}
        with tempfile.TemporaryDirectory() as d:
            r = q.report(self.base, Path(d), old)
            self.assertEqual(r['gates']['accuracy_no_per_image_regression']['status'],'PASS')
            self.assertEqual(r['gates']['speed_cpu_gain']['status'],'NOT_TESTED')

    def test_one_false_positive_cannot_hide_in_average(self):
        old = {r['image']:dict(r, best_raw_score_at_iou_0_5=r['best_raw_score_at_iou_0.5']) for r in self.base['predictions']['rknn']}
        name = next(i['name'] for i in self.base['items'] if i['primary_scoring'] and not i['reviewed_gt'])
        old[name] = dict(old[name], detections=[[0,0,30,100,.9,0]])
        with tempfile.TemporaryDirectory() as d:
            r = q.report(self.base, Path(d), old)
            self.assertEqual(r['gates']['accuracy_no_per_image_regression']['status'],'FAIL')

    def test_changed_container_discards_batch(self):
        class Archive:
            def read(self, name): return b'original'
        item = dict(name='a.jpg',image_sha256=q.digest(b'original'))
        row = dict(image='a.jpg',image_sha256=item['image_sha256'],model='candidate',detections=[])
        with patch.object(q,'remote',return_value=(q.MARKER+json.dumps(row)).encode()), patch.object(q,'get',return_value={}), patch.object(q,'container_identity',return_value={'id':2}):
            with self.assertRaisesRegex(ValueError,'Container changed'):
                q.batch('pod',[item],Archive(),'candidate',{'id':1})

    def test_transport_hash_mismatch_rejected(self):
        class Archive:
            def read(self, name): return b'wrong'
        with self.assertRaisesRegex(ValueError,'Original image mismatch'):
            q.batch('pod',[dict(name='a.jpg',image_sha256='bad')],Archive(),'candidate',{})

    def test_atomic_report_has_no_partial_left(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'x.json'
            q.save(p, {'a':1})
            self.assertEqual(q.load(p),{'a':1})
            self.assertFalse(Path(str(p)+'.partial').exists())

    def test_live_zero_count_does_not_claim_accuracy(self):
        frame = dict(worker_observation_id='1',backend={'observation_id':'1'},stage_timing={},ai_detection_count=0)
        with tempfile.TemporaryDirectory() as d:
            r = q.report(self.base,Path(d),live={'summary':{'frames':[frame]}})
            self.assertEqual(r['gates']['live_trace']['status'],'PASS')
            self.assertEqual(r['gates']['accuracy_no_per_image_regression']['status'],'NOT_TESTED')



class ResumeIntegrationTest(unittest.TestCase):
    def test_interrupted_run_reuses_host_batches(self):
        import io
        import types
        import zipfile
        base = copy.deepcopy(q.load(q.ROOT/'baseline.json'))
        for item in base['items']:
            item['image_sha256'] = q.digest(item['name'].encode())
        predictions = {r['image']:r for r in base['predictions']['rknn']}
        real_zip = zipfile.ZipFile
        class Inputs:
            def __enter__(self): return self
            def __exit__(self,*args): pass
            def namelist(self): return ['images/'+i['name'] for i in base['items']]
            def read(self,name): return Path(name).name.encode()
        def archives(path,*args,**kwargs):
            return Inputs() if path == 'simulated-input.zip' else real_zip(path,*args,**kwargs)
        identity = {'image_id':'same-image','container_id':'same-container'}
        state = {'hashes':{'model':'same-hash'},'ready':{}}
        calls = []
        fail_once = [True]
        def batches(pod,items,archive,model,before):
            if len(items)==20 and len([x for x in calls if x[1]==20])==1 and fail_once[0]:
                fail_once[0]=False
                raise RuntimeError('simulated restart')
            calls.append((model,len(items),items[0]['name']))
            return [dict(image=i['name'], image_sha256=i['image_sha256'], model=model, detections=predictions[i['name']]['detections'], best_raw_score_at_iou_0_5=predictions[i['name']]['best_raw_score_at_iou_0.5'], wall_ms=100 if model=='baseline' else 70, cpu_ms=80 if model=='baseline' else 40) for i in items]
        backend = {'source':'simulated','settings':{}}
        capture = io.BytesIO()
        with real_zip(capture,'w') as z: z.writestr('diagnostics.json',json.dumps({'summary':{'frames':[]}}))
        def remote(pod,container,code,*args,**kwargs):
            if 'settings' in code: return json.dumps(backend).encode()
            if '/collect' in code: return capture.getvalue()
            return b''
        real_sha=q.file_sha
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'kit';root.mkdir();out=Path(d)/'results';out.mkdir()
            (out/'run.log').write_text('launcher already opened log\n')
            (root/'baseline.json').write_text(json.dumps(base))
            (root/'candidate.rknn').write_bytes(b'simulated')
            (root/'qualify.py').write_text('simulated')
            (root/'package.json').write_text(json.dumps({n:real_sha(root/n) for n in ['baseline.json','candidate.rknn','qualify.py']}))
            args=types.SimpleNamespace(input='simulated-input.zip',output=str(out))
            with patch.object(q,'ROOT',root), patch.object(q,'file_sha',side_effect=lambda p:q.INPUT_SHA if p==args.input else real_sha(p)), patch.object(q,'pod_for',return_value={'metadata':{'name':'pod'}}), patch.object(q,'container_identity',return_value=identity), patch.object(q,'probe',return_value=state), patch.object(q,'remote',side_effect=remote), patch.object(q,'get',return_value={}), patch.object(q,'filter_from_source',return_value=lambda d:d), patch.object(q,'batch',side_effect=batches), patch.object(q.zipfile,'ZipFile',side_effect=archives), patch('builtins.print'):
                with self.assertRaisesRegex(RuntimeError,'simulated restart'): q.run(args)
                self.assertTrue((out/'accuracy'/'0000.json').is_file())
                q.run(args)
            self.assertEqual(len(calls),60)  # 10 speed blocks + 50 accuracy batches, no repeat.
            self.assertTrue((out/'qualification-results.zip').is_file())
            self.assertEqual(q.load(out/'report.json')['gates']['accuracy_no_per_image_regression']['status'],'PASS')

class WorkerProtocolTests(unittest.TestCase):
    def test_worker_uses_verified_bytes_and_emits_parseable_result(self):
        import contextlib
        import io
        import numpy as np
        import sys
        import types
        raw = np.zeros((1,5,8400),np.float32)
        raw[0,:,0] = [20,30,10,20,.9]
        class Model:
            target='rk3568'
            def __init__(self,*args,**kwargs): self.last_timing={}
            def infer_raw(self,frame): return raw.copy()
        cv = types.SimpleNamespace(setNumThreads=lambda n:None,imdecode=lambda *a:np.zeros((2,3,3),np.uint8),IMREAD_COLOR=1,IMREAD_IGNORE_ORIENTATION=128)
        nms = types.SimpleNamespace(non_max_suppression=lambda *a,**kw:[np.array([[15,20,25,40,.9,0]])])
        request = dict(model='candidate',images=[dict(name='test.jpg',bytes=q.base64.b64encode(b'test').decode(),image_sha256=q.digest(b'test'),original_height=2,original_width=3,reviewed_gt=[[15,20,25,40]])])
        stdout=io.StringIO()
        with patch.dict(sys.modules,{'cv2':cv,'ModelLoader':types.SimpleNamespace(RKNNModel=Model),'nms':nms}), patch.object(q,'file_sha',return_value=q.CANDIDATE_SHA), contextlib.redirect_stdout(stdout):
            q.worker(request)
        result=json.loads(stdout.getvalue().split(q.MARKER)[1])
        self.assertEqual(result['image'],'test.jpg')
        self.assertAlmostEqual(result['best_raw_score_at_iou_0_5'][0],.9,places=5)
        self.assertGreaterEqual(result['cpu_ms'],0)

    def test_source_filter_reference_matches_recorded_legacy_counts(self):
        source_path=q.ROOT/'filter-reference.py'
        if not source_path.exists(): self.skipTest('reference fixture not packaged')
        reference=q.load(q.ROOT/'local-filter-reference.json')
        f=q.filter_from_source(source_path.read_text(),reference['settings'])
        base=q.load(q.ROOT/'baseline.json')
        actual=q.metrics(base['items'],{r['image']:r for r in base['predictions']['rknn']},filter_fn=f)
        self.assertEqual(actual['overall'],reference['metrics'])
        self.assertEqual(actual['groups']['small']['found'],0)


if __name__ == '__main__': unittest.main()
