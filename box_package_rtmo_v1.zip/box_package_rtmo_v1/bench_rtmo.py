#!/usr/bin/env python3
"""On-device RK3568 benchmark for RTMO-s (one pass per frame): NPU body (.rknn) + CPU tail (.onnx). Read-only test.

Standalone (numpy + cv2 + rknnlite + onnxruntime only) so it can be placed in /tmp on the box, run, and deleted.
Writes only inside --out; loads the given files read-only; changes no configuration and starts no service.

Per model it measures:
  * NPU body: load + init time, N timed runs after warm-up (mean / p50 / p95 / max)
  * CPU tail (NMS + keypoint decoder) in onnxruntime with --tail-threads threads, per picture (it grows with people)
  * full frame per picture: letterbox + NPU + tail, people kept at score >= --score
  * peak RSS, load average before/after, NPU load samples
and saves decoded people per picture (outputs.json) for comparison with the simulator.

Usage: python3 bench_rtmo.py --model body.rknn,tail.onnx [--model ...] --size 384x640 --images DIR --out DIR
"""
from __future__ import annotations

import argparse
import json
import os
import statistics
import threading
import time
from pathlib import Path

import cv2
import numpy as np

PAD = 114


def npu_load() -> str:
    try:
        return Path("/sys/kernel/debug/rknpu/load").read_text().strip()
    except OSError:
        return "unavailable"


def vm_hwm_kb() -> int:
    try:
        for line in Path("/proc/self/status").read_text().splitlines():
            if line.startswith("VmHWM:"):
                return int(line.split()[1])
    except OSError:
        pass
    return -1


def loadavg():
    return os.getloadavg() if hasattr(os, "getloadavg") else None


def pct(values, p):
    s = sorted(values)
    k = (len(s) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(s) - 1)
    return s[lo] + (s[hi] - s[lo]) * (k - lo)


def summary(values):
    return {"mean": round(statistics.fmean(values), 3), "p50": round(pct(values, 0.5), 3),
            "p95": round(pct(values, 0.95), 3), "max": round(max(values), 3), "n": len(values)} if values else None


def letterbox(frame, h, w):
    """Top-left placement, grey 114, BGR kept (RTMO / rtmlib geometry)."""
    r = min(h / frame.shape[0], w / frame.shape[1])
    nw, nh = int(frame.shape[1] * r), int(frame.shape[0] * r)
    canvas = np.full((h, w, 3), PAD, np.uint8)
    canvas[:nh, :nw] = cv2.resize(frame, (nw, nh), interpolation=cv2.INTER_LINEAR)
    return canvas[None], r


def load(path):
    from rknnlite.api import RKNNLite

    rk = RKNNLite(verbose=False)
    t0 = time.perf_counter()
    if rk.load_rknn(path) != 0 or rk.init_runtime() != 0:
        raise RuntimeError(f"cannot load {path} on the NPU")
    return rk, (time.perf_counter() - t0) * 1000.0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--model", action="append", required=True, help="body.rknn,tail.onnx (repeatable)")
    ap.add_argument("--size", default="384x640", help="model input HxW")
    ap.add_argument("--images", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--runs", type=int, default=100)
    ap.add_argument("--warmup", type=int, default=10)
    ap.add_argument("--tail-threads", type=int, default=1, help="onnxruntime threads for the CPU tail (1 = do not compete with live services)")
    ap.add_argument("--score", type=float, default=0.3)
    args = ap.parse_args()

    import onnxruntime as ort

    h, w = (int(v) for v in args.size.lower().split("x"))
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    images = sorted(p for p in Path(args.images).iterdir() if p.suffix.lower() in (".jpg", ".png"))
    report = {"started": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "loadavg_before": loadavg(), "npu_load_before": npu_load(),
              "size": [h, w], "tail_threads": args.tail_threads, "models": {}}
    samples, stop = [], threading.Event()

    def sampler():
        while not stop.is_set():
            samples.append({"t": round(time.time(), 1), "npu": npu_load(), "load1": (loadavg() or [None])[0]})
            time.sleep(0.5)

    threading.Thread(target=sampler, daemon=True).start()
    per_image = []
    for spec in args.model:
        body_path, _, tail_path = spec.partition(",")
        rk, init = load(body_path)
        so = ort.SessionOptions()
        so.intra_op_num_threads = so.inter_op_num_threads = args.tail_threads
        tail = ort.InferenceSession(tail_path, sess_options=so, providers=["CPUExecutionProvider"])
        tail_names = [i.name for i in tail.get_inputs()]
        shapes = [i.shape for i in tail.get_inputs()]

        def body(x):
            raw = rk.inference(inputs=[x])
            return [np.asarray(r, np.float32).reshape(s) for r, s in zip(raw, shapes)]

        x, _ = letterbox(cv2.imread(str(images[0])), h, w)
        for _ in range(args.warmup):
            body(x)
        npu = []
        for _ in range(args.runs):
            t0 = time.perf_counter(); body(x); npu.append((time.perf_counter() - t0) * 1000.0)

        frame_ms, tail_ms, tail_per_person, counts = [], [], [], []
        for img in images:
            frame = cv2.imread(str(img))
            t0 = time.perf_counter()
            x, r = letterbox(frame, h, w)
            raw = body(x)
            t1 = time.perf_counter()
            dets, kpts = tail.run(None, dict(zip(tail_names, raw)))
            t2 = time.perf_counter()
            keep = [i for i in range(dets.shape[1]) if float(dets[0, i, 4]) >= args.score]
            people = [{"box": [round(float(v) / r, 1) for v in dets[0, i, :4]], "score": round(float(dets[0, i, 4]), 4),
                       "kpts": [[round(float(k[0]) / r, 1), round(float(k[1]) / r, 1), round(float(k[2]), 3)] for k in kpts[0, i]]}
                      for i in keep]
            frame_ms.append((time.perf_counter() - t0) * 1000.0)
            tail_ms.append((t2 - t1) * 1000.0)
            if keep:
                tail_per_person.append((t2 - t1) * 1000.0 / len(keep))
            counts.append(len(keep))
            per_image.append({"model": Path(body_path).name, "image": img.name, "tail_rows": int(dets.shape[1]), "people": people})
        report["models"][Path(body_path).name] = {
            "tail": Path(tail_path).name, "init_ms": round(init, 1), "bytes": Path(body_path).stat().st_size,
            "npu_ms": summary(npu), "cpu_tail_ms": summary(tail_ms), "cpu_tail_ms_per_person": summary(tail_per_person),
            "frame_ms_including_cpu": summary(frame_ms), "people_per_frame": summary(counts), "images": len(images)}
        rk.release()
    stop.set()
    report.update({"finished": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "loadavg_after": loadavg(),
                   "peak_rss_kb": vm_hwm_kb(), "npu_load_samples": samples})
    (out / "bench.json").write_text(json.dumps(report, indent=2))
    (out / "outputs.json").write_text(json.dumps(per_image))
    print(json.dumps({k: v for k, v in report.items() if k != "npu_load_samples"}, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
