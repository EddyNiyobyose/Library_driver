#!/bin/sh
# RTMO-s benchmark on the RK3568 box: one detached run, results saved per model. Read-only test.
#
# Writes only inside this folder (results/). Loads the .rknn/.onnx files read-only, installs nothing,
# changes no configuration, starts or restarts no service. Each model runs in its own python process,
# so a crash or a full memory limit loses one model, not the run.
#
# Start (survives the terminal closing):
#   cd <this folder> && setsid nohup sh run_box_test.sh > run.out 2>&1 < /dev/null &
# Check:   cat results/STATUS         (one line per step; "ALL_DONE" at the end)
# Stop:    kill -- -$(cat results/PID)   (whole process group; needs the setsid start)
# Re-run:  same start command; models whose results/<tag>/bench.json exists are skipped.
#
# Settings (environment variables):
#   SIZE      model input HxW, default 384x640 (the live camera shape)
#   RUNS      timed NPU runs per model, default 100
#   THREADS   onnxruntime threads for the CPU tail, default 1 (also run with 2 to see the gain)
#   PY        python with rknnlite 2.3.2 + numpy + cv2 + onnxruntime, default python3
#   MIN_MB    minimum free memory to start each model, default 500
#   FORCE     1 = run even if a preflight check fails (the failure is still recorded)
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
cd "$HERE" || exit 1
R=$HERE/results
mkdir -p "$R"
echo $$ > "$R/PID"

PY=${PY:-python3}
SIZE=${SIZE:-384x640}
RUNS=${RUNS:-100}
THREADS=${THREADS:-1}
MIN_MB=${MIN_MB:-500}
FORCE=${FORCE:-0}

status() { echo "$(date '+%Y-%m-%dT%H:%M:%S') $*" | tee -a "$R/STATUS"; }

free_mb() {  # smaller of the host's MemAvailable and the cgroup headroom (limit - current), in MB
  host=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
  lim=$(cat /sys/fs/cgroup/memory.max 2>/dev/null || cat /sys/fs/cgroup/memory/memory.limit_in_bytes 2>/dev/null || echo max)
  cur=$(cat /sys/fs/cgroup/memory.current 2>/dev/null || cat /sys/fs/cgroup/memory/memory.usage_in_bytes 2>/dev/null || echo 0)
  case $lim in max|"") echo "$host"; return ;; esac
  cg=$(( (lim - cur) / 1048576 ))
  [ "$cg" -lt "$host" ] && echo "$cg" || echo "$host"
}

# ---- preflight -------------------------------------------------------------------------------
status "START size=$SIZE runs=$RUNS threads=$THREADS"
fail=0
{
  echo "===== preflight $(date)"; echo "host: $(uname -a)"
  echo "--- files"; sha256sum -c SHA256SUMS --quiet && echo SUMS_OK || { echo SUMS_FAILED; }
  echo "--- python"; $PY -c "import numpy, cv2; from rknnlite.api import RKNNLite; print('numpy', numpy.__version__, 'cv2', cv2.__version__, 'rknnlite OK')" 2>&1
  $PY -c "import onnxruntime; print('ORT_OK', onnxruntime.__version__)" 2>&1 || echo ORT_MISSING
  echo "--- live service detector setting"; env | grep -E 'EDGEVISION_YOLOX_INPUT_HW|EDGEVISION_KEEP_SHAPE' || echo "(not set in this shell)"
  echo "--- memory (MB free for this test): $(free_mb)"; free -m 2>/dev/null
  echo "--- cpu"; nproc 2>/dev/null; cat /proc/loadavg 2>/dev/null
  echo "--- npu"; cat /sys/kernel/debug/rknpu/load /sys/kernel/debug/rknpu/freq 2>/dev/null || echo "(npu debugfs not readable)"
} > "$R/preflight_last.txt" 2>&1
cat "$R/preflight_last.txt" >> "$R/preflight.txt"  # keep every attempt

grep -q SUMS_OK "$R/preflight_last.txt" || { status "PREFLIGHT_FAIL files: checksum mismatch (see results/preflight.txt)"; fail=1; }
grep -q '^numpy .* rknnlite OK' "$R/preflight_last.txt" || { status "PREFLIGHT_FAIL python: rknnlite/numpy/cv2 missing (see results/preflight.txt)"; fail=1; }
grep -q '^ORT_OK' "$R/preflight_last.txt" || { status "PREFLIGHT_FAIL python: onnxruntime missing (RTMO needs it for the CPU tail)"; fail=1; }
[ "$(free_mb)" -ge "$MIN_MB" ] || { status "PREFLIGHT_FAIL memory: $(free_mb) MB free < $MIN_MB"; fail=1; }
if [ "$fail" -ne 0 ] && [ "$FORCE" != 1 ]; then
  status "STOPPED at preflight; nothing ran. Options: fix the listed item, or FORCE=1 to run anyway."
  status "ALL_DONE"; exit 2
fi
status "PREFLIGHT_OK"

# ---- models, in priority order: tag body.rknn tail.onnx -------------------------------------
MODELS="int8 rtmo_s_384x640_int8.rknn rtmo_tail_cpu_thr03.onnx
fp16 rtmo_s_384x640_fp16.rknn rtmo_tail_cpu_thr03.onnx
int8_tail2threads rtmo_s_384x640_int8.rknn rtmo_tail_cpu_thr03.onnx"

echo "$MODELS" | while read -r tag body tail; do
  [ -n "$tag" ] || continue
  out=$R/$tag
  if [ -f "$out/bench.json" ]; then status "SKIP $tag (already done)"; continue; fi
  if [ ! -f "$body" ] || [ ! -f "$tail" ]; then status "SKIP $tag (file not in package)"; continue; fi
  if [ "$(free_mb)" -lt "$MIN_MB" ] && [ "$FORCE" != 1 ]; then status "SKIP $tag (only $(free_mb) MB free)"; continue; fi
  threads=$THREADS; case $tag in *2threads) threads=2 ;; esac
  mkdir -p "$out"
  status "RUN $tag"
  $PY "$HERE/bench_rtmo.py" --model "$HERE/$body,$HERE/$tail" --size "$SIZE" --images "$HERE/images" \
    --out "$out" --runs "$RUNS" --tail-threads "$threads" > "$out/run.log" 2>&1
  rc=$?
  if [ "$rc" -eq 0 ] && [ -f "$out/bench.json" ]; then status "DONE $tag"; else status "FAILED $tag exit=$rc (see results/$tag/run.log)"; fi
done

# ---- summary + checksums for the copy off the box --------------------------------------------
$PY - "$R" > "$R/summary.txt" 2>&1 <<'EOF'
import json, sys
from pathlib import Path
r = Path(sys.argv[1])
print(f"{'run':20s} {'npu p50':>8s} {'npu p95':>8s} {'tail p50':>9s} {'tail p95':>9s} {'tail/person':>12s} {'frame p50':>10s} {'people':>7s} {'peak MB':>8s}")
for b in sorted(r.glob("*/bench.json")):
    d = json.loads(b.read_text())
    m = list(d["models"].values())[0]
    g = lambda k, q="p50": (m.get(k) or {}).get(q, float("nan"))
    print(f"{b.parent.name:20s} {g('npu_ms'):8.1f} {g('npu_ms','p95'):8.1f} {g('cpu_tail_ms'):9.1f} {g('cpu_tail_ms','p95'):9.1f} "
          f"{g('cpu_tail_ms_per_person'):12.2f} {g('frame_ms_including_cpu'):10.1f} {g('people_per_frame','mean'):7.2f} {d['peak_rss_kb'] / 1024:8.0f}")
EOF
cat "$R/summary.txt"
(cd "$R" && find . -type f ! -name RESULTS_SHA256 ! -name PID ! -name preflight_last.txt ! -name STATUS | sort | xargs sha256sum > RESULTS_SHA256)
status "RESULTS folder for Eddy: $R ($(du -sh "$R" | cut -f1))"
status "ALL_DONE"
