set -eu
DIR=$1
K=/usr/local/sbin/ared-kubectl
"$K" -n camera-solution get deployment camera-ai-worker -o json > "$DIR/deployment.json"
SEL=$(python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); s=d["spec"]["selector"]; assert not s.get("matchExpressions"),"Unsupported selector"; print(",".join(k+"="+v for k,v in sorted(s["matchLabels"].items())))' "$DIR/deployment.json")
"$K" -n camera-solution get pods -l "$SEL" -o json > "$DIR/pods-before.json"
P=$(python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); p=[x for x in d["items"] if not x["metadata"].get("deletionTimestamp") and any(c["type"]=="Ready" and c["status"]=="True" for c in x["status"].get("conditions",[]))]; assert len(p)==1,"Expected exactly one ready worker"; print(p[0]["metadata"]["name"])' "$DIR/pods-before.json")
REMOTE=/tmp/$(basename "$DIR")
"$K" -n camera-solution exec -i "$P" -- sh -s -- "$REMOTE" > "$DIR/frames.tar.partial" <<'REMOTE'
set -eu
OUT=$1
mkdir -m 700 "$OUT"
command -v frame-extractor-helper > "$OUT/helper-path.txt"
command -v timeout > /dev/null
for CASE in hardware-first hardware-guarded software-guarded
do
DECODER='mppvideodec ! video/x-raw,format=NV12'
PARSER='h265parse disable-passthrough=true ! video/x-h265,stream-format=byte-stream,alignment=au'
COUNT=3
GUARD=true
if [ "$CASE" = hardware-first ]; then COUNT=1; GUARD=false; fi
if [ "$CASE" = software-guarded ]; then DECODER=libde265dec; PARSER=h265parse; fi
PIPELINE="rtspsrc location=rtsp://go2rtc:8554/cam_ad146364-2126-4434-84bc-5dd76446727b protocols=tcp latency=100 ! rtph265depay ! $PARSER ! $DECODER ! videoconvert ! videoscale ! video/x-raw,format=BGR,width=640,height=640 ! appsink name=appsink emit-signals=false sync=false max-buffers=1 drop=true"
printf '{"pipeline":"%s","timeout_seconds":12,"options":{"max_frame_candidates":%s,"require_valid_quality_frame":%s},"output_path":"%s/%s.bgr"}\n' "$PIPELINE" "$COUNT" "$GUARD" "$OUT" "$CASE" > "$OUT/$CASE-request.json"
printf 'Capturing %s\n' "$CASE" >&2
RC=0
timeout -k 3 20 frame-extractor-helper < "$OUT/$CASE-request.json" > "$OUT/$CASE.json" 2> "$OUT/$CASE.log" || RC=$?
printf '%s\n' "$RC" > "$OUT/$CASE.exit"
done
tar -C "$OUT" -cf - .
REMOTE
mv "$DIR/frames.tar.partial" "$DIR/frames.tar"
"$K" -n camera-solution get pod "$P" -o json > "$DIR/pod-after.json"
python3 - "$DIR" <<'PY'
import json,sys,tarfile,zipfile
from pathlib import Path
folder=Path(sys.argv[1])
archive=tarfile.open(folder/"frames.tar")
members=[m for m in archive.getmembers() if m.isfile()]
assert all(not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in members),"Unsafe archive path"
files={Path(m.name).name:archive.extractfile(m).read() for m in members}
print("\nDECODER RESULTS")
for case in ("hardware-first","hardware-guarded","software-guarded"):
 print("\n"+case)
 print("Helper exit:",files.get(case+".exit",b"missing").decode().strip())
 raw=files.get(case+".bgr",b"")
 print("Saved pixel bytes:",len(raw),"expected:",640*640*3)
 print("Helper report:",files.get(case+".json",b"missing").decode(errors="replace"))
 print("Helper log:",files.get(case+".log",b"").decode(errors="replace")[-4000:])
before=json.loads((folder/"pods-before.json").read_text())
after=json.loads((folder/"pod-after.json").read_text())
prior=next(p for p in before["items"] if p["metadata"]["uid"]==after["metadata"]["uid"])
identity=lambda p:sorted((c["name"],c.get("containerID"),c.get("restartCount")) for c in p["status"].get("containerStatuses",[]))
print("\nCONTAINER IDENTITY UNCHANGED:",identity(prior)==identity(after))
output=folder/"frame-root-cause.zip"
z=zipfile.ZipFile(output,"x",zipfile.ZIP_DEFLATED)
for name,data in files.items():
 z.writestr("frames/"+name,data)
for name in ("deployment.json","pods-before.json","pod-after.json"):
 z.write(folder/name,name)
z.close()
archive.close()
print("\nCOMPLETE:",output)
PY
