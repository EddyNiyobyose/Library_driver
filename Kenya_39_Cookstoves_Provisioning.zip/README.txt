ARED gateway-owned cookstove provisioning package

Port 1883 is factory/testing transport only.
Port 8883 with production-ca.crt is the production configuration. The public CA
certificate is required for 8883. No TLS client certificate or client private key
is required. Enable certificate-chain and MQTT-hostname verification; never use an
insecure/skip-verify option. The CA private key and MQTT broker private key must
never be provided.

This credential is shared by cookstoves assigned to this gateway. Credentials from
one gateway must not be installed on cookstoves assigned to another gateway. The
factory system is responsible for securely writing these values into the cookstove.
The Edge API cannot directly flash or configure the MCU.

For a physical EPC, the MQTT Client ID MUST equal the exact device_id; never
append a random or boot identifier. The telemetry, meta, event, and lwt topics are
publish topics. The exact control topic is the subscribe topic; physical EPCs must
not use wildcard subscriptions. Factory workstation and synthetic publishers use
a separate ephemeral factory-workstation-<uuid> Client ID and cannot subscribe as
the physical device. The approved acceptance emulator is the sole exception: only
for its registered synthetic fixture and active test session, it uses the exact
device_id because it is emulating the physical EPC contract. Wildcard and
cross-device subscriptions remain denied.
