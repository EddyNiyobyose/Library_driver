#!/usr/bin/env python3
"""Sustained-load test on the RK3568 box for RTMO-s (read-only: writes only --out, loads models read-only).

Roles (the shell runs them as separate processes, in parallel where needed):
  sys   samples the whole box every 0.5 s: CPU busy % (/proc/stat), load average, MemAvailable
  det   YOLOX probe: the deployed detector .rknn, timed at --rate per second (default 1 = one camera at 1 fps);
        its latency with and without RTMO running shows how much RTMO slows the live detector
  pose  RTMO-s body + CPU tail at --rate frames per second (default 2.5 = 5 cameras x 0.5 fps), cycling the
        test photos; records per-frame NPU / CPU-tail / total ms, own CPU time (% of one core), peak memory
Each role stops after --seconds. Usage:
  python3 load_rtmo.py --role pose --body b.rknn --tail t.onnx --images DIR --rate 2.5 --seconds 120 --out f.json
  python3 load_rtmo.py --role det  --body yolox.rknn --images DIR --rate 1 --seconds 120 --out f.json
  python3 load_rtmo.py --role sys  --seconds 120 --out f.json
"""
from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path


def cpu_times():
    v = [int(x) for x in Path("/proc/stat").read_text().splitlines()[0].split()[1:]]
    idle = v[3] + (v[4] if len(v) > 4 else 0)
    return sum(v), idle


def mem_avail_mb():
    for line in Path("/proc/meminfo").read_text().splitlines():
        if line.startswith("MemAvailable:"):
            return int(line.split()[1]) // 1024
    return -1


def vm_hwm_kb():
    for line in Path("/proc/self/status").read_text().splitlines():
        if line.startswith("VmHWM:"):
            return int(line.split()[1])
    return -1


def pct(values, p):
    s = sorted(values)
    if not s:
        return None
    k = (len(s) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(s) - 1)
    return round(s[lo] + (s[hi] - s[lo]) * (k - lo), 2)


def stats(values):
    return {"p50": pct(values, 0.5), "p95": pct(values, 0.95), "max": round(max(values), 2) if values else None, "n": len(values)}


def frames(images, h, w):
    import cv2
    import numpy as np
    out = []
    for p in sorted(Path(images).glob("*.jpg")):
        f = cv2.imread(str(p))
        r = min(h / f.shape[0], w / f.shape[1])
        c = np.full((h, w, 3), 114, np.uint8)
        c[:int(f.shape[0] * r), :int(f.shape[1] * r)] = cv2.resize(f, (int(f.shape[1] * r), int(f.shape[0] * r)))
        out.append(c[None])
    return out


def paced(rate, seconds, step):
    """Call step() at a fixed rate; a call that is late starts at once (no catch-up burst); counts late starts."""
    period, t_end, k, late = 1.0 / rate, time.time() + seconds, 0, 0
    start = time.time()
    while True:
        due = start + k * period
        if due >= t_end:
            break
        now = time.time()
        if now < due:
            time.sleep(due - now)
        elif now - due > period:
            late += 1
            start, k = now, 0  # re-anchor instead of bursting
        step()
        k += 1
    return late


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--role", choices=("sys", "det", "pose"), required=True)
    ap.add_argument("--body"); ap.add_argument("--tail"); ap.add_argument("--images")
    ap.add_argument("--size", default="384x640"); ap.add_argument("--rate", type=float, default=1.0)
    ap.add_argument("--seconds", type=float, default=120); ap.add_argument("--tail-threads", type=int, default=1)
    ap.add_argument("--score", type=float, default=0.3); ap.add_argument("--out", required=True)
    a = ap.parse_args()
    rep = {"role": a.role, "started": time.time(), "rate": a.rate, "seconds": a.seconds, "body": a.body, "tail": a.tail}

    if a.role == "sys":
        rows, (t0, i0) = [], cpu_times()
        end = time.time() + a.seconds
        while time.time() < end:
            time.sleep(0.5)
            t1, i1 = cpu_times()
            rows.append([round(time.time(), 2), round(100.0 * (1 - (i1 - i0) / max(1, t1 - t0)), 1), os.getloadavg()[0], mem_avail_mb()])
            t0, i0 = t1, i1
        rep.update({"samples": rows, "cpu_busy_pct": stats([r[1] for r in rows]), "load1": stats([r[2] for r in rows]),
                    "mem_avail_mb_min": min(r[3] for r in rows)})
    else:
        import numpy as np
        from rknnlite.api import RKNNLite
        h, w = (int(v) for v in a.size.lower().split("x"))
        xs = frames(a.images, h, w)
        rk = RKNNLite(verbose=False)
        assert rk.load_rknn(a.body) == 0 and rk.init_runtime() == 0, f"cannot load {a.body}"
        tail = None
        if a.role == "pose":
            import onnxruntime as ort
            so = ort.SessionOptions(); so.intra_op_num_threads = so.inter_op_num_threads = a.tail_threads
            tail = ort.InferenceSession(a.tail, sess_options=so, providers=["CPUExecutionProvider"])
            names, shapes = [i.name for i in tail.get_inputs()], [i.shape for i in tail.get_inputs()]
        for x in xs[:3]:
            rk.inference(inputs=[x])  # warm-up
        rows, k = [], [0]

        def step():
            x = xs[k[0] % len(xs)]; k[0] += 1
            t0 = time.perf_counter()
            raw = rk.inference(inputs=[x])
            t1 = time.perf_counter()
            row = [round(time.time(), 3), round((t1 - t0) * 1000, 2)]
            if tail is not None:
                dets, _ = tail.run(None, dict(zip(names, [np.asarray(r, np.float32).reshape(s) for r, s in zip(raw, shapes)])))
                t2 = time.perf_counter()
                row += [round((t2 - t1) * 1000, 2), round((t2 - t0) * 1000, 2), int((dets[0, :, 4] >= a.score).sum())]
            rows.append(row)

        c0, w0 = os.times(), time.time()
        late = paced(a.rate, a.seconds, step)
        c1, w1 = os.times(), time.time()
        rk.release()
        rep.update({"frames": len(rows), "late_starts": late, "npu_ms": stats([r[1] for r in rows]),
                    "own_cpu_pct_of_one_core": round(100 * ((c1.user - c0.user) + (c1.system - c0.system)) / (w1 - w0), 1),
                    "peak_rss_mb": round(vm_hwm_kb() / 1024, 1), "rows": rows})
        if tail is not None:
            rep.update({"cpu_tail_ms": stats([r[2] for r in rows]), "frame_ms": stats([r[3] for r in rows]),
                        "people_mean": round(sum(r[4] for r in rows) / max(1, len(rows)), 2)})
    rep["finished"] = time.time()
    Path(a.out).write_text(json.dumps(rep))
    print(json.dumps({k: v for k, v in rep.items() if k not in ("rows", "samples")}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
