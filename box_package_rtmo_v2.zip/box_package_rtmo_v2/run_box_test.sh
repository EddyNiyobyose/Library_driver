#!/bin/sh
# RTMO-s benchmark v2 on the RK3568 box: smaller CPU tails (fewer DCC bins, people cap), exact NPU-body rewrites,
# timing cuts of the body, and a sustained 5-camera load test next to the live service. Read-only test.
#
# Writes only inside this folder (results/). Loads the .rknn/.onnx files read-only, installs nothing,
# changes no configuration, starts or restarts no service. Each model runs in its own python process,
# so a crash or a full memory limit loses one model, not the run.
#
# Start (survives the terminal closing):
#   cd <this folder> && setsid nohup sh run_box_test.sh > run.out 2>&1 < /dev/null &
# Check:   cat results/STATUS         (one line per step; "ALL_DONE" at the end)
# Stop:    kill -- -$(cat results/PID)   (whole process group; needs the setsid start)
# Re-run:  same start command; models whose results/<tag>/bench.json exists are skipped.
#
# Settings (environment variables):
#   SIZE      model input HxW, default 384x640 (the live camera shape)
#   RUNS      timed NPU runs per model, default 100
#   THREADS   default onnxruntime threads for the CPU tail (each model line sets its own)
#   PY        python with rknnlite 2.3.2 + numpy + cv2 + onnxruntime, default python3
#   MIN_MB    minimum free memory to start each model, default 500
#   FORCE     1 = run even if a preflight check fails (the failure is still recorded)
#   DET       deployed detector .rknn, loaded read-only for the YOLOX probe in the load test
#             (default /app/rknn_weights/yolox_tiny_int8_384x640.rknn; probe skipped if missing)
#   LOAD      0 = skip the load test (default 1); LOAD_SECONDS default 120
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
cd "$HERE" || exit 1
R=$HERE/results
mkdir -p "$R"
echo $$ > "$R/PID"

PY=${PY:-python3}
SIZE=${SIZE:-384x640}
RUNS=${RUNS:-100}
THREADS=${THREADS:-1}
MIN_MB=${MIN_MB:-500}
FORCE=${FORCE:-0}
DET=${DET:-/app/rknn_weights/yolox_tiny_int8_384x640.rknn}
LOAD=${LOAD:-1}
LOAD_SECONDS=${LOAD_SECONDS:-120}

status() { echo "$(date '+%Y-%m-%dT%H:%M:%S') $*" | tee -a "$R/STATUS"; }

free_mb() {  # smaller of the host's MemAvailable and the cgroup headroom (limit - current), in MB
  host=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
  lim=$(cat /sys/fs/cgroup/memory.max 2>/dev/null || cat /sys/fs/cgroup/memory/memory.limit_in_bytes 2>/dev/null || echo max)
  cur=$(cat /sys/fs/cgroup/memory.current 2>/dev/null || cat /sys/fs/cgroup/memory/memory.usage_in_bytes 2>/dev/null || echo 0)
  case $lim in max|"") echo "$host"; return ;; esac
  cg=$(( (lim - cur) / 1048576 ))
  [ "$cg" -lt "$host" ] && echo "$cg" || echo "$host"
}

# ---- preflight -------------------------------------------------------------------------------
status "START size=$SIZE runs=$RUNS threads=$THREADS"
fail=0
{
  echo "===== preflight $(date)"; echo "host: $(uname -a)"
  echo "--- files"; sha256sum -c SHA256SUMS --quiet && echo SUMS_OK || { echo SUMS_FAILED; }
  echo "--- python"; $PY -c "import numpy, cv2; from rknnlite.api import RKNNLite; print('numpy', numpy.__version__, 'cv2', cv2.__version__, 'rknnlite OK')" 2>&1
  $PY -c "import onnxruntime; print('ORT_OK', onnxruntime.__version__)" 2>&1 || echo ORT_MISSING
  echo "--- live service detector setting"; env | grep -E 'EDGEVISION_YOLOX_INPUT_HW|EDGEVISION_KEEP_SHAPE' || echo "(not set in this shell)"
  echo "--- memory (MB free for this test): $(free_mb)"; free -m 2>/dev/null
  echo "--- cpu"; nproc 2>/dev/null; cat /proc/loadavg 2>/dev/null
  echo "--- npu"; cat /sys/kernel/debug/rknpu/load /sys/kernel/debug/rknpu/freq 2>/dev/null || echo "(npu debugfs not readable)"
  for f in /sys/class/devfreq/*; do [ -d "$f" ] && echo "devfreq $(basename "$f"): cur $(cat "$f/cur_freq" 2>/dev/null) max $(cat "$f/max_freq" 2>/dev/null) governor $(cat "$f/governor" 2>/dev/null)"; done
  echo "--- detector for the probe: $DET"; [ -f "$DET" ] && echo DET_OK || echo DET_MISSING
} > "$R/preflight_last.txt" 2>&1
cat "$R/preflight_last.txt" >> "$R/preflight.txt"  # keep every attempt

grep -q SUMS_OK "$R/preflight_last.txt" || { status "PREFLIGHT_FAIL files: checksum mismatch (see results/preflight.txt)"; fail=1; }
grep -q '^numpy .* rknnlite OK' "$R/preflight_last.txt" || { status "PREFLIGHT_FAIL python: rknnlite/numpy/cv2 missing (see results/preflight.txt)"; fail=1; }
grep -q '^ORT_OK' "$R/preflight_last.txt" || { status "PREFLIGHT_FAIL python: onnxruntime missing (RTMO needs it for the CPU tail)"; fail=1; }
[ "$(free_mb)" -ge "$MIN_MB" ] || { status "PREFLIGHT_FAIL memory: $(free_mb) MB free < $MIN_MB"; fail=1; }
if [ "$fail" -ne 0 ] && [ "$FORCE" != 1 ]; then
  status "STOPPED at preflight; nothing ran. Options: fix the listed item, or FORCE=1 to run anyway."
  status "ALL_DONE"; exit 2
fi
status "PREFLIGHT_OK"

# ---- models, in priority order: tag body.rknn tail.onnx threads ------------------------------
# now = the v1 tail (box reference, same day); b48 = 48x64 decoder bins (was 192x256); c10 = top 10 people decoded.
# sppf / focus = same maths, NPU-friendlier graph (SPP pools as 5x5 chains; Focus stem as one 6x6 conv).
# cut1/2/3 = the body up to the backbone / encoder / head convs, NPU time only (no tail): full minus cuts = cost per part.
MODELS="now_1t rtmo_s_384x640_int8.rknn rtmo_tail_now.onnx 1
b48c10_1t rtmo_s_384x640_int8.rknn rtmo_tail_b48c10.onnx 1
b48_1t rtmo_s_384x640_int8.rknn rtmo_tail_b48.onnx 1
b48c10_2t rtmo_s_384x640_int8.rknn rtmo_tail_b48c10.onnx 2
sppf_b48c10_1t rtmo_s_384x640_int8_sppf.rknn rtmo_tail_b48c10.onnx 1
focus_b48c10_1t rtmo_s_384x640_int8_focus.rknn rtmo_tail_b48c10.onnx 1
sppffocus_b48c10_1t rtmo_s_384x640_int8_sppf_focus.rknn rtmo_tail_b48c10.onnx 1
cut1_backbone rtmo_cut1_backbone.rknn - 1
cut2_encoder rtmo_cut2_encoder.rknn - 1
cut3_heads rtmo_cut3_heads.rknn - 1
b48_2t rtmo_s_384x640_int8.rknn rtmo_tail_b48.onnx 2
b32c10_1t rtmo_s_384x640_int8.rknn rtmo_tail_b32c10.onnx 1"

echo "$MODELS" | while read -r tag body tail threads; do
  [ -n "$tag" ] || continue
  out=$R/$tag
  if [ -f "$out/bench.json" ]; then status "SKIP $tag (already done)"; continue; fi
  if [ ! -f "$body" ] || { [ "$tail" != - ] && [ ! -f "$tail" ]; }; then status "SKIP $tag (file not in package)"; continue; fi
  spec="$HERE/$body"; [ "$tail" = - ] || spec="$HERE/$body,$HERE/$tail"
  if [ "$(free_mb)" -lt "$MIN_MB" ] && [ "$FORCE" != 1 ]; then status "SKIP $tag (only $(free_mb) MB free)"; continue; fi
  mkdir -p "$out"
  status "RUN $tag"
  $PY "$HERE/bench_rtmo.py" --model "$spec" --size "$SIZE" --images "$HERE/images"     --out "$out" --runs "$RUNS" --tail-threads "${threads:-$THREADS}" > "$out/run.log" 2>&1
  rc=$?
  if [ "$rc" -eq 0 ] && [ -f "$out/bench.json" ]; then status "DONE $tag"; else status "FAILED $tag exit=$rc (see results/$tag/run.log)"; fi
done

# ---- sustained load next to the live service (5 cameras x 0.5 fps pose = 2.5 frames/s) -----------------------
# L0: box alone (live service only), 30 s. L1: YOLOX probe 1/s alone. L2: YOLOX probe + RTMO 2.5/s together.
# Probe = the deployed detector loaded read-only; its latency L1 vs L2 = how much RTMO slows the detector.
LB=${LOAD_BODY:-rtmo_s_384x640_int8.rknn}; LT=${LOAD_TAIL:-rtmo_tail_b48c10.onnx}
if [ "$LOAD" = 1 ] && [ ! -f "$R/load/L2_pose.json" ]; then
  mkdir -p "$R/load"
  if [ "$(free_mb)" -lt "$MIN_MB" ] && [ "$FORCE" != 1 ]; then status "SKIP load test (only $(free_mb) MB free)"; else
    status "RUN load L0 (box alone 30 s)"
    $PY "$HERE/load_rtmo.py" --role sys --seconds 30 --out "$R/load/L0_sys.json" > "$R/load/L0.log" 2>&1
    if [ -f "$DET" ]; then
      status "RUN load L1 (YOLOX probe 1/s alone, 60 s)"
      $PY "$HERE/load_rtmo.py" --role sys --seconds 60 --out "$R/load/L1_sys.json" > "$R/load/L1_sys.log" 2>&1 &
      $PY "$HERE/load_rtmo.py" --role det --body "$DET" --images "$HERE/images" --rate 1 --seconds 60 --out "$R/load/L1_det.json" > "$R/load/L1_det.log" 2>&1
      wait
    else status "SKIP YOLOX probe ($DET not found)"; fi
    status "RUN load L2 (RTMO 2.5/s $LB + $LT, with YOLOX probe if present, $LOAD_SECONDS s)"
    $PY "$HERE/load_rtmo.py" --role sys --seconds "$LOAD_SECONDS" --out "$R/load/L2_sys.json" > "$R/load/L2_sys.log" 2>&1 &
    [ -f "$DET" ] && $PY "$HERE/load_rtmo.py" --role det --body "$DET" --images "$HERE/images" --rate 1 --seconds "$LOAD_SECONDS" --out "$R/load/L2_det.json" > "$R/load/L2_det.log" 2>&1 &
    $PY "$HERE/load_rtmo.py" --role pose --body "$HERE/$LB" --tail "$HERE/$LT" --images "$HERE/images" --rate 2.5 --seconds "$LOAD_SECONDS" --out "$R/load/L2_pose.json" > "$R/load/L2_pose.log" 2>&1
    wait
    [ -f "$R/load/L2_pose.json" ] && status "DONE load" || status "FAILED load (see results/load/*.log)"
  fi
fi

# ---- summary + checksums for the copy off the box --------------------------------------------
$PY - "$R" > "$R/summary.txt" 2>&1 <<'EOF'
import json, sys
from pathlib import Path
r = Path(sys.argv[1])
print(f"{'run':20s} {'npu p50':>8s} {'npu p95':>8s} {'tail p50':>9s} {'tail p95':>9s} {'tail/person':>12s} {'frame p50':>10s} {'people':>7s} {'peak MB':>8s}")
for b in sorted(r.glob("*/bench.json")):
    d = json.loads(b.read_text())
    m = list(d["models"].values())[0]
    g = lambda k, q="p50": (m.get(k) or {}).get(q, float("nan"))
    print(f"{b.parent.name:20s} {g('npu_ms'):8.1f} {g('npu_ms','p95'):8.1f} {g('cpu_tail_ms'):9.1f} {g('cpu_tail_ms','p95'):9.1f} "
          f"{g('cpu_tail_ms_per_person'):12.2f} {g('frame_ms_including_cpu'):10.1f} {g('people_per_frame','mean'):7.2f} {d['peak_rss_kb'] / 1024:8.0f}")
L = r / "load"
def j(n):
    f = L / n
    return json.loads(f.read_text()) if f.exists() else None
for tag in ("L0", "L1", "L2"):
    s_, d_, p_ = j(f"{tag}_sys.json"), j(f"{tag}_det.json"), j(f"{tag}_pose.json")
    if not (s_ or d_ or p_):
        continue
    line = f"load {tag}:"
    if s_: line += f" box CPU busy p50 {s_['cpu_busy_pct']['p50']}% p95 {s_['cpu_busy_pct']['p95']}%, load1 p50 {s_['load1']['p50']}, min free {s_['mem_avail_mb_min']} MB;"
    if d_: line += f" YOLOX probe p50 {d_['npu_ms']['p50']} p95 {d_['npu_ms']['p95']} ms;"
    if p_: line += (f" RTMO npu p50 {p_['npu_ms']['p50']} p95 {p_['npu_ms']['p95']}, tail p50 {p_['cpu_tail_ms']['p50']} p95 {p_['cpu_tail_ms']['p95']},"
                    f" frame p95 {p_['frame_ms']['p95']} ms, own CPU {p_['own_cpu_pct_of_one_core']}% of 1 core, {p_['peak_rss_mb']} MB, late {p_['late_starts']}/{p_['frames']}")
    print(line)
EOF
cat "$R/summary.txt"
(cd "$R" && find . -type f ! -name RESULTS_SHA256 ! -name PID ! -name preflight_last.txt ! -name STATUS | sort | xargs sha256sum > RESULTS_SHA256)
status "RESULTS folder for Eddy: $R ($(du -sh "$R" | cut -f1))"
status "ALL_DONE"
