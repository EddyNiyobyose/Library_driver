#!/bin/sh
# Pose benchmark on the RK3568 box: one detached run, results saved per model. Read-only test.
#
# Writes only inside this folder (results/). Loads the .rknn files read-only, installs nothing,
# changes no configuration, starts or restarts no service. Each pose model runs in its own python
# process, in priority order, so a crash or a full memory limit loses one model, not the run.
#
# Start (survives the terminal closing):
#   cd <this folder> && DET=/app/rknn_weights/<deployed yolox tiny>.rknn nohup sh run_box_test.sh > run.out 2>&1 &
# Check:   cat results/STATUS         (one line per step; "ALL_DONE" at the end)
# Stop:    kill $(cat results/PID)
# Re-run:  same start command; models whose results/<model>/bench.json exists are skipped.
#
# Settings (environment variables):
#   DET       deployed YOLOX-Tiny INT8 .rknn (required; read in place, not copied)
#   DET_SIZE  detector input, default 384x640 (EDGEVISION_YOLOX_INPUT_HW of the live service)
#   DET_MODE  keepshape (live since GitOps #1273), letterbox or stretch
#   RUNS      timed NPU runs per model, default 100
#   PY        python with rknnlite 2.3.2 + numpy + cv2 + onnxruntime, default python3
#   EXTRA     1 = also run the body7 FP16 models
#   MIN_MB    minimum free memory to start each model, default 500
#   FORCE     1 = run even if a preflight check fails (the failure is still recorded)
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
cd "$HERE" || exit 1
R=$HERE/results
mkdir -p "$R"
echo $$ > "$R/PID"

PY=${PY:-python3}
DET=${DET:-}
DET_SIZE=${DET_SIZE:-384x640}
DET_MODE=${DET_MODE:-keepshape}
RUNS=${RUNS:-100}
EXTRA=${EXTRA:-0}
MIN_MB=${MIN_MB:-500}
FORCE=${FORCE:-0}

status() { echo "$(date '+%Y-%m-%dT%H:%M:%S') $*" | tee -a "$R/STATUS"; }

free_mb() {  # smaller of the host's MemAvailable and the cgroup headroom (limit - current), in MB
  host=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
  lim=$(cat /sys/fs/cgroup/memory.max 2>/dev/null || cat /sys/fs/cgroup/memory/memory.limit_in_bytes 2>/dev/null || echo max)
  cur=$(cat /sys/fs/cgroup/memory.current 2>/dev/null || cat /sys/fs/cgroup/memory/memory.usage_in_bytes 2>/dev/null || echo 0)
  case $lim in max|"") echo "$host"; return ;; esac
  cg=$(( (lim - cur) / 1048576 ))
  [ "$cg" -lt "$host" ] && echo "$cg" || echo "$host"
}

# ---- preflight -------------------------------------------------------------------------------
status "START det=$DET size=$DET_SIZE mode=$DET_MODE runs=$RUNS extra=$EXTRA"
fail=0
{
  echo "===== preflight $(date)"; echo "host: $(uname -a)"; uptime
  echo "--- files"; sha256sum -c SHA256SUMS --quiet && echo SUMS_OK || { echo SUMS_FAILED; }
  echo "--- python"; $PY -c "import numpy, cv2; from rknnlite.api import RKNNLite; print('numpy', numpy.__version__, 'cv2', cv2.__version__, 'rknnlite OK')" 2>&1
  $PY -c "import onnxruntime; print('ORT_OK', onnxruntime.__version__)" 2>&1 || echo ORT_MISSING
  echo "--- detector"; ls -la "$DET" 2>&1; sha256sum "$DET" 2>&1
  echo "--- live service detector setting"; env | grep -E 'EDGEVISION_YOLOX_INPUT_HW|EDGEVISION_KEEP_SHAPE' || echo "(not set in this shell)"
  echo "--- memory (MB free for this test): $(free_mb)"; free -m 2>/dev/null
  echo "--- npu"; cat /sys/kernel/debug/rknpu/load /sys/kernel/debug/rknpu/freq 2>/dev/null || echo "(npu debugfs not readable)"
} > "$R/preflight_last.txt" 2>&1
cat "$R/preflight_last.txt" >> "$R/preflight.txt"  # keep every attempt

grep -q SUMS_OK "$R/preflight_last.txt" || { status "PREFLIGHT_FAIL files: checksum mismatch (see results/preflight.txt)"; fail=1; }
grep -q '^numpy .* rknnlite OK' "$R/preflight_last.txt" || { status "PREFLIGHT_FAIL python: rknnlite/numpy/cv2 missing (see results/preflight.txt)"; fail=1; }
ORT=1; grep -q '^ORT_OK' "$R/preflight_last.txt" || { ORT=0; status "NOTE onnxruntime missing: split models (CPU head) skipped; full-NPU models still run"; }
[ -n "$DET" ] && [ -f "$DET" ] || { status "PREFLIGHT_FAIL detector: DET not set or not a file"; fail=1; }
[ "$(free_mb)" -ge "$MIN_MB" ] || { status "PREFLIGHT_FAIL memory: $(free_mb) MB free < $MIN_MB"; fail=1; }
if [ "$fail" -ne 0 ] && [ "$FORCE" != 1 ]; then
  status "STOPPED at preflight; nothing ran. Options: fix the listed item, or FORCE=1 to run anyway."
  status "ALL_DONE"; exit 2
fi
status "PREFLIGHT_OK"

# ---- models, in priority order: tag model.rknn head.onnx ("-" = full model on the NPU, no CPU head) --
# split = NPU body + float32 head in onnxruntime; full = whole RTMPose on the NPU (ScaleNorm FP16-safe rewrite)
MODELS="t_split_int8 rtmpose_t_coco_int8_mmse.rknn rtmpose_head_cpu_t_coco.onnx
s_split_int8 rtmpose_s_coco_int8_mmse.rknn rtmpose_head_cpu_s_coco.onnx
t_full_fp16 rtmpose_t_full_fp16.rknn -
s_full_fp16 rtmpose_s_full_fp16.rknn -
t_full_int8 rtmpose_t_full_int8_mmse.rknn -
s_full_int8 rtmpose_s_full_int8_mmse.rknn -
t_split_fp16 rtmpose_t_coco_fp16.rknn rtmpose_head_cpu_t_coco.onnx
s_split_fp16 rtmpose_s_coco_fp16.rknn rtmpose_head_cpu_s_coco.onnx"
if [ "$EXTRA" = 1 ]; then
  MODELS="$MODELS
t_body7_fp16 rtmpose_t_body7_fp16.rknn rtmpose_head_cpu_t_body7.onnx
s_body7_fp16 rtmpose_s_body7_fp16.rknn rtmpose_head_cpu_s_body7.onnx"
fi

echo "$MODELS" | while read -r tag body head; do
  [ -n "$tag" ] || continue
  out=$R/$tag
  if [ -f "$out/bench.json" ]; then status "SKIP $tag (already done)"; continue; fi
  if [ ! -f "$body" ]; then status "SKIP $tag (file $body not in package)"; continue; fi
  if [ "$head" != "-" ] && [ "$ORT" = 0 ]; then status "SKIP $tag (needs onnxruntime)"; continue; fi
  if [ "$(free_mb)" -lt "$MIN_MB" ] && [ "$FORCE" != 1 ]; then status "SKIP $tag (only $(free_mb) MB free)"; continue; fi
  spec=$body; [ "$head" != "-" ] && spec="$body,$head"
  mkdir -p "$out"
  status "RUN $tag"
  $PY "$HERE/bench_topdown.py" --det "$DET" --det-size "$DET_SIZE" --det-mode "$DET_MODE" \
    --pose "$HERE/$spec" --images "$HERE/images" --out "$out" --runs "$RUNS" > "$out/run.log" 2>&1
  rc=$?
  if [ "$rc" -eq 0 ] && [ -f "$out/bench.json" ]; then status "DONE $tag"; else status "FAILED $tag exit=$rc (see results/$tag/run.log)"; fi
done

# ---- summary + checksums for the copy off the box --------------------------------------------
$PY - "$R" > "$R/summary.txt" 2>&1 <<'EOF'
import json, sys
from pathlib import Path
r = Path(sys.argv[1])
print(f"{'model':18s} {'det npu p50':>11s} {'pose npu p50':>12s} {'head cpu p50':>12s} {'ms/person p50':>13s} {'ms/frame p50':>12s} {'people/frame':>12s} {'peak MB':>8s}")
for b in sorted(r.glob("*/bench.json")):
    d = json.loads(b.read_text())
    det, pose = list(d["models"].values())[0], list(d["models"].values())[-1]
    pipe = list(d["pipeline"].values())[0]
    g = lambda m, k: (m.get(k) or {}).get("p50", float("nan"))
    print(f"{b.parent.name:18s} {g(det, 'npu_ms'):11.1f} {g(pose, 'npu_ms'):12.1f} {g(pose, 'cpu_head_ms'):12.2f} "
          f"{g(pipe, 'person_crop_ms_including_cpu'):13.1f} {g(pipe, 'frame_ms_including_cpu'):12.1f} "
          f"{(pipe['people_per_frame'] or {}).get('mean', 0):12.2f} {d['peak_rss_kb'] / 1024:8.0f}")
EOF
cat "$R/summary.txt"
(cd "$R" && find . -type f ! -name RESULTS_SHA256 ! -name PID ! -name preflight_last.txt ! -name STATUS | sort | xargs sha256sum > RESULTS_SHA256)
status "RESULTS folder for Eddy: $R ($(du -sh "$R" | cut -f1))"
status "ALL_DONE"
