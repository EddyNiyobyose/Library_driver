#!/usr/bin/env python3
"""On-device RK3568 benchmark: YOLOX-Tiny + RTMPose-t RKNN models (RKNNLite 2.3.2). Read-only test.

Standalone on purpose (numpy + cv2 + rknnlite only, no repository imports) so a single file can be
placed in /tmp on the box, run, and deleted. It writes only inside --out (also under /tmp), loads the
given .rknn files read-only, changes no configuration and starts no service.

Measures, per model:
  * load + init time, N timed NPU inferences after warm-up -> mean / p50 / p95 / max latency
  * CPU post-processing time (YOLOX decode + NMS; RTMPose SimCC decode)
  * peak process RSS, NPU load samples (/sys/kernel/debug/rknpu/load), load average before/after
And, for the full pipeline on each test image (detector -> one RTMPose crop per person):
  * end-to-end ms per frame, people per frame, ms per person crop
  * raw outputs and decoded people per image (outputs.json) for comparison with the simulator

Usage (inside the EdgeVision container or any Python with rknnlite 2.3.2):
  python3 bench_topdown.py --det yolox_tiny_int8.rknn --pose rtmpose_t_body7_int8.rknn \
      --images /tmp/edgevision_pose_test/images --out /tmp/edgevision_pose_test/results [--runs 100]
"""
from __future__ import annotations

import argparse
import json
import os
import statistics
import threading
import time
from pathlib import Path

import cv2
import numpy as np

YOLOX_SIZE, CANONICAL_SIZE, NC = 416, 640, 80
POSE_W, POSE_H, SIMCC_SPLIT = 192, 256, 2.0


def npu_load() -> str:
    try:
        return Path("/sys/kernel/debug/rknpu/load").read_text().strip()
    except OSError:
        return "unavailable"


def vm_hwm_kb() -> int:
    try:
        for line in Path("/proc/self/status").read_text().splitlines():
            if line.startswith("VmHWM:"):
                return int(line.split()[1])
    except OSError:
        pass
    return -1


def loadavg():
    return os.getloadavg() if hasattr(os, "getloadavg") else None


def pct(values, p):
    s = sorted(values)
    k = (len(s) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(s) - 1)
    return s[lo] + (s[hi] - s[lo]) * (k - lo)


def summary(values):
    return {"mean": round(statistics.fmean(values), 3), "p50": round(pct(values, 0.5), 3),
            "p95": round(pct(values, 0.95), 3), "max": round(max(values), 3), "n": len(values)} if values else None


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -30, 30)))


def nms(boxes, scores, thr):
    order, keep = scores.argsort()[::-1], []
    while len(order):
        i = order[0]
        keep.append(i)
        r = order[1:]
        if not len(r):
            break
        xx1 = np.maximum(boxes[i, 0], boxes[r, 0]); yy1 = np.maximum(boxes[i, 1], boxes[r, 1])
        xx2 = np.minimum(boxes[i, 2], boxes[r, 2]); yy2 = np.minimum(boxes[i, 3], boxes[r, 3])
        inter = np.clip(xx2 - xx1, 0, None) * np.clip(yy2 - yy1, 0, None)
        a1 = (boxes[i, 2] - boxes[i, 0]) * (boxes[i, 3] - boxes[i, 1])
        a2 = (boxes[r, 2] - boxes[r, 0]) * (boxes[r, 3] - boxes[r, 1])
        order = r[inter / (a1 + a2 - inter + 1e-9) <= thr]
    return keep


def input_hw(size):
    """int -> square; (h, w) or "384x640" -> (h, w)."""
    if isinstance(size, str):
        parts = size.lower().split("x")
        return (int(parts[0]), int(parts[-1]))
    if isinstance(size, (tuple, list)):
        return int(size[0]), int(size[1])
    return int(size), int(size)


def decode_people(outs, conf=0.2, iou=0.45, size=YOLOX_SIZE):
    """9 YOLOX head tensors -> person rows [x1, y1, x2, y2, score] in model pixels (same math as yolox_decode.py)."""
    boxes, scores = [], []
    in_h, _ = input_hw(size)
    for level in range(3):
        reg, obj, cls = outs[3 * level], outs[3 * level + 1], outs[3 * level + 2]
        h, w = reg.shape[2], reg.shape[3]
        stride = in_h // h
        r = reg[0].reshape(4, -1).T.astype(np.float32)
        s = sigmoid(obj[0].reshape(-1).astype(np.float32)) * sigmoid(cls[0][0].reshape(-1).astype(np.float32))
        gy, gx = np.mgrid[0:h, 0:w]
        grid = np.stack([gx.ravel(), gy.ravel()], 1).astype(np.float32)
        xy, wh = (r[:, :2] + grid) * stride, np.exp(np.clip(r[:, 2:], -10, 8)) * stride
        boxes.append(np.concatenate([xy - wh / 2, xy + wh / 2], 1))
        scores.append(s)
    boxes, scores = np.concatenate(boxes), np.concatenate(scores)
    keep = scores > conf
    boxes, scores = boxes[keep], scores[keep]
    k = nms(boxes, scores, iou)[:100]
    return np.concatenate([boxes[k], scores[k, None]], 1) if len(k) else np.zeros((0, 5), np.float32)


def detector_input(frame, size=YOLOX_SIZE, mode="stretch"):
    """(BGR uint8 model input, (sx, sy)) with frame xy = model xy * (sx, sy).

    stretch: runtime geometry (receiver stretch to 640, then the YOLOX backend resize to `size`).
    letterbox: keep the aspect ratio, pad 114 bottom/right (the YOLOX pipeline's calibration geometry).
    keepshape: the 2026-10-28 live path (EdgeVision #119/#120): the worker sends 640 wide in the camera's
    own shape, the AI fits it into the (h, w) input top-left with grey 114 (yolox_backend._prepare).
    """
    h, w = frame.shape[:2]
    if mode == "keepshape":
        H, W = input_hw(size)
        sent = frame if w == 640 else cv2.resize(frame, (640, max(1, int(round(640 * h / w)))), interpolation=cv2.INTER_LINEAR)
        fh, fw = sent.shape[:2]
        r = min(W / float(fw), H / float(fh))
        nw, nh = max(1, min(W, int(round(fw * r)))), max(1, min(H, int(round(fh * r))))
        canvas = np.full((H, W, 3), 114, np.uint8)
        canvas[:nh, :nw] = sent if (nw, nh) == (fw, fh) else cv2.resize(sent, (nw, nh), interpolation=cv2.INTER_LINEAR)
        return canvas[None], (w / nw, h / nh)
    size = input_hw(size)[0]
    if mode == "letterbox":
        r = min(size / h, size / w)
        nh, nw = int(round(h * r)), int(round(w * r))
        canvas = np.full((size, size, 3), 114, np.uint8)
        canvas[:nh, :nw] = cv2.resize(frame, (nw, nh), interpolation=cv2.INTER_LINEAR)
        return canvas[None], (1.0 / r, 1.0 / r)
    canonical = cv2.resize(frame, (CANONICAL_SIZE, CANONICAL_SIZE), interpolation=cv2.INTER_LINEAR)
    return cv2.resize(canonical, (size, size), interpolation=cv2.INTER_LINEAR)[None], (w / size, h / size)


def pose_input(frame, box):
    x1, y1, x2, y2 = (float(v) for v in box[:4])
    cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
    w, h = (x2 - x1) * 1.25, (y2 - y1) * 1.25
    if w > h * POSE_W / POSE_H:
        h = w * POSE_H / POSE_W
    else:
        w = h * POSE_W / POSE_H
    src = np.array([[cx - w / 2, cy - h / 2], [cx + w / 2, cy - h / 2], [cx - w / 2, cy + h / 2]], np.float32)
    dst = np.array([[0, 0], [POSE_W, 0], [0, POSE_H]], np.float32)
    crop = cv2.warpAffine(frame, cv2.getAffineTransform(src, dst), (POSE_W, POSE_H), flags=cv2.INTER_LINEAR)
    return cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)[None], np.array([cx, cy], np.float32), np.array([w, h], np.float32)


def decode_pose(outs, center, scale):
    sx, sy = outs
    locs = np.stack([sx[0].argmax(-1), sy[0].argmax(-1)], -1).astype(np.float32) / SIMCC_SPLIT
    kpts = locs / np.array([POSE_W, POSE_H], np.float32) * scale + center - scale / 2
    return kpts, np.minimum(sx[0].max(-1), sy[0].max(-1))


def run_head(head, outs):
    """Split RTMPose (rtmpose_split.py): the NPU returns the final conv features, the float32 head gives simcc_x/y."""
    return head.run(None, {head.get_inputs()[0].name: np.asarray(outs[0], np.float32)}) if head is not None else outs


def load(path):
    from rknnlite.api import RKNNLite

    rk = RKNNLite(verbose=False)
    t0 = time.perf_counter()
    if rk.load_rknn(path) != 0 or rk.init_runtime() != 0:
        raise RuntimeError(f"cannot load {path} on the NPU")
    return rk, (time.perf_counter() - t0) * 1000.0


def timed(rk, x, warmup, runs):
    for _ in range(warmup):
        rk.inference(inputs=[x])
    lat = []
    for _ in range(runs):
        s = time.perf_counter()
        out = rk.inference(inputs=[x])
        lat.append((time.perf_counter() - s) * 1000.0)
    return lat, out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--det", required=True, help="YOLOX .rknn (9 head outputs): Tiny 416 or S 640")
    ap.add_argument("--det-size", default=str(YOLOX_SIZE), help="Detector input: 416 (square) or HxW, e.g. 384x640 (live since 2026-10-28)")
    ap.add_argument("--det-mode", default="stretch", choices=("stretch", "letterbox", "keepshape"))
    ap.add_argument("--pose", action="append", required=True,
                    help="RTMPose-t .rknn, or body.rknn,head.onnx for the split model (head runs in onnxruntime on the CPU); repeatable")
    ap.add_argument("--images", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--runs", type=int, default=100)
    ap.add_argument("--warmup", type=int, default=10)
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    images = sorted(p for p in Path(args.images).iterdir() if p.suffix.lower() in (".jpg", ".png"))
    report = {"started": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "loadavg_before": loadavg(), "npu_load_before": npu_load(),
              "models": {}, "pipeline": {}}
    samples, stop = [], threading.Event()

    def sampler():
        while not stop.is_set():
            samples.append({"t": round(time.time(), 1), "npu": npu_load(), "load1": (loadavg() or [None])[0]})
            time.sleep(0.5)

    threading.Thread(target=sampler, daemon=True).start()
    first = cv2.imread(str(images[0]))

    size, mode = input_hw(args.det_size), args.det_mode
    if size[0] != size[1] and mode != "keepshape":
        ap.error("a non-square detector input needs --det-mode keepshape")
    det, det_init = load(args.det)
    x, (sx, sy) = detector_input(first, size, mode)
    lat, outs = timed(det, x, args.warmup, args.runs)
    post = []
    for _ in range(20):
        s = time.perf_counter(); rows = decode_people(outs, size=size); post.append((time.perf_counter() - s) * 1000.0)
    report["models"][Path(args.det).name] = {"init_ms": round(det_init, 1), "npu_ms": summary(lat), "cpu_decode_ms": summary(post),
                                             "bytes": Path(args.det).stat().st_size, "input": size, "mode": mode}

    poses = {}
    for spec in args.pose:
        path, _, head_path = spec.partition(",")
        rk, init = load(path)
        head = None
        if head_path:
            import onnxruntime as ort

            so = ort.SessionOptions()
            so.intra_op_num_threads = so.inter_op_num_threads = 1  # one core: don't compete with the live services
            head = ort.InferenceSession(head_path, sess_options=so, providers=["CPUExecutionProvider"])
        box = [rows[0][0] * sx, rows[0][1] * sy, rows[0][2] * sx, rows[0][3] * sy] if len(rows) else [0, 0, first.shape[1], first.shape[0]]
        crop, center, scale = pose_input(first, box)
        lat, pouts = timed(rk, crop, args.warmup, args.runs)
        head_ms, post = [], []
        for _ in range(20 if head else 0):
            s = time.perf_counter(); run_head(head, pouts); head_ms.append((time.perf_counter() - s) * 1000.0)
        pouts = run_head(head, pouts)
        for _ in range(20):
            s = time.perf_counter(); decode_pose(pouts, center, scale); post.append((time.perf_counter() - s) * 1000.0)
        name = Path(path).name + (f"+{Path(head_path).name}" if head_path else "")
        report["models"][name] = {"init_ms": round(init, 1), "npu_ms": summary(lat), "cpu_head_ms": summary(head_ms),
                                  "cpu_decode_ms": summary(post), "bytes": Path(path).stat().st_size}
        poses[name] = (rk, head)

    per_image = []
    for name, (rk, head) in poses.items():
        frame_ms, person_ms, counts = [], [], []
        for img in images:
            frame = cv2.imread(str(img))
            t0 = time.perf_counter()
            x, (sx, sy) = detector_input(frame, size, mode)
            rows = decode_people(det.inference(inputs=[x]), size=size)
            people = []
            for row in rows:
                box = [min(max(row[0] * sx, 0), frame.shape[1]), min(max(row[1] * sy, 0), frame.shape[0]),
                       min(max(row[2] * sx, 0), frame.shape[1]), min(max(row[3] * sy, 0), frame.shape[0])]  # clipped like the runtime
                t1 = time.perf_counter()
                crop, center, scale = pose_input(frame, box)
                kpts, ks = decode_pose(run_head(head, rk.inference(inputs=[crop])), center, scale)
                person_ms.append((time.perf_counter() - t1) * 1000.0)
                people.append({"box": [round(v, 1) for v in box], "score": round(float(row[4]), 4),
                               "kpts": [[round(float(x), 1), round(float(y), 1), round(float(s), 3)] for (x, y), s in zip(kpts, ks)]})
            frame_ms.append((time.perf_counter() - t0) * 1000.0)
            counts.append(len(people))
            per_image.append({"pose_model": name, "image": img.name, "people": people})
        report["pipeline"][name] = {"frame_ms_including_cpu": summary(frame_ms), "person_crop_ms_including_cpu": summary(person_ms),
                                    "people_per_frame": summary(counts), "images": len(images)}
    stop.set()
    for rk in [det, *(r for r, _ in poses.values())]:
        rk.release()
    report.update({"finished": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "loadavg_after": loadavg(),
                   "peak_rss_kb": vm_hwm_kb(), "npu_load_samples": samples})
    (out / "bench.json").write_text(json.dumps(report, indent=2))
    (out / "outputs.json").write_text(json.dumps(per_image))
    print(json.dumps({k: v for k, v in report.items() if k != "npu_load_samples"}, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
