import sys
n=1228800
for i,b in enumerate(iter(lambda: sys.stdin.buffer.read(n), b'')): s=b[::97]; m=sum(s)/len(s); print(' frame',i,'mean',round(m),'std',round(pow(sum(pow(x-m,2) for x in s)/len(s),0.5),1),'bytes',len(b))
