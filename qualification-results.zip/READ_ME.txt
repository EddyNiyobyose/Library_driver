PERSON QUALIFICATION
Diagnostic results only; no model or production setting was changed.

Saved baseline: {'images': 742, 'gt': 1768, 'tp': 982, 'fp': 403, 'fn': 786, 'count_absolute_error': 851, 'precision': 0.7090252707581227, 'recall': 0.5554298642533937, 'count_mae': 1.146900269541779}

Gates:
accuracy_no_per_image_regression: FAIL
size_recall_no_regression: FAIL
speed_cpu_gain: FAIL
historical_baseline_reproducible: REVIEW
live_trace: PASS
isolated_backend_reliability: PASS

Unresolved coverage:
Labels were screened at preview resolution; completeness is not certified.
Close distance and partial-body classes lack verified dedicated labels.
No animal, pose, theft or restaurant service-time validation in this Person dataset.
Isolated notification checks do not certify browser delivery. Live invalid-frame recovery and multi-camera load still require exercised cases; empty-camera captures cannot pass them.
No approved business accuracy or end-to-end latency targets; conservative regression gates are diagnostic only.
This is a reused development set, not an independent held-out acceptance test.
