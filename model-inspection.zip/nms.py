import numpy as np
import time
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class NMSMetrics:
    raw_prediction_shape: tuple
    raw_box_count: int
    confidence_candidate_count: int
    pre_nms_candidate_count: int
    final_detection_count: int
    max_confidence: float
    nms_elapsed_ms: float
    nms_backend: str
    max_det: int
    max_nms: int
    conf_thres: float
    iou_thres: float

    def to_dict(self):
        data = asdict(self)
        data["raw_prediction_shape"] = [int(dim) for dim in self.raw_prediction_shape]
        return data


def _metrics_dict(**kwargs):
    return NMSMetrics(**kwargs).to_dict()


def _empty_like_np(x):
    return np.empty_like(x, dtype=np.float32)


def xywh2xyxy(x):
    assert x.shape[-1] == 4, f"input shape last dimension expected 4 but input shape is {x.shape}"
    y = _empty_like_np(x)
    xy = x[..., :2]
    wh = x[..., 2:] / 2
    y[..., :2] = xy - wh
    y[..., 2:] = xy + wh
    return y


def _nms_kernel_np(boxes, scores, iou_threshold):
    sorted_indices = np.argsort(scores)[::-1]
    
    keep_indices = []
    while sorted_indices.size > 0:
        current_index = sorted_indices[0]
        keep_indices.append(current_index.item())
        
        if sorted_indices.size == 1:
            break
            
        remaining_indices = sorted_indices[1:]
        
        current_box = boxes[current_index:current_index+1]
        remaining_boxes = boxes[remaining_indices]

        x1 = np.maximum(current_box[:, 0:1], remaining_boxes[:, 0])
        y1 = np.maximum(current_box[:, 1:2], remaining_boxes[:, 1])
        x2 = np.minimum(current_box[:, 2:3], remaining_boxes[:, 2])
        y2 = np.minimum(current_box[:, 3:4], remaining_boxes[:, 3])

        intersection_area = np.maximum(0, x2 - x1) * np.maximum(0, y2 - y1)

        area1 = (current_box[:, 2:3] - current_box[:, 0:1]) * (current_box[:, 3:4] - current_box[:, 1:2])
        area2 = (remaining_boxes[:, 2] - remaining_boxes[:, 0]) * (remaining_boxes[:, 3] - remaining_boxes[:, 1])
        
        union_area = area1 + area2 - intersection_area

        ious = (intersection_area / (union_area + 1e-6)).squeeze()
        
        boxes_to_keep = ious <= iou_threshold
        sorted_indices = remaining_indices[boxes_to_keep]

    return np.array(keep_indices, dtype=np.int64)


def normalize_yolo_prediction(prediction, nc=0):
    """Normalize YOLO raw output to NMS' expected BCH/BCN layout.

    non_max_suppression expects (batch, 4 + nc + masks, boxes). Some
    backends, including RKNN exports, can return the same tensor as
    (batch, boxes, 4 + nc + masks). Keep ONNX output unchanged and transpose
    backend output only when the channel dimension is clearly last.
    """
    if isinstance(prediction, (list, tuple)):
        prediction = prediction[0]

    prediction = np.asarray(prediction)
    if prediction.ndim == 2:
        prediction = np.expand_dims(prediction, 0)

    if prediction.ndim != 3:
        return prediction

    expected_channels = 4 + int(nc or 0)
    if nc and prediction.shape[-1] == expected_channels and prediction.shape[1] != expected_channels:
        if prediction.shape[-1] < prediction.shape[1]:
            return prediction.transpose(0, 2, 1)

    return prediction


def non_max_suppression(
    prediction,
    conf_thres=0.25,
    iou_thres=0.45,
    classes=None,
    agnostic=False,
    multi_label=False,
    labels=(),
    max_det=300,
    nc=0,
    max_time_img=0.05,
    max_nms=30000,
    max_wh=7680,
    in_place=True,
    rotated=False,
    return_metrics=False,
):
    assert 0 <= conf_thres <= 1, f"Invalid Confidence threshold {conf_thres}, valid values are between 0.0 and 1.0"
    assert 0 <= iou_thres <= 1, f"Invalid IoU {iou_thres}, valid values are between 0.0 and 1.0"
    prediction = normalize_yolo_prediction(prediction, nc=nc)
    raw_prediction_shape = tuple(int(dim) for dim in prediction.shape)
    if classes is not None:
        classes = np.array(classes)

    if prediction.shape[-1] == 6:
        nms_start = time.perf_counter()
        output = [pred[pred[:, 4] > conf_thres][:max_det] for pred in prediction]
        if classes is not None:
            output = [pred[(pred[:, 5:6] == classes).any(axis=1)] for pred in output]
        if return_metrics:
            elapsed = round((time.perf_counter() - nms_start) * 1000.0, 3)
            metrics = []
            for pred, det in zip(prediction, output):
                confidence_candidate_count = int(np.count_nonzero(pred[:, 4] > conf_thres))
                metrics.append(_metrics_dict(
                    raw_prediction_shape=raw_prediction_shape,
                    raw_box_count=int(pred.shape[0]),
                    confidence_candidate_count=confidence_candidate_count,
                    pre_nms_candidate_count=confidence_candidate_count,
                    final_detection_count=int(det.shape[0]),
                    max_confidence=float(np.max(pred[:, 4])) if pred.shape[0] else 0.0,
                    nms_elapsed_ms=elapsed,
                    nms_backend="numpy",
                    max_det=int(max_det),
                    max_nms=int(max_nms),
                    conf_thres=float(conf_thres),
                    iou_thres=float(iou_thres),
                ))
            return output, metrics
        return output

    bs = prediction.shape[0]
    nc = nc or (prediction.shape[1] - 4)
    nm = prediction.shape[1] - nc - 4
    mi = 4 + nc
    xc = prediction[:, 4:mi].max(axis=1) > conf_thres

    time_limit = 2.0 + max_time_img * bs
    multi_label &= nc > 1

    prediction = prediction.transpose(0, 2, 1)
    if not rotated:
        if in_place:
            prediction[..., :4] = xywh2xyxy(prediction[..., :4])
        else:
            prediction = np.concatenate((xywh2xyxy(prediction[..., :4]), prediction[..., 4:]), axis=-1)

    t = time.time()
    output = [np.zeros((0, 6 + nm), dtype=np.float32)] * bs
    metrics = []
    for xi, x in enumerate(prediction):
        image_nms_start = time.perf_counter()
        raw_box_count = int(x.shape[0])
        max_confidence = float(np.max(x[:, 4:mi])) if x[:, 4:mi].size else 0.0
        confidence_candidate_count = int(np.count_nonzero(xc[xi]))
        x = x[xc[xi]]
        pre_nms_candidate_count = 0

        if labels and len(labels[xi]) and not rotated:
            lb = labels[xi]
            v = np.zeros((len(lb), nc + nm + 4), dtype=np.float32)
            v[:, :4] = xywh2xyxy(lb[:, 1:5])
            v[range(len(lb)), lb[:, 0].astype(np.int64) + 4] = 1.0
            x = np.concatenate((x, v), 0)

        if not x.shape[0]:
            if return_metrics:
                metrics.append(_metrics_dict(raw_prediction_shape=raw_prediction_shape, raw_box_count=raw_box_count, confidence_candidate_count=confidence_candidate_count, pre_nms_candidate_count=0, final_detection_count=0, max_confidence=max_confidence, nms_elapsed_ms=round((time.perf_counter() - image_nms_start) * 1000.0, 3), nms_backend="numpy", max_det=int(max_det), max_nms=int(max_nms), conf_thres=float(conf_thres), iou_thres=float(iou_thres)))
            continue

        box, cls, mask = np.split(x, [4, 4 + nc], axis=1)

        if multi_label:
            i, j = np.where(cls > conf_thres)
            x = np.concatenate((box[i], x[i, 4 + j, None], j[:, None].astype(np.float32), mask[i]), 1)
        else:
            conf = np.max(cls, axis=1, keepdims=True)
            j = np.argmax(cls, axis=1, keepdims=True)
            x = np.concatenate((box, conf, j.astype(np.float32), mask), 1)[conf.reshape(-1) > conf_thres]

        if classes is not None:
            x = x[(x[:, 5:6] == classes).any(axis=1)]

        n = x.shape[0]
        pre_nms_candidate_count = int(n)
        if not n:
            if return_metrics:
                metrics.append(_metrics_dict(raw_prediction_shape=raw_prediction_shape, raw_box_count=raw_box_count, confidence_candidate_count=confidence_candidate_count, pre_nms_candidate_count=0, final_detection_count=0, max_confidence=max_confidence, nms_elapsed_ms=round((time.perf_counter() - image_nms_start) * 1000.0, 3), nms_backend="numpy", max_det=int(max_det), max_nms=int(max_nms), conf_thres=float(conf_thres), iou_thres=float(iou_thres)))
            continue
        if n > max_nms:
            x = x[np.argsort(x[:, 4])[::-1][:max_nms]]

        c = x[:, 5:6] * (0 if agnostic else max_wh)
        scores = x[:, 4]
        
        if rotated:
            raise NotImplementedError("Rotated NMS is not implemented in this pure-NumPy version.")
        else:
            boxes = x[:, :4] + c
            i = _nms_kernel_np(boxes, scores, iou_thres)
        
        i = i[:max_det]

        output[xi] = x[i]
        if return_metrics:
            metrics.append(_metrics_dict(raw_prediction_shape=raw_prediction_shape, raw_box_count=raw_box_count, confidence_candidate_count=confidence_candidate_count, pre_nms_candidate_count=pre_nms_candidate_count, final_detection_count=int(output[xi].shape[0]), max_confidence=max_confidence, nms_elapsed_ms=round((time.perf_counter() - image_nms_start) * 1000.0, 3), nms_backend="numpy", max_det=int(max_det), max_nms=int(max_nms), conf_thres=float(conf_thres), iou_thres=float(iou_thres)))
        
        if (time.time() - t) > time_limit:
            print(f"WARNING: NMS time limit {time_limit:.3f}s exceeded")
            break

    if return_metrics:
        while len(metrics) < bs:
            metrics.append(_metrics_dict(raw_prediction_shape=raw_prediction_shape, raw_box_count=0, confidence_candidate_count=0, pre_nms_candidate_count=0, final_detection_count=0, max_confidence=0.0, nms_elapsed_ms=0.0, nms_backend="numpy", max_det=int(max_det), max_nms=int(max_nms), conf_thres=float(conf_thres), iou_thres=float(iou_thres)))
        return output, metrics
    return output
"""
#Adapted from Ultralytics
import torch, math
import torch.nn as nn
import torch.nn.functional as F
import time

def bbox2dist(anchor_points, bbox, reg_max):
    #Transform bbox(xyxy) to dist(ltrb).
    x1y1, x2y2 = bbox.chunk(2, -1)
    return torch.cat((anchor_points - x1y1, x2y2 - anchor_points), -1).clamp_(0, reg_max - 0.01)  # dist (lt, rb)

class BboxLoss(nn.Module):
    def __init__(self, reg_max=16):
        super().__init__()
        self.dfl_loss = DFLoss(reg_max) if reg_max > 1 else None

    def forward(self, pred_dist, pred_bboxes, anchor_points, target_bboxes, target_scores, target_scores_sum, fg_mask):
        weight = target_scores.sum(-1)[fg_mask].unsqueeze(-1)
        iou = bbox_iou(pred_bboxes[fg_mask], target_bboxes[fg_mask], xywh=False, CIoU=True)
        loss_iou = ((1.0 - iou) * weight).sum() / target_scores_sum
        if self.dfl_loss:
            target_ltrb = bbox2dist(anchor_points, target_bboxes, self.dfl_loss.reg_max - 1)
            loss_dfl = self.dfl_loss(pred_dist[fg_mask].view(-1, self.dfl_loss.reg_max), target_ltrb[fg_mask]) * weight
            loss_dfl = loss_dfl.sum() / target_scores_sum
        else:
            loss_dfl = torch.tensor(0.0).to(pred_dist.device)

        return loss_iou, loss_dfl

def empty_like(x):
    #Creates empty torch.Tensor or np.ndarray with same shape as input and float32 dtype.
    return (
        torch.empty_like(x, dtype=torch.float32) if isinstance(x, torch.Tensor) else np.empty_like(x, dtype=np.float32)
    )

def xywh2xyxy(x):
    
    #Convert bounding box coordinates from (x, y, width, height) format to (x1, y1, x2, y2) format where (x1, y1) is the
    #top-left corner and (x2, y2) is the bottom-right corner. Note: ops per 2 channels faster than per channel.

    #Args:
    #    x (np.ndarray | torch.Tensor): The input bounding box coordinates in (x, y, width, height) format.

    #Returns:
    #    y (np.ndarray | torch.Tensor): The bounding box coordinates in (x1, y1, x2, y2) format.
    
    assert x.shape[-1] == 4, f"input shape last dimension expected 4 but input shape is {x.shape}"
    y = empty_like(x)  # faster than clone/copy
    xy = x[..., :2]  # centers
    wh = x[..., 2:] / 2  # half width-height
    y[..., :2] = xy - wh  # top left xy
    y[..., 2:] = xy + wh  # bottom right xy
    return y

def non_max_suppression(
    prediction,
    conf_thres=0.25,
    iou_thres=0.45,
    classes=None,
    agnostic=False,
    multi_label=False,
    labels=(),
    max_det=300,
    nc=0,  # number of classes (optional)
    max_time_img=0.05,
    max_nms=30000,
    max_wh=7680,
    in_place=True,
    rotated=False,
    return_metrics=False,
):
    
    #Perform non-maximum suppression (NMS) on a set of boxes, with support for masks and multiple labels per box.

    #Args:
    #    prediction (torch.Tensor): A tensor of shape (batch_size, num_classes + 4 + num_masks, num_boxes)
    #        containing the predicted boxes, classes, and masks. The tensor should be in the format
    #        output by a model, such as YOLO.
    #    conf_thres (float): The confidence threshold below which boxes will be filtered out.
    #        Valid values are between 0.0 and 1.0.
    #    iou_thres (float): The IoU threshold below which boxes will be filtered out during NMS.
    #        Valid values are between 0.0 and 1.0.
    #    classes (List[int]): A list of class indices to consider. If None, all classes will be considered.
    #    agnostic (bool): If True, the model is agnostic to the number of classes, and all
    #        classes will be considered as one.
    #    multi_label (bool): If True, each box may have multiple labels.
    #    labels (List[List[Union[int, float, torch.Tensor]]]): A list of lists, where each inner
    #        list contains the apriori labels for a given image. The list should be in the format
    #        output by a dataloader, with each label being a tuple of (class_index, x1, y1, x2, y2).
    #    max_det (int): The maximum number of boxes to keep after NMS.
    #    nc (int, optional): The number of classes output by the model. Any indices after this will be considered masks.
    #    max_time_img (float): The maximum time (seconds) for processing one image.
    #    max_nms (int): The maximum number of boxes into torchvision.ops.nms().
    #    max_wh (int): The maximum box width and height in pixels.
    #    in_place (bool): If True, the input prediction tensor will be modified in place.
    #    rotated (bool): If Oriented Bounding Boxes (OBB) are being passed for NMS.
    #
    #Returns:
    #    (List[torch.Tensor]): A list of length batch_size, where each element is a tensor of
    #        shape (num_boxes, 6 + num_masks) containing the kept boxes, with columns
    #        (x1, y1, x2, y2, confidence, class, mask1, mask2, ...).
    
    import torchvision  # scope for faster 'import ultralytics'

    # Checks
    assert 0 <= conf_thres <= 1, f"Invalid Confidence threshold {conf_thres}, valid values are between 0.0 and 1.0"
    assert 0 <= iou_thres <= 1, f"Invalid IoU {iou_thres}, valid values are between 0.0 and 1.0"
    if isinstance(prediction, (list, tuple)):  # YOLOv8 model in validation model, output = (inference_out, loss_out)
        prediction = prediction[0]  # select only inference output
    if classes is not None:
        classes = torch.tensor(classes, device=prediction.device)

    if prediction.shape[-1] == 6:  # end-to-end model (BNC, i.e. 1,300,6)
        output = [pred[pred[:, 4] > conf_thres][:max_det] for pred in prediction]
        if classes is not None:
            output = [pred[(pred[:, 5:6] == classes).any(1)] for pred in output]
        return output

    bs = prediction.shape[0]  # batch size (BCN, i.e. 1,84,6300)
    nc = nc or (prediction.shape[1] - 4)  # number of classes
    nm = prediction.shape[1] - nc - 4  # number of masks
    mi = 4 + nc  # mask start index
    xc = prediction[:, 4:mi].amax(1) > conf_thres  # candidates

    # Settings
    # min_wh = 2  # (pixels) minimum box width and height
    time_limit = 2.0 + max_time_img * bs  # seconds to quit after
    multi_label &= nc > 1  # multiple labels per box (adds 0.5ms/img)

    prediction = prediction.transpose(-1, -2)  # shape(1,84,6300) to shape(1,6300,84)
    if not rotated:
        if in_place:
            prediction[..., :4] = xywh2xyxy(prediction[..., :4])  # xywh to xyxy
        else:
            prediction = torch.cat((xywh2xyxy(prediction[..., :4]), prediction[..., 4:]), dim=-1)  # xywh to xyxy

    t = time.time()
    output = [torch.zeros((0, 6 + nm), device=prediction.device)] * bs
    for xi, x in enumerate(prediction):  # image index, image inference
        # Apply constraints
        # x[((x[:, 2:4] < min_wh) | (x[:, 2:4] > max_wh)).any(1), 4] = 0  # width-height
        x = x[xc[xi]]  # confidence

        # Cat apriori labels if autolabelling
        if labels and len(labels[xi]) and not rotated:
            lb = labels[xi]
            v = torch.zeros((len(lb), nc + nm + 4), device=x.device)
            v[:, :4] = xywh2xyxy(lb[:, 1:5])  # box
            v[range(len(lb)), lb[:, 0].long() + 4] = 1.0  # cls
            x = torch.cat((x, v), 0)

        # If none remain process next image
        if not x.shape[0]:
            continue

        # Detections matrix nx6 (xyxy, conf, cls)
        box, cls, mask = x.split((4, nc, nm), 1)

        if multi_label:
            i, j = torch.where(cls > conf_thres)
            x = torch.cat((box[i], x[i, 4 + j, None], j[:, None].float(), mask[i]), 1)
        else:  # best class only
            conf, j = cls.max(1, keepdim=True)
            x = torch.cat((box, conf, j.float(), mask), 1)[conf.view(-1) > conf_thres]

        # Filter by class
        if classes is not None:
            x = x[(x[:, 5:6] == classes).any(1)]

        # Check shape
        n = x.shape[0]  # number of boxes
        if not n:  # no boxes
            continue
        if n > max_nms:  # excess boxes
            x = x[x[:, 4].argsort(descending=True)[:max_nms]]  # sort by confidence and remove excess boxes

        # Batched NMS
        c = x[:, 5:6] * (0 if agnostic else max_wh)  # classes
        scores = x[:, 4]  # scores
        #if rotated:
        #    boxes = torch.cat((x[:, :2] + c, x[:, 2:4], x[:, -1:]), dim=-1)  # xywhr
        #    i = nms_rotated(boxes, scores, iou_thres)
        #else:
        boxes = x[:, :4] + c  # boxes (offset by class)
        i = torchvision.ops.nms(boxes, scores, iou_thres)  # NMS
        i = i[:max_det]  # limit detections

        # # Experimental
        # merge = False  # use merge-NMS
        # if merge and (1 < n < 3E3):  # Merge NMS (boxes merged using weighted mean)
        #     # Update boxes as boxes(i,4) = weights(i,n) * boxes(n,4)
        #     from .metrics import box_iou
        #     iou = box_iou(boxes[i], boxes) > iou_thres  # IoU matrix
        #     weights = iou * scores[None]  # box weights
        #     x[i, :4] = torch.mm(weights, x[:, :4]).float() / weights.sum(1, keepdim=True)  # merged boxes
        #     redundant = True  # require redundant detections
        #     if redundant:
        #         i = i[iou.sum(1) > 1]  # require redundancy

        output[xi] = x[i]
        if (time.time() - t) > time_limit:
            LOGGER.warning(f"WARNING ⚠️ NMS time limit {time_limit:.3f}s exceeded")
            break  # time limit exceeded

    return output
"""
