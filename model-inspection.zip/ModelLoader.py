import os
import time
import numpy as np
import platform
import cv2
from nms import non_max_suppression, normalize_yolo_prediction

DEVICE_COMPATIBLE_NODE = '/proc/device-tree/compatible'
RKNN356X_TARGETS = {'rk3566', 'rk3568'}
RKNNLITE_SHIM_SENTINEL = '_edgevision_target_soc_shim'



def _apply_nms_metrics_to_timing(last_timing, metrics):
    if not metrics:
        return
    metric = metrics[0] or {}
    last_timing.update({
        'backend_nms_elapsed_ms': metric.get('nms_elapsed_ms', 0.0),
        'backend_raw_box_count': metric.get('raw_box_count', 0),
        'backend_confidence_candidate_count': metric.get('confidence_candidate_count', 0),
        'backend_pre_nms_candidate_count': metric.get('pre_nms_candidate_count', 0),
        'backend_final_detection_count': metric.get('final_detection_count', 0),
        'backend_max_confidence': metric.get('max_confidence', 0.0),
        'backend_nms_backend': metric.get('nms_backend', 'numpy'),
    })

RKNN_TARGET_MAP = {
    'RK3566_RK3568': 'rk3568',
    'RK3562': 'rk3562',
    'RK3576': 'rk3576',
    'RK3588': 'rk3588',
}


def _env_truthy(var_name, default=False):
    value = os.getenv(var_name)
    if value is None:
        return default
    return value.strip().lower() in ('1', 'true', 'yes', 'on')


def resolve_rknn_target(host_name):
    env_target = os.getenv('RKNN_TARGET', '').strip().lower()
    if env_target:
        print(f"RKNN target selected from env RKNN_TARGET={env_target}")
        return env_target

    mapped_target = RKNN_TARGET_MAP.get(host_name)
    if mapped_target:
        print(f"RKNN target resolved from host '{host_name}' to '{mapped_target}'")
        return mapped_target

    if host_name == 'Linux-aarch64':
        raise RuntimeError(
            "RKNN target resolution failed: host is Linux-aarch64 and RKNN_TARGET is not set. "
            "Set RKNN_TARGET explicitly (for RK3568 use RKNN_TARGET=rk3568)."
        )

    raise RuntimeError(
        f"RKNN target resolution failed for host '{host_name}'. "
        "Set RKNN_TARGET explicitly."
    )


def resolve_rknn_runtime_config(host_name):
    target = resolve_rknn_target(host_name)
    print(f"RKNN runtime config: selected_target={target}")

    is_linux_aarch64 = platform.system() == 'Linux' and platform.machine() == 'aarch64'
    rk356x_targetless_compat = is_linux_aarch64 and (
        target in RKNN356X_TARGETS or host_name == 'RK3566_RK3568'
    )

    if rk356x_targetless_compat:
        return {}, 'default_linux_aarch64_rk356x', True, target

    return {'target': target}, 'explicit_target', False, target


def _resolve_rk356x_target_proof():
    env_target = os.getenv('RKNN_TARGET', '').strip().lower()
    if env_target in RKNN356X_TARGETS:
        return env_target, f'env:RKNN_TARGET={env_target}'

    compatible_node = os.getenv('DEVICE_COMPATIBLE_NODE', DEVICE_COMPATIBLE_NODE).strip() or DEVICE_COMPATIBLE_NODE
    try:
        with open(compatible_node) as f:
            device_compatible_str = f.read().lower()
    except IOError:
        return None, f'compatible_node_unreadable:{compatible_node}'

    if 'rockchip,rk3568' in device_compatible_str or 'rk3568' in device_compatible_str:
        return 'rk3568', f'compatible_node:{compatible_node}:rk3568'
    if 'rockchip,rk3566' in device_compatible_str or 'rk3566' in device_compatible_str:
        return 'rk3566', f'compatible_node:{compatible_node}:rk3566'
    return None, f'compatible_node:{compatible_node}:no_rk356x'


def activate_rknnlite_detection_shim(host_name, runtime_mode, selected_target):
    is_linux_aarch64 = platform.system() == 'Linux' and platform.machine() == 'aarch64'
    selected_target = (selected_target or '').strip().lower()
    target_or_host_match = selected_target in RKNN356X_TARGETS or host_name == 'RK3566_RK3568'
    precheck_ok = is_linux_aarch64 and runtime_mode == 'default_linux_aarch64_rk356x' and target_or_host_match
    print(
        'RKNNLite detection shim precheck: '
        f'linux_aarch64={is_linux_aarch64} runtime_mode={runtime_mode} '
        f'target_or_host_match={target_or_host_match}'
    )
    if not precheck_ok:
        print('RKNNLite detection shim active=False reason=precheck_failed')
        return False

    proof_target, proof_source = _resolve_rk356x_target_proof()
    print(f'RKNNLite detection shim target proof source={proof_source}')
    if proof_target not in RKNN356X_TARGETS:
        print('RKNNLite detection shim active=False reason=missing_target_proof')
        return False

    try:
        from rknnlite.api import rknn_runtime
    except Exception as exc:
        print(f'RKNNLite detection shim active=False reason=import_failed error={exc}')
        return False

    runtime_cls = getattr(rknn_runtime, 'RKNNRuntime', None)
    if runtime_cls is None:
        print('RKNNLite detection shim active=False reason=missing_RKNNRuntime')
        return False

    original_get_target_soc = getattr(runtime_cls, '_get_target_soc', None)
    if not callable(original_get_target_soc):
        print('RKNNLite detection shim active=False reason=missing__get_target_soc')
        return False

    if getattr(runtime_cls, RKNNLITE_SHIM_SENTINEL, False):
        print('RKNNLite detection shim active=True reason=already_patched')
        return True

    def _shim_get_target_soc(self, *args, **kwargs):
        try:
            print(
                'RKNNLite detection shim call passthrough: '
                f'args_count={len(args)} kwargs_count={len(kwargs)}'
            )
            detected = original_get_target_soc(self, *args, **kwargs)
            print(f'RKNNLite detection shim original detection result={detected}')
        except Exception as exc:
            detected = None
            print(f'RKNNLite detection shim original detection result=error:{exc}')

        if isinstance(detected, str) and detected.strip():
            print(f'RKNNLite detection shim result={detected}')
            return detected

        print(f'RKNNLite detection shim result={proof_target}')
        return proof_target

    setattr(runtime_cls, '_get_target_soc', _shim_get_target_soc)
    setattr(runtime_cls, RKNNLITE_SHIM_SENTINEL, True)
    print(f'RKNNLite detection shim active=True target={proof_target}')
    return True


def get_host():
    system = platform.system()
    if system == 'Linux' and platform.machine() == 'aarch64':
        compatible_node = os.getenv('DEVICE_COMPATIBLE_NODE', DEVICE_COMPATIBLE_NODE).strip() or DEVICE_COMPATIBLE_NODE
        print(f"RKNN host detect: compatible_node_path={compatible_node}")
        try:
            with open(compatible_node) as f:
                device_compatible_str = f.read()
                print(f"RKNN host detect: compatible_node_read=ok bytes={len(device_compatible_str)}")
                if 'rk3562' in device_compatible_str:
                    return 'RK3562'
                elif 'rk3576' in device_compatible_str:
                    return 'RK3576'
                elif 'rk3588' in device_compatible_str:
                    return 'RK3588'
                else:
                    return 'RK3566_RK3568'
        except IOError:
            print(f"RKNN host detect: compatible_node_read=failed path={compatible_node}")
            return 'Linux-aarch64'
    return platform.system() + '-' + platform.machine()

def get_best_onnx_providers(rt):
    available_providers = rt.get_available_providers()
    provider_priority = [
        'DmlExecutionProvider',
        'CoreMLExecutionProvider',
        'CPUExecutionProvider'
    ]
    chosen_providers = [p for p in provider_priority if p in available_providers]
    return chosen_providers if chosen_providers else ['CPUExecutionProvider']

class RKNNModel:
    def __init__(self, rknn_path, nc=1, input_shape=(1, 3, 640, 640)):
        if not os.path.exists(rknn_path):
            raise FileNotFoundError(f"RKNN model not found at {rknn_path}")

        from rknnlite.api import RKNNLite

        self.rknn_lite = RKNNLite()
        host_name = get_host()
        env_target = os.getenv('RKNN_TARGET', '').strip().lower()
        self.rknn_path = rknn_path
        print(f"RKNN init: model_path={rknn_path}")
        print(f"RKNN init: detected_host={host_name}")
        print(f"RKNN init: env_RKNN_TARGET={env_target or '(unset)'}")
        runtime_kwargs, runtime_mode, rk356x_targetless_compat, target = resolve_rknn_runtime_config(host_name)
        self.target = target
        print(f"RKNN init: selected_target={target}")
        print(f"RKNN init: runtime_mode={runtime_mode}")
        print(f"RKNN init: rk356x_targetless_compat={rk356x_targetless_compat}")
        shim_active = activate_rknnlite_detection_shim(host_name, runtime_mode, target)
        print(f"RKNN init: detection_shim_active={shim_active}")

        ret = self.rknn_lite.load_rknn(rknn_path)
        if ret != 0:
            raise RuntimeError(f'Load RKNN model {rknn_path} failed with code {ret}')
        ret = self.rknn_lite.init_runtime(**runtime_kwargs)
        if ret != 0:
            raise RuntimeError(f'Init RKNN runtime failed with code {ret}')
        print("RKNN init: success")
        
        self.input_size = (640, 640)
        self.nc = nc
        self.last_timing = {}


    def __del__(self):
        if hasattr(self, 'rknn_lite'):
            self.rknn_lite.release()

    def preprocess_frame(self, frame):
        """Return RKNN input for a BGR HWC frame.

        The RKNN was built from the NCHW ONNX model with mean/std
        preprocessing, so runtime input must remain raw uint8 RGB in NHWC
        layout. Feeding already-normalized float tiles scales inputs twice and
        collapses confidences toward zero.
        """
        if frame.dtype != np.uint8:
            frame = np.clip(frame * 255.0 if np.max(frame) <= 1.0 else frame, 0, 255).astype(np.uint8)

        img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, self.input_size, interpolation=cv2.INTER_LINEAR)
        return np.expand_dims(img, 0)

    def infer_raw(self, frame):
        preprocess_start = time.perf_counter()
        input_data = self.preprocess_frame(frame)
        backend_preprocess_elapsed_ms = round((time.perf_counter() - preprocess_start) * 1000.0, 3)
        inference_start = time.perf_counter()
        outputs = self.rknn_lite.inference(inputs=[input_data])
        backend_inference_elapsed_ms = round((time.perf_counter() - inference_start) * 1000.0, 3)
        normalize_start = time.perf_counter()
        normalized = normalize_yolo_prediction(outputs[0], nc=self.nc)
        backend_postprocess_elapsed_ms = round((time.perf_counter() - normalize_start) * 1000.0, 3)
        self.last_timing = {
            'backend_preprocess_elapsed_ms': backend_preprocess_elapsed_ms,
            'backend_inference_elapsed_ms': backend_inference_elapsed_ms,
            'backend_postprocess_elapsed_ms': backend_postprocess_elapsed_ms,
            'backend_total_elapsed_ms': round(backend_preprocess_elapsed_ms + backend_inference_elapsed_ms + backend_postprocess_elapsed_ms, 3),
        }
        return normalized

    def predict_frame(self, frame, conf_thresh=0.25, iou_thresh=0.45):
        total_start = time.perf_counter()
        try:
            raw_preds_np = self.infer_raw(frame)
            nms_start = time.perf_counter()
            final_detections, nms_metrics = non_max_suppression(
                raw_preds_np,
                conf_thres=conf_thresh,
                iou_thres=iou_thresh,
                nc=self.nc,
                return_metrics=True,
            )
            nms_elapsed_ms = round((time.perf_counter() - nms_start) * 1000.0, 3)
            self.last_timing['backend_postprocess_elapsed_ms'] = round(self.last_timing.get('backend_postprocess_elapsed_ms', 0.0) + nms_elapsed_ms, 3)
            _apply_nms_metrics_to_timing(self.last_timing, nms_metrics)
            self.last_timing['backend_total_elapsed_ms'] = round((time.perf_counter() - total_start) * 1000.0, 3)
            return final_detections[0]
        except Exception:
            self.last_timing = {'backend_total_elapsed_ms': round((time.perf_counter() - total_start) * 1000.0, 3)}
            raise
    
    def predict_batch(self, batch_frames, conf_thresh=0.25, iou_thresh=0.45):
        all_detections = []
        for frame in batch_frames:
            detections = self.predict_frame(frame, conf_thresh, iou_thresh)
            all_detections.append(detections)
        return all_detections
        
class ONNXModel:
    def __init__(self, onnx_path, nc=1):
        if not os.path.exists(onnx_path):
            raise FileNotFoundError(f"ONNX model not found at {onnx_path}")

        import onnxruntime as rt

        sess_options = rt.SessionOptions()
        sess_options.execution_mode = rt.ExecutionMode.ORT_SEQUENTIAL
        self.session = rt.InferenceSession(
            onnx_path, 
            providers=get_best_onnx_providers(rt),
            sess_options=sess_options
        )
        self.input_name = self.session.get_inputs()[0].name
        self.input_shape = self.session.get_inputs()[0].shape
        self.nc = nc
        self.input_size = (640, 640)
        self.last_timing = {}

    def preprocess_frame(self, frame):
        """Return ONNX input for a BGR HWC frame as normalized RGB NCHW."""
        if frame.dtype != np.uint8:
            frame = np.clip(frame * 255.0 if np.max(frame) <= 1.0 else frame, 0, 255).astype(np.uint8)

        img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, self.input_size, interpolation=cv2.INTER_LINEAR)
        img = img.astype(np.float32) / 255.0
        input_batch = np.expand_dims(img, axis=0)
        return input_batch.transpose(0, 3, 1, 2)

    def infer_raw(self, frame):
        preprocess_start = time.perf_counter()
        input_batch = self.preprocess_frame(frame)
        backend_preprocess_elapsed_ms = round((time.perf_counter() - preprocess_start) * 1000.0, 3)
        inference_start = time.perf_counter()
        outputs = self.session.run(None, {self.input_name: input_batch})
        backend_inference_elapsed_ms = round((time.perf_counter() - inference_start) * 1000.0, 3)
        normalize_start = time.perf_counter()
        normalized = normalize_yolo_prediction(outputs[0], nc=self.nc)
        backend_postprocess_elapsed_ms = round((time.perf_counter() - normalize_start) * 1000.0, 3)
        self.last_timing = {
            'backend_preprocess_elapsed_ms': backend_preprocess_elapsed_ms,
            'backend_inference_elapsed_ms': backend_inference_elapsed_ms,
            'backend_postprocess_elapsed_ms': backend_postprocess_elapsed_ms,
            'backend_total_elapsed_ms': round(backend_preprocess_elapsed_ms + backend_inference_elapsed_ms + backend_postprocess_elapsed_ms, 3),
        }
        return normalized

    def predict_frame(self, frame, conf_thresh=0.25, iou_thresh=0.45):
        total_start = time.perf_counter()
        try:
            raw_preds_np = self.infer_raw(frame)
            nms_start = time.perf_counter()
            final_detections, nms_metrics = non_max_suppression(
                raw_preds_np,
                conf_thres=conf_thresh,
                iou_thres=iou_thresh,
                nc=self.nc,
                return_metrics=True,
            )
            nms_elapsed_ms = round((time.perf_counter() - nms_start) * 1000.0, 3)
            self.last_timing['backend_postprocess_elapsed_ms'] = round(self.last_timing.get('backend_postprocess_elapsed_ms', 0.0) + nms_elapsed_ms, 3)
            _apply_nms_metrics_to_timing(self.last_timing, nms_metrics)
            self.last_timing['backend_total_elapsed_ms'] = round((time.perf_counter() - total_start) * 1000.0, 3)
            return final_detections[0]
        except Exception:
            self.last_timing = {'backend_total_elapsed_ms': round((time.perf_counter() - total_start) * 1000.0, 3)}
            raise
        
    def predict_batch(self, batch_frames, conf_thresh=0.25, iou_thresh=0.45):
        all_detections = []
        for frame in batch_frames:
            detections = self.predict_frame(frame, conf_thresh, iou_thresh)
            all_detections.append(detections)
        return all_detections

class ModelLoader:
    def __init__(self, model, backend):
        self.model = model
        self.backend = backend

def load_best_model(onnx_path, rknn_path, nc=1):
    require_npu = _env_truthy('REQUIRE_NPU', default=False)
    allow_cpu_emergency = _env_truthy('ALLOW_CPU_EMERGENCY', default=False)
    allow_onnx_fallback = (not require_npu) or allow_cpu_emergency

    print(
        "Model loading policy: "
        f"REQUIRE_NPU={require_npu}, "
        f"ALLOW_CPU_EMERGENCY={allow_cpu_emergency}, "
        f"ONNX_fallback_allowed={allow_onnx_fallback}"
    )

    if os.path.exists(rknn_path):
        print("Loading RKNN model")
        try:
            rknn_model = RKNNModel(rknn_path, nc=nc)
            print("✅ RKNN model loaded successfully")
            return ModelLoader(rknn_model, "RKNN")
        except Exception as e:
            print(f"❌ RKNN loading failed: {e}")
            if require_npu and not allow_cpu_emergency:
                print("hard_accel_failure: REQUIRE_NPU=true and ALLOW_CPU_EMERGENCY=false; refusing CPU fallback")
                raise RuntimeError(
                    "hard_accel_failure: RKNN init failed while REQUIRE_NPU=true and "
                    "ALLOW_CPU_EMERGENCY=false"
                ) from e
    elif require_npu and not allow_cpu_emergency:
        print("hard_accel_failure: RKNN model path missing while REQUIRE_NPU=true and ALLOW_CPU_EMERGENCY=false")
        raise RuntimeError(
            f"hard_accel_failure: RKNN model not found at {rknn_path} while REQUIRE_NPU=true"
        )

    if not allow_onnx_fallback:
        raise RuntimeError("hard_accel_failure: ONNX fallback is disabled by NPU policy")

    print("RUNNING_DEGRADED_CPU_FALLBACK=1")
    print("Loading ONNX model")
    try:
        onnx_model = ONNXModel(onnx_path, nc=nc)
        print("✅ ONNX model loaded successfully")
        return ModelLoader(onnx_model, "ONNX")
    except Exception as e:
        print(f"❌ ONNX loading failed: {e}")
        raise RuntimeError(f"Failed to load model: {e}")
