"""Canonical preprocessing helpers for the current EdgeVision hot path.

Production TCP input is RGB, HWC, uint8 with byte length width * height * 3.
This module intentionally documents and preserves the current stretch-to-640
policy. It does not introduce letterbox preprocessing in PR 1.

Backend adapters remain backend-specific:
* RKNN receives raw RGB NHWC uint8 at the adapter level; RKNN build config owns
  scaling/normalization.
* ONNX receives RGB NCHW float32 normalized by /255 at the adapter level.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

import cv2
import numpy as np

MODEL_INPUT_SIZE = (640, 640)


@dataclass(frozen=True)
class FrameGeometry:
    original_width: int
    original_height: int
    model_width: int = MODEL_INPUT_SIZE[0]
    model_height: int = MODEL_INPUT_SIZE[1]

    @property
    def scale_x(self) -> float:
        return self.original_width / float(self.model_width)

    @property
    def scale_y(self) -> float:
        return self.original_height / float(self.model_height)


@dataclass(frozen=True)
class PreprocessTiming:
    frame_decode_elapsed_ms: float = 0.0
    receiver_preprocess_elapsed_ms: float = 0.0
    backend_preprocess_elapsed_ms: float = 0.0


@dataclass(frozen=True)
class PreprocessResult:
    frame: np.ndarray
    geometry: FrameGeometry
    timing: PreprocessTiming = field(default_factory=PreprocessTiming)


def rgb_bytes_to_rgb_frame(frame_data: bytes, width: int, height: int) -> np.ndarray:
    """Return an RGB HWC uint8 frame view from TCP frame bytes.

    The caller remains responsible for validating byte length against
    width * height * 3, preserving the existing FrameReceiver contract.
    """
    frame_rgb = np.frombuffer(frame_data, dtype=np.uint8)
    return frame_rgb.reshape((height, width, 3))


def resize_rgb_stretch(frame_rgb: np.ndarray, size: tuple[int, int] = MODEL_INPUT_SIZE) -> np.ndarray:
    """Stretch-resize an RGB frame to model input size using cv2.resize.

    This intentionally preserves the current non-letterboxed 640x640 stretch
    behavior so measurements can be gathered before any cleanup PR changes it.
    """
    return cv2.resize(frame_rgb, size, interpolation=cv2.INTER_LINEAR)


def rgb_to_bgr(frame_rgb: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2BGR)


def bgr_to_rgb(frame_bgr: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)


def scale_detections_from_model_input(
    detections: Sequence[Mapping[str, Any]],
    original_width: int,
    original_height: int,
    model_width: int = MODEL_INPUT_SIZE[0],
    model_height: int = MODEL_INPUT_SIZE[1],
) -> list[dict[str, Any]]:
    """Scale dict detections from stretched model input coordinates.

    This helper mirrors the existing FrameReceiver coordinate behavior: int()
    truncation, clamp to original frame bounds, and invalid box filtering.
    Class/module filtering is intentionally left to the caller.
    """
    scale_x = original_width / float(model_width)
    scale_y = original_height / float(model_height)
    scaled = []
    for det in detections:
        if not isinstance(det, Mapping):
            continue
        if 'box' not in det or 'confidence' not in det or 'class' not in det:
            continue
        box = det['box']
        if not isinstance(box, list) or len(box) != 4:
            continue

        x1 = max(0, min(original_width, int(box[0] * scale_x)))
        y1 = max(0, min(original_height, int(box[1] * scale_y)))
        x2 = max(0, min(original_width, int(box[2] * scale_x)))
        y2 = max(0, min(original_height, int(box[3] * scale_y)))
        if x1 >= x2 or y1 >= y2:
            continue
        scaled.append({'box': [x1, y1, x2, y2], 'confidence': float(det['confidence']), 'class': int(det['class'])})
    return scaled
