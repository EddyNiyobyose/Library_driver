PERSON EVALUATION — DIAGNOSTIC DATA REVIEW, 21 OCTOBER 2026

Purpose: investigate the existing ARED person detector, not certify deployment accuracy.
Original archive is retained byte-for-byte. No training or model modification performed.

Verified source: 100 decodable images; 100 matching YOLO class-0 label files;
175 original annotation boxes; no malformed or out-of-bounds labels; no exact duplicate images.
All 100 pairs visually screened as contact sheets. Two poster-related cases additionally
inspected at source resolution and revised for physically present person counting.
20 uncertain/incomplete cases excluded from diagnostic/ rather than inventing ground truth.
The 80 retained images are a preliminary diagnostic subset, not fully independently certified labels.
Their selection is based on annotation review; do not compare their aggregate metrics directly
with the original 100-image set or the engineer's 1000-image benchmark.

See image_review.csv for every image, exclusions and limitations.
See label_changes.json for exact changes. original/ retains original images and labels.
diagnostic/ contains only retained image/label pairs with the two documented corrections.

Important limitations:
- Source training/test membership and licensing not documented in this archive.
- No camera/session split metadata; first five images visibly share a camera scene.
- No model weights, inference outputs or previous evaluation scripts included.
- 17 original boxes occupy less than 1% of their source image area; only three original
  images have five or more annotations. Original set has no empty labels; revised subset
  includes a single poster-only image with an empty label. Additional representative
  empty, small-person and crowded surveillance scenes needed for final acceptance.
- Uncertain labels must not be silently treated as negative examples.

Execution path verified in repository code:
video_ai/ModelLoader.py loads RKNN first, ONNX only when fallback is permitted.
RKNN runtime receives raw RGB uint8 NHWC; ONNX receives normalized RGB float NCHW.
Both existing adapters use 640x640 stretch and shared NMS.
video_ai/scripts/compare_onnx_rknn_frame.py compares formats on the same input,
not model predictions against ground-truth labels. It does not provide batch labeled scoring.
No conversion needed to test already existing ONNX/RKNN files.
No hardware inference or model accuracy gain is claimed in this package.

Next required execution: identify the actual deployed model hash, thresholds and preprocessing;
score these fixed diagnostic inputs using the existing adapters with ground-truth matching;
retain raw predictions before confidence/NMS and final detections for loss attribution.
Check ONNX/RKNN disagreement separately from model-vs-label errors. Replay identical
final detections through the backend filter independently. Desktop time is not RK3568 time.

Acceptance criteria: agree required recall/count error, empty-scene false-alarm limits and
hardware latency/memory budgets before selecting an improvement. An untouched, representative
camera/session-separated holdout remains necessary. This package defines no invented targets.
