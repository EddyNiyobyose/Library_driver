#!/usr/bin/env bash
# Zoom test on the box NPU (VisDrone val, 250 pictures). Read-only for the running service:
# copies the pictures into the AI pod's /tmp, runs zoom_box_eval.py through the live model code, then removes
# everything from the pod and from the box's /tmp.
# Run:  cd /tmp && tar xzf zoomtest_visdrone.tgz && bash /tmp/zoomtest/run_box.sh
set -uo pipefail
export KUBECONFIG="${KUBECONFIG:-/mnt/data/server/cred/admin.kubeconfig}"
NS="${NS:-camera-solution}"
HERE="$(cd "$(dirname "$0")" && pwd)"
exec </dev/null
cleanup() {
  [ -n "${P:-}" ] && kubectl -n "$NS" exec "$P" -- rm -rf /tmp/zoomtest /tmp/zoomtest_pkg.tgz >/dev/null 2>&1
  case "$HERE" in /tmp/*) rm -rf "$HERE";; esac
  rm -f /tmp/zoomtest.tgz /tmp/zoomtest_visdrone.tgz
  echo "--- cleaned: pod /tmp/zoomtest, box /tmp/zoomtest and the package"
}
trap cleanup EXIT
echo "=== ZOOM TEST (VisDrone val, NPU) ==="; date
P="$(kubectl -n "$NS" get pods -o name 2>/dev/null | grep -i edgevision | head -1)"; P="${P#pod/}"
[ -n "$P" ] || { echo "STOP: AI service pod not found in $NS"; kubectl -n "$NS" get pods 2>&1 | head -20; exit 1; }
echo "--- AI pod: $P (restarts before: $(kubectl -n "$NS" get pod "$P" -o jsonpath='{.status.containerStatuses[0].restartCount}'))"
kubectl -n "$NS" exec "$P" -- sh -c 'ls -l /app/rknn_weights/yolox_tiny_int8_384x640.rknn /app/rknn_weights/yolox_tiny_int8_448x800.rknn' \
  || { echo "STOP: model files missing"; exit 1; }
echo "--- pictures: $(ls "$HERE/images" | wc -l), labels: $(ls "$HERE/labels" | wc -l)"
tar czf /tmp/zoomtest.tgz -C "$(dirname "$HERE")" --transform 's,^[^/]*,zoomtest,' "$(basename "$HERE")"
kubectl -n "$NS" exec "$P" -- rm -rf /tmp/zoomtest /tmp/zoomtest_pkg.tgz
kubectl -n "$NS" cp /tmp/zoomtest.tgz "$P:/tmp/zoomtest_pkg.tgz"
kubectl -n "$NS" exec "$P" -- sh -c 'cd /tmp && tar xzf zoomtest_pkg.tgz && rm zoomtest_pkg.tgz && ls /tmp/zoomtest | head -5'
echo "--- running (real NPU, about 5-10 minutes)"
kubectl -n "$NS" exec "$P" -- sh -c 'cd /app && PYTHONPATH=/app python3 /tmp/zoomtest/zoom_box_eval.py --data /tmp/zoomtest --weights /app/rknn_weights 2>&1' \
  | grep -E "^(PROGRESS|PICTURES|RESULT|SUMMARY|STOP|  )|Traceback|Error" | grep -v "RKNN init"
echo "--- AI pod restarts after: $(kubectl -n "$NS" get pod "$P" -o jsonpath='{.status.containerStatuses[0].restartCount}')"
echo "=== DONE ==="
