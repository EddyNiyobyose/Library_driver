"""Zoom test on the box NPU: VisDrone val pictures (original resolution, hand labels).

Runs INSIDE the AI pod through the live YoloxRKNNModel code. Read-only: it loads its own model copies
and never touches the running service or its settings.

  (a) today:  frame -> 640x360 (worker) -> 384x640 keep
  (b) zoom:   (a) + one pass on a fixed crop (half the frame width and height) of the original frame, merged
              'upper centre' = fixed crop at the top middle; 'per camera' = crop placed once per sequence
              from the OTHER pictures of that sequence (crops.json, made offline)
  (c) 448x800 one pass (frame sent at 800x450)

  PYTHONPATH=/app python3 zoom_box_eval.py --data /tmp/zoomtest --weights /app/rknn_weights
"""
import argparse
import json
import os
import statistics
import sys

import cv2
import numpy as np

sys.path.insert(0, "/app")

PERSON, VEH = (0,), (2, 3, 5, 7)
CLASSES = PERSON + VEH
CONF, NMS_IOU, MERGE_IOU = 0.25, 0.45, 0.5
VD_PERSON, VD_VEH, VD_VEH_IGNORE = (1, 2), (4, 5, 6, 9, 10), (3, 7, 8)
FAR = .15


def iou_mat(a, b):
    if not len(a) or not len(b):
        return np.zeros((len(a), len(b)))
    x1 = np.maximum(a[:, None, 0], b[None, :, 0]); y1 = np.maximum(a[:, None, 1], b[None, :, 1])
    x2 = np.minimum(a[:, None, 2], b[None, :, 2]); y2 = np.minimum(a[:, None, 3], b[None, :, 3])
    inter = np.clip(x2 - x1, 0, None) * np.clip(y2 - y1, 0, None)
    aa = (a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1]); ab = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])
    return inter / (aa[:, None] + ab[None, :] - inter + 1e-9)


def match(db, ds, gb, gign, t):
    """Greedy by score. 1 hit, 0 false alarm, -1 on an ignore box. Returns states and the gt hit mask."""
    st = np.zeros(len(ds), int); gm = np.zeros(len(gb), bool)
    if not len(gb):
        return st, gm
    M = iou_mat(db, gb)
    for i in np.argsort(-ds):
        cand = np.where(~gign & ~gm & (M[i] >= t))[0]
        if len(cand):
            j = cand[np.argmax(M[i, cand])]; gm[j] = True; st[i] = 1
        elif (gign & (M[i] >= t)).any():
            st[i] = -1
    return st, gm


def nms(b, s, thr):
    order = np.argsort(-s); keep = []
    while order.size:
        i = order[0]; keep.append(i)
        iou = iou_mat(b[i:i + 1], b[order[1:]])[0]
        order = order[1:][iou <= thr]
    return np.array(keep, int)


def load_labels(path):
    P, PI, V, VI = [], [], [], []
    for ln in open(path):
        v = [int(x) for x in ln.strip().strip(",").split(",")[:8]]
        bx = [v[0], v[1], v[0] + v[2], v[1] + v[3]]
        if v[5] in VD_PERSON:
            (P if v[4] == 1 else PI).append(bx)
        elif v[5] in VD_VEH:
            (V if v[4] == 1 else VI).append(bx)
        elif v[5] in VD_VEH_IGNORE:
            VI.append(bx)
        else:                      # ignored regions and 'others'
            PI.append(bx); VI.append(bx)
    a = lambda L: np.array(L, float).reshape(-1, 4)
    return a(P), a(PI), a(V), a(VI)


def detect(m, frame, scale):
    """One live pass; boxes scaled back to original-frame pixels. Returns rows and NPU ms."""
    m.set_source_aspect(frame.shape[1] / float(frame.shape[0]))
    rows = m.predict_frame(frame, conf_thresh=CONF, iou_thresh=NMS_IOU)
    rows = rows.copy()
    if len(rows):
        rows[:, :4] *= scale
    return rows, m.last_timing["backend_inference_elapsed_ms"], m.last_timing["backend_total_elapsed_ms"]


def zoom(m, full, base, crop):
    H, W = full.shape[:2]; x0, y0, cw, ch = crop
    sub = cv2.resize(full[y0:y0 + ch, x0:x0 + cw], (640, 360), interpolation=cv2.INTER_AREA)   # worker sends the crop at 640x360
    rows, npu, tot = detect(m, sub, np.array([cw / 640.0, ch / 360.0, cw / 640.0, ch / 360.0]))
    if len(rows):
        mg = 4  # boxes cut by an inner crop border: the full-frame pass sees those whole
        cut = ((rows[:, 0] < mg) & (x0 > 0)) | ((rows[:, 1] < mg) & (y0 > 0)) | ((rows[:, 2] > cw - mg) & (x0 + cw < W)) | ((rows[:, 3] > ch - mg) & (y0 + ch < H))
        rows = rows[~cut]; rows[:, :4] += [x0, y0, x0, y0]
    allr = np.concatenate([base, rows]) if len(rows) else base
    if len(allr):
        grp = np.isin(allr[:, 5], VEH).astype(float)
        allr = allr[nms(allr[:, :4] + grp[:, None] * 16384.0, allr[:, 4], MERGE_IOU)]
    return allr, npu, tot


class Score:
    def __init__(self):
        self.k = dict(tp=0, fp=0, all=0, far=0, vtp=0, vfp=0, vhit=0, abserr=0)
        self.rel, self.npu, self.tot = [], [], []

    def add(self, rows, P, PI, V, VI, H, npu, tot):
        k = self.k; self.npu.append(npu); self.tot.append(tot)
        b = rows[:, :4] if len(rows) else np.zeros((0, 4)); s = rows[:, 4] if len(rows) else np.zeros(0)
        c = rows[:, 5] if len(rows) else np.zeros(0)
        pk = np.isin(c, PERSON)
        gb = np.concatenate([P, PI]); ign = np.r_[np.zeros(len(P), bool), np.ones(len(PI), bool)]
        st, gm = match(b[pk], s[pk], gb, ign, 0.5); gm = gm[:len(P)]
        far = (P[:, 3] - P[:, 1]) / H < FAR
        k["tp"] += int((st == 1).sum()); k["fp"] += int((st == 0).sum()); k["all"] += int(gm.sum()); k["far"] += int((gm & far).sum())
        n = int((st >= 0).sum()); k["abserr"] += abs(n - len(P)); self.rel.append(abs(n - len(P)) / max(len(P), 1))
        vk = np.isin(c, VEH)
        gb = np.concatenate([V, VI]); ign = np.r_[np.zeros(len(V), bool), np.ones(len(VI), bool)]
        st, gm = match(b[vk], s[vk], gb, ign, 0.5)
        k["vtp"] += int((st == 1).sum()); k["vfp"] += int((st == 0).sum()); k["vhit"] += int(gm[:len(V)].sum())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--weights", default="/app/rknn_weights")
    ap.add_argument("--limit", type=int, default=0)
    a = ap.parse_args()
    from yolox_backend import YoloxRKNNModel

    crops = json.load(open(os.path.join(a.data, "crops.json")))
    names = sorted(crops)[: a.limit or None]
    need = {"384x640": "yolox_tiny_int8_384x640.rknn", "448x800": "yolox_tiny_int8_448x800.rknn"}
    for k, f in need.items():
        if not os.path.exists(os.path.join(a.weights, f)):
            print("STOP: %s not in this image" % f, flush=True); sys.exit(1)
    m384 = YoloxRKNNModel(os.path.join(a.weights, need["384x640"]), nc=1, model_size=(384, 640), classes=CLASSES, keep_shape=True)
    m448 = YoloxRKNNModel(os.path.join(a.weights, need["448x800"]), nc=1, model_size=(448, 800), classes=CLASSES, keep_shape=True)
    opts = ["a 384x640", "b zoom upper centre", "b zoom per camera", "c 448x800"]
    S = {o: Score() for o in opts}
    NP = NF = NV = 0
    for i, n in enumerate(names):
        full = cv2.imread(os.path.join(a.data, "images", n)); H, W = full.shape[:2]
        P, PI, V, VI = load_labels(os.path.join(a.data, "labels", n[:-4] + ".txt"))
        NP += len(P); NF += int(((P[:, 3] - P[:, 1]) / H < FAR).sum()); NV += len(V)
        f360 = cv2.resize(full, (640, 360), interpolation=cv2.INTER_AREA)
        base, npu, tot = detect(m384, f360, np.array([W / 640.0, H / 360.0, W / 640.0, H / 360.0]))
        S["a 384x640"].add(base, P, PI, V, VI, H, npu, tot)
        for o, key in (("b zoom upper centre", "upper_centre"), ("b zoom per camera", "per_camera")):
            rows, n2, t2 = zoom(m384, full, base, crops[n][key])
            S[o].add(rows, P, PI, V, VI, H, npu + n2, tot + t2)
        f450 = cv2.resize(full, (800, 450), interpolation=cv2.INTER_AREA)
        rows, n3, t3 = detect(m448, f450, np.array([W / 800.0, H / 450.0, W / 800.0, H / 450.0]))
        S["c 448x800"].add(rows, P, PI, V, VI, H, n3, t3)
        if (i + 1) % 50 == 0:
            print("PROGRESS %d/%d" % (i + 1, len(names)), flush=True)
    npic = len(names)
    print("PICTURES %d | people %d (far %d) | vehicles %d | conf %.2f IoU 0.5" % (npic, NP, NF, NV, CONF), flush=True)
    res = {}
    for o in opts:
        k = S[o].k
        r = dict(far=100.0 * k["far"] / max(NF, 1), all=100.0 * k["all"] / max(NP, 1), prec=100.0 * k["tp"] / max(k["tp"] + k["fp"], 1),
                 fpp=k["fp"] / float(npic), rel=100.0 * float(np.mean(S[o].rel)), veh=100.0 * k["vhit"] / max(NV, 1),
                 vprec=100.0 * k["vtp"] / max(k["vtp"] + k["vfp"], 1), npu=statistics.median(S[o].npu),
                 npu95=float(np.percentile(S[o].npu, 95)), tot=statistics.median(S[o].tot))
        res[o] = r
        print("RESULT %-20s far people %5.1f/100 | all people %5.1f | precision %5.1f | false people/pic %4.2f | count err %3.0f%% | "
              "vehicles %5.1f prec %5.1f | NPU %5.1f ms (p95 %5.1f) total %5.1f ms" % (
                  o, r["far"], r["all"], r["prec"], r["fpp"], r["rel"], r["veh"], r["vprec"], r["npu"], r["npu95"], r["tot"]), flush=True)
    A, C = res["a 384x640"], res["c 448x800"]
    print("SUMMARY rule: zoom needs >= +10 far per 100 over (a), <= 2 points precision loss, and must beat (c)")
    for o in opts[1:3]:
        x = res[o]; ok = x["far"] - A["far"] >= 10 and A["prec"] - x["prec"] <= 2 and x["far"] > C["far"]
        print("  %-20s far %+5.1f | precision %+5.1f | vs (c) far %+5.1f | NPU x%.2f -> %s" % (
            o, x["far"] - A["far"], x["prec"] - A["prec"], x["far"] - C["far"], x["npu"] / max(A["npu"], 1e-6), "PASS" if ok else "fail"))
    print("  %-20s far %+5.1f | precision %+5.1f | NPU x%.2f" % ("c 448x800", C["far"] - A["far"], C["prec"] - A["prec"], C["npu"] / max(A["npu"], 1e-6)))


if __name__ == "__main__":
    main()
