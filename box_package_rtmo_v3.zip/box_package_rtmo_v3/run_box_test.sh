#!/bin/sh
# RTMO-s benchmark v3 on the RK3568 box: the faster SPPF+Focus body with capped and uncapped CPU tails, the shipped
# body as same-day reference (each run twice for run-to-run noise), and two sustained 5-camera load tests next to
# the live service (shipped body vs SPPF+Focus). Read-only test.
#
# v3 needs no results file to leave the box: analyze_v3.py compares the box INT8 outputs with float references
# made on the laptop (refs_v3.json) and prints one short report (results/report.txt, also shown by 'status').
#
# Writes only inside this folder (results/). Loads the .rknn/.onnx files read-only, installs nothing,
# changes no configuration, starts or restarts no service. Each model runs in its own python process.
#
# Start (survives the terminal closing):
#   cd <this folder> && setsid nohup sh run_box_test.sh > run.out 2>&1 < /dev/null &
# Check:   cat results/STATUS         (one line per step; "ALL_DONE" at the end)
# Stop:    kill -- -$(cat results/PID)   (whole process group; needs the setsid start)
# Re-run:  same start command; models whose results/<tag>/bench.json exists are skipped.
#
# Settings (environment variables): SIZE (384x640), RUNS (100), THREADS (1), PY (python3), MIN_MB (500), FORCE (0),
#   DET (deployed detector for the YOLOX probe, default /app/rknn_weights/yolox_tiny_int8_384x640.rknn),
#   LOAD (1 = run the load tests), LOAD_SECONDS (120)
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
cd "$HERE" || exit 1
R=$HERE/results
mkdir -p "$R"
echo $$ > "$R/PID"

PY=${PY:-python3}
SIZE=${SIZE:-384x640}
RUNS=${RUNS:-100}
THREADS=${THREADS:-1}
MIN_MB=${MIN_MB:-500}
FORCE=${FORCE:-0}
DET=${DET:-/app/rknn_weights/yolox_tiny_int8_384x640.rknn}
LOAD=${LOAD:-1}
LOAD_SECONDS=${LOAD_SECONDS:-120}

status() { echo "$(date '+%Y-%m-%dT%H:%M:%S') $*" | tee -a "$R/STATUS"; }

free_mb() {  # smaller of the host's MemAvailable and the cgroup headroom (limit - current), in MB
  host=$(awk '/MemAvailable/ {print int($2/1024)}' /proc/meminfo)
  lim=$(cat /sys/fs/cgroup/memory.max 2>/dev/null || cat /sys/fs/cgroup/memory/memory.limit_in_bytes 2>/dev/null || echo max)
  cur=$(cat /sys/fs/cgroup/memory.current 2>/dev/null || cat /sys/fs/cgroup/memory/memory.usage_in_bytes 2>/dev/null || echo 0)
  case $lim in max|"") echo "$host"; return ;; esac
  cg=$(( (lim - cur) / 1048576 ))
  [ "$cg" -lt "$host" ] && echo "$cg" || echo "$host"
}

# ---- preflight -------------------------------------------------------------------------------
status "START size=$SIZE runs=$RUNS threads=$THREADS"
fail=0
{
  echo "===== preflight $(date)"; echo "host: $(uname -a)"
  echo "--- files"; sha256sum -c SHA256SUMS --quiet && echo SUMS_OK || { echo SUMS_FAILED; }
  echo "--- python"; $PY -c "import numpy, cv2; from rknnlite.api import RKNNLite; print('numpy', numpy.__version__, 'cv2', cv2.__version__, 'rknnlite OK')" 2>&1
  $PY -c "import onnxruntime; print('ORT_OK', onnxruntime.__version__)" 2>&1 || echo ORT_MISSING
  echo "--- live service detector setting"; env | grep -E 'EDGEVISION_YOLOX_INPUT_HW|EDGEVISION_KEEP_SHAPE' || echo "(not set in this shell)"
  echo "--- memory (MB free for this test): $(free_mb)"; free -m 2>/dev/null
  echo "--- cpu"; nproc 2>/dev/null; cat /proc/loadavg 2>/dev/null
  echo "--- npu"; cat /sys/kernel/debug/rknpu/load /sys/kernel/debug/rknpu/freq 2>/dev/null || echo "(npu debugfs not readable)"
  for f in /sys/class/devfreq/*; do [ -d "$f" ] && echo "devfreq $(basename "$f"): cur $(cat "$f/cur_freq" 2>/dev/null) max $(cat "$f/max_freq" 2>/dev/null) governor $(cat "$f/governor" 2>/dev/null)"; done
  echo "--- detector for the probe: $DET"; [ -f "$DET" ] && echo DET_OK || echo DET_MISSING
} > "$R/preflight_last.txt" 2>&1
cat "$R/preflight_last.txt" >> "$R/preflight.txt"  # keep every attempt

grep -q SUMS_OK "$R/preflight_last.txt" || { status "PREFLIGHT_FAIL files: checksum mismatch (see results/preflight.txt)"; fail=1; }
grep -q '^numpy .* rknnlite OK' "$R/preflight_last.txt" || { status "PREFLIGHT_FAIL python: rknnlite/numpy/cv2 missing (see results/preflight.txt)"; fail=1; }
grep -q '^ORT_OK' "$R/preflight_last.txt" || { status "PREFLIGHT_FAIL python: onnxruntime missing (RTMO needs it for the CPU tail)"; fail=1; }
[ "$(free_mb)" -ge "$MIN_MB" ] || { status "PREFLIGHT_FAIL memory: $(free_mb) MB free < $MIN_MB"; fail=1; }
if [ "$fail" -ne 0 ] && [ "$FORCE" != 1 ]; then
  status "STOPPED at preflight; nothing ran. Options: fix the listed item, or FORCE=1 to run anyway."
  status "ALL_DONE"; exit 2
fi
status "PREFLIGHT_OK"

# ---- models, in priority order: tag body.rknn tail.onnx threads ------------------------------
# base = shipped body; sf = SPPF+Focus body (same maths, NPU-friendlier graph). b48/b32 = 48x64 / 32x48 decoder bins;
# c10 = at most 10 people decoded (no suffix = no cap). _r2 = the same run again at the end (run-to-run noise).
# Also every v2 run: now = the v1 tail (192x256 bins); sppf / focus alone; cut1/2/3 = the body up to the backbone /
# encoder / head convs, NPU time only (no tail): full minus cuts = cost per part.
MODELS="base_b48c10_1t rtmo_s_384x640_int8.rknn rtmo_tail_b48c10.onnx 1
sf_b48c10_1t rtmo_s_384x640_int8_sppf_focus.rknn rtmo_tail_b48c10.onnx 1
sf_b32c10_1t rtmo_s_384x640_int8_sppf_focus.rknn rtmo_tail_b32c10.onnx 1
sf_b32c10_2t rtmo_s_384x640_int8_sppf_focus.rknn rtmo_tail_b32c10.onnx 2
sf_b48_2t rtmo_s_384x640_int8_sppf_focus.rknn rtmo_tail_b48.onnx 2
sf_b32_2t rtmo_s_384x640_int8_sppf_focus.rknn rtmo_tail_b32.onnx 2
sf_b32_1t rtmo_s_384x640_int8_sppf_focus.rknn rtmo_tail_b32.onnx 1
now_1t rtmo_s_384x640_int8.rknn rtmo_tail_now.onnx 1
b48_1t rtmo_s_384x640_int8.rknn rtmo_tail_b48.onnx 1
b48c10_2t rtmo_s_384x640_int8.rknn rtmo_tail_b48c10.onnx 2
sppf_b48c10_1t rtmo_s_384x640_int8_sppf.rknn rtmo_tail_b48c10.onnx 1
focus_b48c10_1t rtmo_s_384x640_int8_focus.rknn rtmo_tail_b48c10.onnx 1
cut1_backbone rtmo_cut1_backbone.rknn - 1
cut2_encoder rtmo_cut2_encoder.rknn - 1
cut3_heads rtmo_cut3_heads.rknn - 1
b48_2t rtmo_s_384x640_int8.rknn rtmo_tail_b48.onnx 2
b32c10_1t rtmo_s_384x640_int8.rknn rtmo_tail_b32c10.onnx 1
base_b48c10_1t_r2 rtmo_s_384x640_int8.rknn rtmo_tail_b48c10.onnx 1
sf_b48c10_1t_r2 rtmo_s_384x640_int8_sppf_focus.rknn rtmo_tail_b48c10.onnx 1"

echo "$MODELS" | while read -r tag body tail threads; do
  [ -n "$tag" ] || continue
  out=$R/$tag
  if [ -f "$out/bench.json" ]; then status "SKIP $tag (already done)"; continue; fi
  if [ ! -f "$body" ] || { [ "$tail" != - ] && [ ! -f "$tail" ]; }; then status "SKIP $tag (file not in package)"; continue; fi
  spec="$HERE/$body"; [ "$tail" = - ] || spec="$HERE/$body,$HERE/$tail"
  if [ "$(free_mb)" -lt "$MIN_MB" ] && [ "$FORCE" != 1 ]; then status "SKIP $tag (only $(free_mb) MB free)"; continue; fi
  mkdir -p "$out"
  status "RUN $tag"
  $PY "$HERE/bench_rtmo.py" --model "$spec" --size "$SIZE" --images "$HERE/images"     --out "$out" --runs "$RUNS" --tail-threads "${threads:-$THREADS}" > "$out/run.log" 2>&1
  rc=$?
  if [ "$rc" -eq 0 ] && [ -f "$out/bench.json" ]; then status "DONE $tag"; else status "FAILED $tag exit=$rc (see results/$tag/run.log)"; fi
done

# ---- sustained load next to the live service (5 cameras x 0.5 fps pose = 2.5 frames/s) -----------------------
# L0: box alone (live service only), 30 s. L1: YOLOX probe 1/s alone, 60 s.
# L2: YOLOX probe + RTMO 2.5/s, SPPF+Focus body + 32x48 bins capped at 10 (the candidate). L3: same with the shipped body + b48c10 (v2 setup).
# Probe = the deployed detector loaded read-only; its latency L1 vs L2/L3 = how much RTMO slows the detector.
pose_load() {  # tag body tail
  status "RUN load $1 (RTMO 2.5/s $2 + $3, with YOLOX probe if present, $LOAD_SECONDS s)"
  $PY "$HERE/load_rtmo.py" --role sys --seconds "$LOAD_SECONDS" --out "$R/load/$1_sys.json" > "$R/load/$1_sys.log" 2>&1 &
  [ -f "$DET" ] && $PY "$HERE/load_rtmo.py" --role det --body "$DET" --images "$HERE/images" --rate 1 --seconds "$LOAD_SECONDS" --out "$R/load/$1_det.json" > "$R/load/$1_det.log" 2>&1 &
  $PY "$HERE/load_rtmo.py" --role pose --body "$HERE/$2" --tail "$HERE/$3" --images "$HERE/images" --rate 2.5 --seconds "$LOAD_SECONDS" --out "$R/load/$1_pose.json" > "$R/load/$1_pose.log" 2>&1
  wait
  [ -f "$R/load/$1_pose.json" ] && status "DONE load $1" || status "FAILED load $1 (see results/load/$1_*.log)"
}
if [ "$LOAD" = 1 ]; then
  mkdir -p "$R/load"
  if [ "$(free_mb)" -lt "$MIN_MB" ] && [ "$FORCE" != 1 ]; then status "SKIP load test (only $(free_mb) MB free)"; else
    if [ ! -f "$R/load/L0_sys.json" ]; then
      status "RUN load L0 (box alone 30 s)"
      $PY "$HERE/load_rtmo.py" --role sys --seconds 30 --out "$R/load/L0_sys.json" > "$R/load/L0.log" 2>&1
    fi
    if [ -f "$DET" ] && [ ! -f "$R/load/L1_det.json" ]; then
      status "RUN load L1 (YOLOX probe 1/s alone, 60 s)"
      $PY "$HERE/load_rtmo.py" --role sys --seconds 60 --out "$R/load/L1_sys.json" > "$R/load/L1_sys.log" 2>&1 &
      $PY "$HERE/load_rtmo.py" --role det --body "$DET" --images "$HERE/images" --rate 1 --seconds 60 --out "$R/load/L1_det.json" > "$R/load/L1_det.log" 2>&1
      wait
    fi
    [ -f "$DET" ] || status "SKIP YOLOX probe ($DET not found)"
    [ -f "$R/load/L2_pose.json" ] || pose_load L2 rtmo_s_384x640_int8_sppf_focus.rknn rtmo_tail_b32c10.onnx
    [ -f "$R/load/L3_pose.json" ] || pose_load L3 rtmo_s_384x640_int8.rknn rtmo_tail_b48c10.onnx
  fi
fi

# ---- report (everything the test is for, printed on the box; nothing needs to leave it) ------------------
$PY "$HERE/analyze_v3.py" "$R" "$HERE/refs_v3.json" > "$R/report.txt" 2>&1
cat "$R/report.txt"
(cd "$R" && find . -type f ! -name RESULTS_SHA256 ! -name PID ! -name preflight_last.txt ! -name STATUS | sort | xargs sha256sum > RESULTS_SHA256)
status "REPORT ready: results/report.txt ($(du -sh "$R" | cut -f1) results)"
status "ALL_DONE"
