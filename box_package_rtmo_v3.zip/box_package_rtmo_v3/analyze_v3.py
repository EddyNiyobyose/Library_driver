#!/usr/bin/env python3
"""On-box analysis for the RTMO-s box test v3 (standard library only). Read-only: reads results/, prints a report.

So that no results file has to leave the box, this prints everything the test is for in one short block:
  * speed per run (NPU / CPU tail p50 p95, ms per person, people, memory)
  * box INT8 vs float ONNX per run (refs_v3.json made on the laptop from the same photos and tails):
    people lost / extra (IoU 0.5), keypoint error / box diagonal, frames with the same people count;
    next to the simulator's INT8 vs float numbers (what the box should match)
  * load: box CPU, memory, YOLOX probe, RTMO under load; RTMO NPU time split by whether the YOLOX probe was on
    the NPU at the same time and whether the box CPU was >= 90% busy (what drives the slow frames)
Usage: python3 analyze_v3.py RESULTS_DIR REFS_JSON
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path


def pct(values, p):
    s = sorted(values)
    if not s:
        return float("nan")
    k = (len(s) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(s) - 1)
    return s[lo] + (s[hi] - s[lo]) * (k - lo)


def iou(a, b):
    x1, y1, x2, y2 = max(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, x2 - x1) * max(0.0, y2 - y1)
    return inter / ((a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter + 1e-9)


def compare(ref, out):
    """ref/out: {image: [people]}. Greedy IoU >= 0.5 match per reference person (as rtmo_variants_vs_onnx.py)."""
    nref = nout = lost = 0
    errs, same = [], 0
    for name, rp in ref.items():
        op = out.get(name, [])
        nref += len(rp); nout += len(op); same += len(rp) == len(op)
        used = set()
        for p in rp:
            best, bj = 0.0, None
            for j, q in enumerate(op):
                if j not in used:
                    v = iou(p["box"], q["box"])
                    if v > best:
                        best, bj = v, j
            if best < 0.5:
                lost += 1
                continue
            used.add(bj)
            b = p["box"]
            diag = math.hypot(b[2] - b[0], b[3] - b[1]) + 1e-6
            q = op[bj]["kpts"]
            errs.append(sum(math.hypot(k[0] - m[0], k[1] - m[1]) for k, m in zip(p["kpts"], q)) / len(q) / diag)
    return {"float_people": nref, "int8_people": nout, "lost": round(lost / max(1, nref), 4),
            "extra": round((nout - (nref - lost)) / max(1, nref), 4), "kpt_err": round(sum(errs) / max(1, len(errs)), 4),
            "kpt_err_p95": round(pct(errs, 0.95), 4) if errs else None, "count_equal": f"{same}/{len(ref)}"}


def main() -> int:
    r, refs_path = Path(sys.argv[1]), Path(sys.argv[2])
    refs = json.loads(refs_path.read_text()) if refs_path.exists() else {"refs": {}, "simulator_vs_float": {}}
    print(f"{'run':22s} {'npu p50':>7s} {'p95':>6s} {'tail p50':>8s} {'p95':>6s} {'ms/pers':>7s} {'people':>6s} {'MB':>4s}")
    par = []
    for b in sorted(r.glob("*/bench.json")):
        d = json.loads(b.read_text()); m = list(d["models"].values())[0]; body = list(d["models"])[0]
        g = lambda k, q="p50": (m.get(k) or {}).get(q, float("nan"))
        print(f"{b.parent.name:22s} {g('npu_ms'):7.1f} {g('npu_ms','p95'):6.1f} {g('cpu_tail_ms'):8.1f} {g('cpu_tail_ms','p95'):6.1f} "
              f"{g('cpu_tail_ms_per_person'):7.2f} {g('people_per_frame','mean'):6.2f} {d['peak_rss_kb'] / 1024:4.0f}")
        key = f"{body}|{m.get('tail')}"
        o = b.parent / "outputs.json"
        if m.get("tail") and key in refs["refs"] and o.exists():
            out = {}
            for row in json.loads(o.read_text()):
                out[row["image"]] = row["people"]
            par.append((b.parent.name, compare(refs["refs"][key], out), refs["simulator_vs_float"].get(key)))
    if par:
        print("INT8 vs float (box | simulator): lost, extra, kpt err mean/p95, same count")
        for tag, c, s in par:
            s = s or {}
            print(f"  {tag:20s} box {c['lost']:.3f} {c['extra']:.3f} {c['kpt_err']:.4f}/{c['kpt_err_p95']} {c['count_equal']} (float {c['float_people']}, int8 {c['int8_people']})"
                  f" | sim {s.get('lost')} {s.get('extra')} {s.get('kpt_err')}/{s.get('kpt_err_p95')} {s.get('count_equal')}")

    L = r / "load"
    def j(n):
        f = L / n
        return json.loads(f.read_text()) if f.exists() else None
    for tag in ("L0", "L1", "L2", "L3"):
        s_, d_, p_ = j(f"{tag}_sys.json"), j(f"{tag}_det.json"), j(f"{tag}_pose.json")
        if not (s_ or d_ or p_):
            continue
        line = f"load {tag}:"
        if p_: line += f" [{Path(p_['body']).name} + {Path(p_['tail']).name}]"
        if s_: line += f" CPU busy p50 {s_['cpu_busy_pct']['p50']}% p95 {s_['cpu_busy_pct']['p95']}%, load1 {s_['load1']['p50']}, min free {s_['mem_avail_mb_min']} MB;"
        if d_: line += f" YOLOX p50 {d_['npu_ms']['p50']} p95 {d_['npu_ms']['p95']};"
        if p_: line += (f" RTMO npu {p_['npu_ms']['p50']}/{p_['npu_ms']['p95']}, tail {p_['cpu_tail_ms']['p50']}/{p_['cpu_tail_ms']['p95']},"
                        f" frame p95 {p_['frame_ms']['p95']}, own CPU {p_['own_cpu_pct_of_one_core']}%, {p_['peak_rss_mb']} MB, late {p_['late_starts']}/{p_['frames']}, people {p_.get('people_mean')}")
        print(line)
        if p_ and p_.get("rows"):
            rows = p_["rows"]  # [t after NPU, npu ms, tail ms, frame ms, people]
            det = [(t - ms / 1000.0, t) for t, ms in (d_ or {}).get("rows", [])]
            ov, no = [], []
            for row in rows:
                a, z = row[0] - row[1] / 1000.0, row[0]
                (ov if any(s < z and e > a for s, e in det) else no).append(row[1])
            samp = (s_ or {}).get("samples", [])  # [t end of 0.5 s window, busy %, load1, MB]
            hi_n, lo_n, hi_t, lo_t = [], [], [], []
            for row in rows:
                w = next((x for x in samp if x[0] >= row[0]), None)
                if w is None:
                    continue
                (hi_n if w[1] >= 90 else lo_n).append(row[1]); (hi_t if w[1] >= 90 else lo_t).append(row[2])
            f = lambda v: f"{pct(v, .5):.0f}/{pct(v, .95):.0f} (n {len(v)})"
            print(f"  {tag} RTMO npu p50/p95: YOLOX on NPU same time {f(ov)}, not {f(no)} | box CPU >=90% {f(hi_n)}, <90% {f(lo_n)}; tail: CPU >=90% {f(hi_t)}, <90% {f(lo_t)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
