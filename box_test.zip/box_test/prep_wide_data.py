"""Download labelled COCO val2017 pictures for the box shape test: pictures with people, plus pictures
with vehicles or animals and no people (those groups are thin otherwise).

Standard library only (runs on the box host). Pictures are never used in training, so the result
is a fair comparison. They are not our venues: use it to compare options against each other.

  python3 prep_wide_data.py OUT_DIR [N] [EXTRA]      (default N=600, EXTRA=300)
"""
import concurrent.futures as cf, io, os, sys, urllib.request, zipfile

LABELS_URL = 'https://github.com/ultralytics/assets/releases/download/v0.0.0/coco2017labels.zip'
OUT = sys.argv[1]
N = int(sys.argv[2]) if len(sys.argv) > 2 else 600
EXTRA = int(sys.argv[3]) if len(sys.argv) > 3 else 300
OTHERS = {str(c) for c in (2, 3, 5, 7, *range(14, 24))}     # vehicles and animals, video_ai/object_categories.py


def get(url, timeout=60):
    return urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=timeout).read()


os.makedirs(os.path.join(OUT, 'images'), exist_ok=True)
os.makedirs(os.path.join(OUT, 'labels'), exist_ok=True)
z = zipfile.ZipFile(io.BytesIO(get(LABELS_URL, 300)))
names = sorted(n for n in z.namelist() if n.startswith('coco/labels/val2017/') and n.endswith('.txt'))
seen = {n: {l.split()[0] for l in z.read(n).decode().splitlines() if l.split()} for n in names}
people = [n for n in names if '0' in seen[n]]
rest = [n for n in names if '0' not in seen[n] and seen[n] & OTHERS]
chosen = people[::max(1, len(people) // N)][:N] + rest[::max(1, len(rest) // max(EXTRA, 1))][:EXTRA]


def fetch(n):
    i = n.split('/')[-1][:-4]
    dst = os.path.join(OUT, 'images', i + '.jpg')
    if not os.path.exists(dst):
        try:
            b = get('http://images.cocodataset.org/val2017/%s.jpg' % i, 30)
        except Exception:
            return 0
        if len(b) < 5000:
            return 0
        open(dst, 'wb').write(b)
    open(os.path.join(OUT, 'labels', i + '.txt'), 'wb').write(z.read(n))
    return 1


with cf.ThreadPoolExecutor(8) as ex:
    ok = sum(ex.map(fetch, chosen))
print('DATA %d pictures (%d in COCO val with people, %d with only vehicles or animals) in %s' % (ok, len(people), len(rest), OUT))
