#!/usr/bin/env bash
# Box test: which input size gives YOLOX-Tiny the best accuracy per unit of work (real NPU, live code).
# Read-only for the running service. Finds labelled pictures under /mnt/data (images+labels, or the
# pipeline eval/evallabels layout); if none, downloads COCO val pictures with people, plus pictures with vehicles or
# animals and no people (those groups are thin otherwise). Run: bash tools/box_shapes_test.sh
# To test a newer evaluate_shapes.py than the image has: EVAL_SCRIPT=path/to/evaluate_shapes.py bash tools/box_shapes_test.sh
set -uo pipefail
NS=camera-solution; N=600; EXTRA=300
T="$(mktemp -d /tmp/shapes.XXXXXX)"; trap 'rm -rf "$T"' EXIT
exec </dev/null
echo "=== SHAPE TEST ==="; date
P="$(kubectl -n "$NS" get pods -o name 2>/dev/null | grep -i edgevision | head -1)"; P="${P#pod/}"
[ -n "$P" ] || { echo "STOP: AI service pod not found"; exit 1; }
echo "--- AI pod: $P"
echo "--- model files in the image"
kubectl -n "$NS" exec "$P" -- sh -c 'ls -l /app/rknn_weights/ 2>&1 | sed "s/^/  /"; for f in /app/rknn_weights/*.build_error.txt; do [ -f "$f" ] && { echo "  BUILD ERROR in $f:"; tail -n 25 "$f" | sed "s/^/    /"; }; done; true'
SCRIPT=/app/scripts/evaluate_shapes.py
if [ -z "${EVAL_SCRIPT:-}" ]; then
  kubectl -n "$NS" exec "$P" -- test -f "$SCRIPT" || { echo "STOP: AI image has no scripts/evaluate_shapes.py"; exit 1; }
fi
echo "--- labelled pictures"
python3 - "$T/data" "$N" "$EXTRA" <<'PY'
import io, os, random, shutil, sys, urllib.request, zipfile
out, n, extra = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
OTHERS = {str(c) for c in (2, 3, 5, 7, *range(14, 24))}     # vehicles and animals, video_ai/object_categories.py
PRUNE = ("containerd", "rancher", "k3s", "overlay", "venv", "site-packages", "snapshots", "recordings", "lost+found")
IMG = (".jpg", ".jpeg", ".png")

def label_for(img):
    d, f = os.path.split(img); stem = os.path.splitext(f)[0]; up = os.path.dirname(d)
    c = [os.path.join(d, stem + ".txt"), os.path.join(d, "labels", stem + ".txt"),
         os.path.join(up, "labels", stem + ".txt"), os.path.join(up, "evallabels", stem + ".txt"),
         os.path.join(os.path.dirname(up), "labels", os.path.basename(d), stem + ".txt")]
    return next((p for p in c if os.path.isfile(p)), None)

def pairs_in(d):
    return [(os.path.join(d, f), l) for f in sorted(os.listdir(d)) if f.lower().endswith(IMG)
            for l in [label_for(os.path.join(d, f))] if l]

best, src = [], ""
for root, dirs, files in os.walk("/mnt/data"):
    dirs[:] = [x for x in dirs if x not in PRUNE]
    if root.count(os.sep) > 9:
        dirs[:] = []
    if sum(f.lower().endswith(IMG) for f in files) >= 50:
        p = pairs_in(root)
        if len(p) > len(best):
            best, src = p, root
def classes(lines):
    return {x.split()[0] for x in lines if x.split()}

people = [(i, l) for i, l in best if "0" in classes(open(l, errors="replace"))]
others = [(i, l) for i, l in best if "0" not in classes(open(l, errors="replace")) and classes(open(l, errors="replace")) & OTHERS]
if len(people) >= 50:
    print("  found %d labelled pictures with people and %d with only vehicles or animals in %s" % (len(people), len(others), src))
else:
    print("  no labelled pictures on the box; downloading COCO val pictures with people (not used in training)")
    get = lambda u, t=120: urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}), timeout=t).read()
    z = zipfile.ZipFile(io.BytesIO(get("https://github.com/ultralytics/assets/releases/download/v0.0.0/coco2017labels.zip", 600)))
    names = sorted(x for x in z.namelist() if x.startswith("coco/labels/val2017/") and x.endswith(".txt"))
    seen = {x: classes(z.read(x).decode().splitlines()) for x in names}
    with_people = [x for x in names if "0" in seen[x]][::4][:n]
    rest = [x for x in names if "0" not in seen[x] and seen[x] & OTHERS]
    rest = rest[::max(1, len(rest) // extra)][:extra]
    dl = os.path.join(out + "_dl"); os.makedirs(dl, exist_ok=True)

    def fetch(chosen):
        got = []
        for x in chosen:
            i = x.split("/")[-1][:-4]
            try:
                b = get("http://images.cocodataset.org/val2017/%s.jpg" % i, 30)
            except Exception:
                continue
            open(os.path.join(dl, i + ".jpg"), "wb").write(b); open(os.path.join(dl, i + ".txt"), "wb").write(z.read(x))
            got.append((os.path.join(dl, i + ".jpg"), os.path.join(dl, i + ".txt")))
        return got

    people, others = fetch(with_people), fetch(rest)
    print("  downloaded %d pictures with people and %d with only vehicles or animals" % (len(people), len(others)))
    if len(people) < 50:
        print("STOP: could not get labelled pictures (send this output to Claude)"); sys.exit(1)
random.Random(0).shuffle(people)
random.Random(0).shuffle(others)
picked = people[:n] + others[:extra]
os.makedirs(os.path.join(out, "images")); os.makedirs(os.path.join(out, "labels"))
for k, (i, l) in enumerate(picked):
    shutil.copy(i, os.path.join(out, "images", "%05d%s" % (k, os.path.splitext(i)[1].lower())))
    shutil.copy(l, os.path.join(out, "labels", "%05d.txt" % k))
print("  testing on %d pictures" % len(picked))
PY
[ -d "$T/data/images" ] || exit 1
tar czf "$T/data.tgz" -C "$T/data" images labels
kubectl -n "$NS" exec "$P" -- sh -c 'rm -rf /tmp/shapetest && mkdir -p /tmp/shapetest'
kubectl -n "$NS" cp "$T/data.tgz" "$P:/tmp/shapetest/data.tgz"
kubectl -n "$NS" exec "$P" -- sh -c 'cd /tmp/shapetest && tar xzf data.tgz && rm data.tgz'
if [ -n "${EVAL_SCRIPT:-}" ]; then
  kubectl -n "$NS" cp "$EVAL_SCRIPT" "$P:/tmp/shapetest/evaluate_shapes.py"
  SCRIPT=/tmp/shapetest/evaluate_shapes.py
fi
echo "--- results (real NPU, takes 15-30 minutes)"
kubectl -n "$NS" exec "$P" -- sh -c "cd /app && PYTHONPATH=/app python3 $SCRIPT --data /tmp/shapetest --weights /app/rknn_weights 2>&1" \
  | grep -E "^(PICTURES|RESULT|SKIP|BUILD_ERROR|SUMMARY|  )|Traceback|Error" | grep -v "RKNN init"
kubectl -n "$NS" exec "$P" -- rm -rf /tmp/shapetest
echo "=== DONE ==="
