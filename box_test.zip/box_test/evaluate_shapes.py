"""Box test: which input shape gives YOLOX-Tiny the best accuracy per unit of work on wide cameras?

Runs INSIDE the AI pod, on the NPU, through the same YoloxRKNNModel code the live service uses.
Read-only: it loads its own model copies and never touches the running service or its settings.

Each labelled picture is cut to 16:9 (like a real camera), squashed to 640x640 (like the camera
worker does), then sent through each variant:
  416 stretch  - today
  416 keep     - padding (shape kept, grey bars)
  320x544 keep - wide input, about today's cost
  384x640 keep - wide input, about 1.4x today's cost (takes the worker's 640x360 as is)
  448x800 keep - wide input, about 2.1x (past Tiny's 320-640 training sizes)
Objects less than half visible after the cut are 'ignore': never counted as missed or as false alarms.
People are scored on the pictures with people. Vehicles and animals (video_ai/object_categories.py) are
scored the same way on every picture, one group at a time, so a car found as a truck still counts. Each
picture runs on the NPU once; the group passes reuse that output through the live decode.

  python3 evaluate_shapes.py --data DIR --weights /app/rknn_weights [--limit N]

DIR holds images/<id>.jpg and labels/<id>.txt (YOLO format, from prep_wide_data.py).
"""
import argparse
import glob
import os
import statistics
import sys
import time

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))          # /app (video_ai) inside the image

LIVE_CONF = 0.25
THRS = np.arange(0.5, 0.96, 0.05)
GROUPS = {"person": (0,), "vehicle": (2, 3, 5, 7), "animal": tuple(range(14, 24))}   # object_categories.py


def wide_crop(img):
    h, w = img.shape[:2]
    if w / h < 16 / 9:
        nh = int(round(w * 9 / 16)); y0 = (h - nh) // 2
        return img[y0:y0 + nh], 0, y0
    nw = int(round(h * 16 / 9)); x0 = (w - nw) // 2
    return img[:, x0:x0 + nw], x0, 0


def load_objects(label_path, w0, h0, x0, y0, fw, fh):
    """Group -> boxes in the cut picture's pixels, with an ignore flag and visible height share."""
    out = {g: [] for g in GROUPS}
    if not os.path.exists(label_path):
        return out
    for ln in open(label_path):
        t = ln.split()
        group = next((g for g, ids in GROUPS.items() if len(t) >= 5 and int(t[0]) in ids), None)
        if group is None:
            continue
        cx, cy, bw, bh = (float(v) for v in t[1:5])
        ob = np.array([(cx - bw / 2) * w0 - x0, (cy - bh / 2) * h0 - y0, (cx + bw / 2) * w0 - x0, (cy + bh / 2) * h0 - y0])
        cb = np.array([max(0, ob[0]), max(0, ob[1]), min(fw, ob[2]), min(fh, ob[3])])
        if cb[2] <= cb[0] or cb[3] <= cb[1]:
            continue
        vis = (cb[2] - cb[0]) * (cb[3] - cb[1]) / max((ob[2] - ob[0]) * (ob[3] - ob[1]), 1e-6)
        out[group].append((cb, vis < 0.5, (cb[3] - cb[1]) / fh))
    return out


def iou_mat(a, b):
    if not len(a) or not len(b):
        return np.zeros((len(a), len(b)))
    x1 = np.maximum(a[:, None, 0], b[None, :, 0]); y1 = np.maximum(a[:, None, 1], b[None, :, 1])
    x2 = np.minimum(a[:, None, 2], b[None, :, 2]); y2 = np.minimum(a[:, None, 3], b[None, :, 3])
    inter = np.clip(x2 - x1, 0, None) * np.clip(y2 - y1, 0, None)
    aa = (a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1]); ab = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])
    return inter / (aa[:, None] + ab[None, :] - inter + 1e-9)


def match(db, ds, gb, gign, t):
    order = np.argsort(-ds)
    st = np.zeros(len(ds), int); gm = np.zeros(len(gb), bool)
    if not len(gb):
        return st, gm
    M = iou_mat(db, gb)
    for i in order:
        cand = np.where(~gign & ~gm & (M[i] >= t))[0]
        if len(cand):
            j = cand[np.argmax(M[i, cand])]; gm[j] = True; st[i] = 1
        elif (gign & (M[i] >= t)).any():
            st[i] = -1
    return st, gm


def ap(scores, tps, npos):
    if npos == 0 or not len(scores):
        return 0.0
    o = np.argsort(-scores); tp = tps[o]
    ctp = np.cumsum(tp); cfp = np.cumsum(1 - tp)
    rec = ctp / npos; prec = np.maximum.accumulate((ctp / np.maximum(ctp + cfp, 1e-12))[::-1])[::-1]
    return float(np.mean([prec[k] if k < len(prec) else 0.0 for k in (np.searchsorted(rec, rt, side='left') for rt in np.linspace(0, 1, 101))]))


class ReuseNPU:
    """Wraps the runtime so the group passes on one picture share a single NPU run; `fresh()` starts a picture."""

    def __init__(self, lite):
        self.lite, self.outs = lite, None

    def fresh(self):
        self.outs = None

    def inference(self, inputs):
        if self.outs is None:
            self.outs = self.lite.inference(inputs=inputs)
        return self.outs

    def __getattr__(self, name):
        return getattr(self.lite, name)


class Tally:
    """Live-threshold counts and AP for one group over the pictures it is scored on."""

    def __init__(self):
        self.scores, self.tps = [[] for _ in THRS], [[] for _ in THRS]
        self.npos = self.tp = self.fp = self.exact = self.pics = 0
        self.buckets = {"far": [0, 0], "mid": [0, 0], "near": [0, 0]}

    def add(self, b, s, gts):
        gb = np.array([g[0] for g in gts]).reshape(-1, 4); gign = np.array([g[1] for g in gts], bool)
        gh = np.array([g[2] for g in gts])
        self.npos += int((~gign).sum())
        for ti, t_ in enumerate(THRS):
            st, _ = match(b, s, gb, gign, t_)
            keep_ = st >= 0
            self.scores[ti].append(s[keep_]); self.tps[ti].append(st[keep_])
        live = s >= LIVE_CONF
        st, gm = match(b[live], s[live], gb, gign, 0.5)
        self.tp += int((st == 1).sum()); self.fp += int((st == 0).sum())
        for bn, lo, hi in (("far", 0, .15), ("mid", .15, .40), ("near", .40, 9)):
            sel = ~gign & (gh >= lo) & (gh < hi)
            self.buckets[bn][0] += int((gm & sel).sum()); self.buckets[bn][1] += int(sel.sum())
        nreal, nign = int((~gign).sum()), int(gign.sum())
        self.exact += int(nreal <= int(live.sum()) <= nreal + nign)
        self.pics += 1

    def result(self):
        """AP, AP50, found, right, far, mid, near, exact count; all percentages."""
        aps = [ap(np.concatenate(self.scores[i]) if self.scores[i] else np.zeros(0),
                  np.concatenate(self.tps[i]).astype(float) if self.tps[i] else np.zeros(0), self.npos) for i in range(len(THRS))]
        pct = lambda x, y: 100.0 * x / max(y, 1)
        return (100 * float(np.mean(aps)), 100 * aps[0], pct(self.tp, self.npos), pct(self.tp, self.tp + self.fp),
                pct(*self.buckets["far"]), pct(*self.buckets["mid"]), pct(*self.buckets["near"]), pct(self.exact, self.pics))


def real(gts):
    return sum(1 for g in gts if not g[1])


def main():
    ap_ = argparse.ArgumentParser()
    ap_.add_argument("--data", required=True)
    ap_.add_argument("--weights", default="/app/rknn_weights")
    ap_.add_argument("--limit", type=int, default=0)
    a = ap_.parse_args()
    from yolox_backend import YoloxRKNNModel

    variants = [("416 stretch (today)", "yolox_tiny_int8_batch1.rknn", 416, False),
                ("416 keep (padding)", "yolox_tiny_int8_batch1.rknn", 416, True),
                ("320x544 keep (wide)", "yolox_tiny_int8_320x544.rknn", (320, 544), True),
                ("384x640 keep (wide)", "yolox_tiny_int8_384x640.rknn", (384, 640), True),
                ("448x800 keep (wide)", "yolox_tiny_int8_448x800.rknn", (448, 800), True)]
    imgs = sorted(f for ext in ("*.jpg", "*.jpeg", "*.png") for f in glob.glob(os.path.join(a.data, "images", ext)))
    if a.limit:
        imgs = imgs[:a.limit]
    pics = []
    for p in imgs:
        im = cv2.imread(p)
        if im is None:
            continue
        h0, w0 = im.shape[:2]
        cut, x0, y0 = wide_crop(im)
        fh, fw = cut.shape[:2]
        gts = load_objects(os.path.join(a.data, "labels", os.path.splitext(os.path.basename(p))[0] + ".txt"), w0, h0, x0, y0, fw, fh)
        if not any(real(v) for v in gts.values()):
            continue
        # today the worker squashes to 640x640; with CAMERA_AI_FRAME_HEIGHT=0 it sends 640x360 (true shape)
        pics.append((cv2.resize(cut, (640, 640), interpolation=cv2.INTER_LINEAR),
                     cv2.resize(cut, (640, 360), interpolation=cv2.INTER_LINEAR), fw, fh, gts))
    counted = {g: sum(real(p[4][g]) for p in pics) for g in GROUPS}
    print("PICTURES %d wide (16:9) pictures, %d with people; counted %d people, %d vehicles, %d animals" % (
        len(pics), sum(1 for p in pics if real(p[4]["person"])), counted["person"], counted["vehicle"], counted["animal"]), flush=True)

    rows, results = [], {}
    for name, fname, size, keep in variants:
        path = os.path.join(a.weights, fname)
        if not os.path.exists(path):
            print("SKIP %s: %s not in this image" % (name, fname), flush=True)
            err = path[:-5] + ".build_error.txt"
            if os.path.exists(err):
                print("BUILD_ERROR %s (last lines):" % fname)
                print("".join(open(err, errors="replace").readlines()[-40:]), flush=True)
            continue
        m = YoloxRKNNModel(path, nc=1, model_size=size, classes=(0,), keep_shape=keep, default_aspect="16:9")
        m.set_source_aspect(640 / 360.0)
        m.rknn_lite = ReuseNPU(m.rknn_lite)
        tally = {g: Tally() for g in GROUPS}
        npu, pre, post = [], [], []
        for k, (f640, f360, fw, fh, gts) in enumerate(pics):
            frame = f360 if keep else f640          # what the worker would send for this option
            if k < 150:   # live-like timing pass at the live threshold, people as today
                m.rknn_lite.fresh()
                m.set_thread_classes(GROUPS["person"])
                m.predict_frame(frame, conf_thresh=LIVE_CONF, iou_thresh=0.45)
                t = m.last_timing
                pre.append(t["backend_preprocess_elapsed_ms"]); npu.append(t["backend_inference_elapsed_ms"]); post.append(t["backend_postprocess_elapsed_ms"])
            fx, fy = fw / float(frame.shape[1]), fh / float(frame.shape[0])
            m.rknn_lite.fresh()
            for g, ids in GROUPS.items():
                if g == "person" and not real(gts[g]):
                    continue
                m.set_thread_classes(ids)
                det = m.predict_frame(frame, conf_thresh=0.01, iou_thresh=0.45)
                b = det[:, :4] * np.array([fx, fy, fx, fy]) if len(det) else np.zeros((0, 4))
                tally[g].add(b, det[:, 4] if len(det) else np.zeros(0), gts[g])
        ap_p, ap50, found, right, far, mid, near, exact_c = tally["person"].result()
        r = (name, ap_p, ap50, found, right, far, mid, near, exact_c,
             statistics.median(npu), statistics.median(pre), statistics.median(post))
        rows.append(r)
        print("RESULT %-22s accuracy(AP) %5.1f | AP50 %5.1f | found %5.1f%% | right %5.1f%% | far %5.1f%% mid %5.1f%% near %5.1f%% | exact count %5.1f%% | NPU %5.1f ms prep %4.1f ms decode %4.1f ms" % r, flush=True)
        for g in ("vehicle", "animal"):
            print("  %-7s accuracy(AP) %5.1f | AP50 %5.1f | found %5.1f%% | right %5.1f%% | far %5.1f%% mid %5.1f%% near %5.1f%% | exact count %5.1f%%" % ((g,) + tally[g].result()), flush=True)
        results[name] = {g: tally[g].result() for g in GROUPS}
        del m   # releases the NPU copy
    if rows:
        base = rows[0]
        print("SUMMARY vs today (accuracy points, NPU time ratio):")
        for r in rows[1:]:
            print("  %-22s %+5.1f AP | far people %+5.1f pts | NPU x%.2f" % (r[0], r[1] - base[1], r[5] - base[5], r[9] / max(base[9], 1e-6)))
            for g in ("vehicle", "animal"):
                x, y = results[r[0]][g], results[base[0]][g]
                print("    %-7s %+5.1f AP | far %+5.1f pts" % (g, x[0] - y[0], x[4] - y[4]))


if __name__ == "__main__":
    main()
