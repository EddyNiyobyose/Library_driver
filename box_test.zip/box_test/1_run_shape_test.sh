#!/usr/bin/env bash
# Input size test on the real NPU, with this folder's evaluate_shapes.py. Run: bash 1_run_shape_test.sh
# Uses the NPU for 15-30 minutes next to the live service. Writes shape_test_<time>.log next to this file.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG="$HERE/shape_test_$(date +%Y%m%d_%H%M%S).log"
EVAL_SCRIPT="$HERE/evaluate_shapes.py" bash "$HERE/box_shapes_test.sh" 2>&1 | tee "$LOG"
echo "Log: $LOG"
