#!/usr/bin/env bash
# Read-only check before the shape test. Changes nothing and uses no NPU time. Run: bash 0_check_box.sh
set -uo pipefail
exec </dev/null
NS=camera-solution
echo "=== BOX CHECK ==="; date; hostname; uptime
P="$(kubectl -n "$NS" get pods -o name 2>/dev/null | grep -i edgevision | head -1)"; P="${P#pod/}"
if [ -z "$P" ]; then echo "STOP: AI service pod not found in namespace $NS"; exit 1; fi
echo "--- AI pod: $P"
kubectl -n "$NS" get pod "$P" -o jsonpath='image: {.spec.containers[*].image}{"\n"}started: {.status.startTime}{"\n"}'
kubectl -n "$NS" get pod "$P" --no-headers
echo "--- model files in the image"
kubectl -n "$NS" exec "$P" -- sh -c 'ls -l /app/rknn_weights/ 2>&1 | sed "s/^/  /"; for f in /app/rknn_weights/*.build_error.txt; do [ -f "$f" ] && echo "  BUILD ERROR: $f"; done; true'
echo "--- test script in the image"
kubectl -n "$NS" exec "$P" -- sh -c 'ls -l /app/scripts/evaluate_shapes.py 2>&1 | sed "s/^/  /"'
echo "--- settings the test depends on"
kubectl -n "$NS" exec "$P" -- sh -c 'env | grep -E "^(EDGEVISION_|CAMERA_AI_)" | sed "s/^/  /"; true'
echo "--- backend person filter settings"
B="$(kubectl -n "$NS" get pods -o name 2>/dev/null | grep -i backend | head -1)"; B="${B#pod/}"
if [ -n "$B" ]; then
  kubectl -n "$NS" exec "$B" -- sh -c 'env | grep -E "^CAMERA_ANALYTICS_PERSON_" | sed "s/^/  /"; echo "  (nothing listed = code defaults)"'
else
  echo "  backend pod not found in $NS"
fi
echo "--- host python"
python3 --version 2>&1 | sed 's/^/  /'
echo "--- internet (needed only if the box has no labelled pictures)"
for u in https://github.com http://images.cocodataset.org; do
  printf '  %s: ' "$u"; curl -sS -o /dev/null -m 10 -w '%{http_code}\n' "$u" 2>&1 | tail -n 1
done
echo "--- free space"
df -h /tmp 2>&1 | sed 's/^/  /'
kubectl -n "$NS" exec "$P" -- sh -c 'df -h /tmp 2>&1 | sed "s/^/  pod: /"'
echo "=== DONE: send this output back ==="
