# YOLOX-Tiny input size test on the box

Compares 416 stretch (today), 416 keep, 320x544, 384x640 and 448x800 on the real NPU, through the live
`YoloxRKNNModel` code: accuracy for people, vehicles and animals, plus NPU, prepare and decode time.

It loads its own model copies. It does not restart anything or change settings or the service's data.
It does share the NPU with the live service while it runs.

## Files

| File | What it does |
|---|---|
| `0_check_box.sh` | Read-only check. No NPU use. Run this first. |
| `1_run_shape_test.sh` | Runs the test and saves a log next to it. |
| `box_shapes_test.sh` | The test itself, called by step 1. |
| `evaluate_shapes.py` | Copied into the AI pod's `/tmp/shapetest` for the run, removed afterwards. |
| `prep_wide_data.py` | Only if the box has no internet: run on another machine, then copy the pictures to the box. |

## Steps

Copy this folder to the box host (needs `kubectl`), for example to `/tmp/box_test`.

1. Run the check and send back the output:

   ```bash
   bash /tmp/box_test/0_check_box.sh
   ```

   Please look for:
   - `yolox_tiny_int8_320x544.rknn`, `..._384x640.rknn` and `..._448x800.rknn` are listed, with no `BUILD ERROR`.
     A missing model is skipped by the test, not treated as a failure.
   - The backend filter settings show `CAMERA_ANALYTICS_PERSON_FILTER_PROFILE` if it is set.
   - The internet lines show a status code. The test downloads COCO pictures if `/mnt/data` has no labelled set.

2. Agree on a time. The test uses the NPU for 15-30 minutes, so pick a quiet period for the cameras.

3. Run the test:

   ```bash
   bash /tmp/box_test/1_run_shape_test.sh
   ```

   Send back the log file. It ends with `=== DONE ===`.

To stop early, press Ctrl+C. The pod's `/tmp/shapetest` may stay behind; remove it with:

```bash
kubectl -n camera-solution exec "$(kubectl -n camera-solution get pods -o name | grep -i edgevision | head -1)" -- rm -rf /tmp/shapetest
```

## Not tested on real hardware yet

The script changes were checked with a fake `kubectl` and a fake NPU only. If anything looks wrong, stop and send the output.
